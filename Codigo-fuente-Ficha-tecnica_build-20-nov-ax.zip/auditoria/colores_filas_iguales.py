exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('ev("localStorage.clear()')[0])
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(4)
for code in ("700","408"):
    ev("document.getElementById('addColorBtn').click()");time.sleep(1.2)
    ev("(function(){var p=document.getElementById('cdPantone');p.value='%s';p.dispatchEvent(new Event('input',{bubbles:true}))})()"%code);time.sleep(.4)
    ev("document.querySelector('.cd-submit').click()");time.sleep(2.5)

print(ev("""JSON.stringify([].map.call(document.querySelectorAll('.pb-colrow'),function(r){var chain=[],e=r;while(e&&chain.length<8){chain.push(e.tagName+'.'+(e.className.toString().split(' ').slice(0,3).join('.')));e=e.parentElement}var c=r.querySelector('.pb-colchip');var cs=c?getComputedStyle(c):null;return {chain:chain.join(' < '),chip:cs?[cs.height,cs.border,cs.background.slice(0,30),cs.fontSize].join('|'):null,n:r.children.length,html:r.innerHTML.slice(0,260)}}),null,1)"""))
ev("__tdbg('pgCenter(PG.pages[0].v.id,true)')");time.sleep(1)
r=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/cl1.png","wb").write(base64.b64decode(r["result"]["data"]))
