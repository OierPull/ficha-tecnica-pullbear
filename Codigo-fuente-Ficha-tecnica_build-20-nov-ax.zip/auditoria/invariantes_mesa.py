exec(open("auditoria/cdp.py").read())
import time,json,random
EV=[]
def call(method,params=None):
    global i;i+=1;send({"id":i,"method":method,"params":params or {}})
    while True:
        m=recv()
        if "method" in m: EV.append(m)
        if m.get("id")==i:return m
def pump(t=.4):
    s.settimeout(t)
    try:
        while True: EV.append(recv())
    except Exception: pass
    s.settimeout(90)
s.settimeout(90)
call("Runtime.enable");call("Log.enable");call("Page.enable");call("DOM.enable");call("Page.setInterceptFileChooserDialog",{"enabled":True})
call("Page.bringToFront")
call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(3)
INV="""JSON.stringify((function(){var L=document.querySelector('.pg-layer'),bad=[];if(!L)return ['sin capa'];var P=window.__PG;P.pages.forEach(function(p){var id=p.v.id;var lab=L.querySelector('.pg-lab[data-pglab="'+id+'"]:not(.is-cont)');var sp=L.querySelector('.pg-spec[data-pgv="'+id+'"]');var gd=L.querySelector('.pg-grid[data-pggrid="'+id+'"]');if(!lab)bad.push(id+': sin título');else{var cur=lab.querySelector('.pgl-cur');var r=cur&&cur.getBoundingClientRect();if(!r||r.width<5)bad.push(id+': título colapsado');if(lab.getBoundingClientRect().width<40)bad.push(id+': etiqueta estrecha')}if(!sp)bad.push(id+': sin ficha');if(!gd)bad.push(id+': sin rejilla');else if(gd.hidden)bad.push(id+': rejilla oculta')});return bad})())"""
def inv(tag):
    b=json.loads(ev(INV))
    print(("✔ " if not b else "✘ ")+tag,b if b else "")
    return b
def V(): return json.loads(ev("JSON.stringify(__tdbg('boardV()'))"))
fails=0
fails+=len(inv("tras crear"))
for z in (0.1,0.2,0.35,0.6,1.0,1.6):
    ev("__tdbg('BOARD.zoom=%s;boardRedraw();pgLayerPos()')"%z);time.sleep(.7);fails+=len(inv("zoom %s"%z))
ev("__tdbg('BOARD.zoom=0.5;boardRedraw();pgLayerPos()')")
# add pages through the + button between sheets
for n in range(2):
    ev("var b=document.querySelector('[data-pgadd]');b&&b.click()");time.sleep(2.5)
    ev("var pop=document.getElementById('tabPop');if(pop){var i=pop.querySelector('input[type=text],input:not([type])');if(i){i.value='Extra'+Math.floor(Math.random()*900+100);i.dispatchEvent(new Event('input',{bubbles:true}))}var b=[].find.call(pop.querySelectorAll('button'),function(x){return x.textContent.trim()==='Añadir'});b&&b.click()}");time.sleep(3)
    fails+=len(inv("tras añadir página %d"%(n+1)))
# reload + open
call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("document.querySelector('.project-card').click()");time.sleep(.4);fails+=len(inv("reabrir +0.4s"))
time.sleep(2.5);fails+=len(inv("reabrir +3s"))
# images through real UI + rect
def mouse(t,x,y,b=0):
    call("Input.dispatchMouseEvent",{"type":t,"x":x,"y":y,"button":"left","buttons":b,"clickCount":1})
def click_el(js):
    r=json.loads(ev("JSON.stringify((function(){var e=%s;if(!e)return null;var r=e.getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})())"%js))
    mouse("mouseMoved",r[0],r[1]);mouse("mousePressed",r[0],r[1],1);mouse("mouseReleased",r[0],r[1],0)
def choose(path):
    for _ in range(20):
        pump(.3)
        for m in EV:
            if m.get("method")=="Page.fileChooserOpened":
                EV.remove(m);call("DOM.setFileInputFiles",{"files":[path],"backendNodeId":m["params"]["backendNodeId"]});return True
        time.sleep(.2)
    return False
for f in ("a","b","c"):
    click_el("document.querySelector('.board-island [data-bupload]')||[].find.call(document.querySelectorAll('.board-island button'),function(b){return /imagen/i.test(b.title||b.getAttribute('aria-label')||'')})")
    choose("/tmp/opencode/img_%s.png"%f);time.sleep(2)
    fails+=len(inv("imagen %s"%f))
pump(1)
errs=[]
for m in EV:
    if m.get("method")=="Runtime.exceptionThrown":
        d=m["params"]["exceptionDetails"];errs.append("EXC "+(d.get("exception",{}).get("description") or d.get("text"))[:160])
    elif m.get("method")=="Runtime.consoleAPICalled" and m["params"]["type"]=="error":
        errs.append("console.error "+" ".join(str(a.get("value",a.get("description","")))[:100] for a in m["params"]["args"]))
print("TOTAL fallos de invariantes:",fails,"| errores de consola:",len(errs))
for e in errs[:8]: print("  ",e)
