exec(open("auditoria/cdp.py").read())
import time,json,sys
s.settimeout(240)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
LANG=sys.argv[1] if len(sys.argv)>1 else "es"
ev("localStorage.clear();localStorage.setItem('pb-lang','%s')"%LANG);call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(4)
ev("document.getElementById('versionCompareDemo').click()");time.sleep(3)
ev("""__tdbg(`(function(){var p=PG.pages[1];var c=document.createElement("canvas");c.width=1200;c.height=1200;var x=c.getContext("2d");x.fillStyle="#6b4a32";x.fillRect(0,0,1200,1200);BOARD.objects.push({id:"im",type:"image",x:p.ox+60,y:60,w:420,h:420,src:c.toDataURL()});for(var k=0;k<9;k++){BOARD.objects.push({id:"r"+k,type:"rect",x:p.ox+80+k*40,y:100+(k%3)*110,w:130,h:80,sw:3,color:"#d64545"})}boardCommit()})()`)""");time.sleep(2)
for f in ("pdfjs.min.js",):
    ev("new Promise(function(r){var s=document.createElement('script');s.src='/%s';s.onload=r;document.head.appendChild(s)})"%f)
ev("pdfjsLib.GlobalWorkerOptions.workerSrc='/pdfjs.worker.min.js'")
t0=time.time()
ev("window.__pbCombine={parts:[]}")
code="""(async function(){var plan=buildExportPagePlan('red'),keys=plan.map(pdfPageKey),sel=plan.map(function(p,i){return i});window.__pdfok=null;await new Promise(function(res){startPdfExport('red',keys,function(ok){window.__pdfok=ok;res()})});return window.__pdfok})()"""
print("export ok:",ev("__tdbg(%s)"%json.dumps(code)),round(time.time()-t0,1),"s")
print("bytes:",ev("window.__pbCombine.parts.length&&window.__pbCombine.parts[0].bytes.length"))
render="""(async function(scale){var b=window.__pbCombine.parts[0].bytes,doc=await pdfjsLib.getDocument({data:b.slice()}).promise,out=[];for(var i=1;i<=doc.numPages;i++){var pg=await doc.getPage(i),vp=pg.getViewport({scale:scale}),cv=document.createElement('canvas');cv.width=vp.width;cv.height=vp.height;await pg.render({canvasContext:cv.getContext('2d'),viewport:vp}).promise;out.push(cv.toDataURL('image/png'))}return JSON.stringify(out)})(%s)"""
rr=ev(render%("1.6"))
if isinstance(rr,dict):print(str(rr)[:600]);sys.exit(1)
r=json.loads(rr)
for i,u in enumerate(r):
    open("/tmp/pdfout/%s_p%d.png"%(LANG,i+1),"wb").write(base64.b64decode(u.split(",")[1]))
print("páginas:",len(r))
