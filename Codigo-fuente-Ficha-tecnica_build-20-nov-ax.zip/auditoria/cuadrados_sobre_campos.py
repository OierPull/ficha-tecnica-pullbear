exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
ev("""__tdbg(`(function(){var p=PG.pages[0];pgCenter(p.v.id,true)})()`)""");time.sleep(1.5)
def pt(x,y,t,**k):
    d={"type":t,"x":x,"y":y,"button":"left","clickCount":1};d.update(k);call("Input.dispatchMouseEvent",d)
def click(x,y,**k):
    pt(x,y,"mouseMoved");pt(x,y,"mousePressed",**k);pt(x,y,"mouseReleased",**k);time.sleep(.4)
def objs(): return ev("""JSON.stringify(__tdbg('[BOARD.tool,BOARD.sel,BOARD.objects.filter(function(o){return !o.virtual}).map(function(o){return [o.id,o.type,Math.round(o.x),Math.round(o.y),Math.round(o.w),Math.round(o.h)]})]'))""")
sp=json.loads(ev("JSON.stringify((function(){var r=document.querySelector('.pg-spec').getBoundingClientRect();return [r.left,r.top,r.width,r.height]})())"))
fld=json.loads(ev("JSON.stringify((function(){var l=[].filter.call(document.querySelectorAll('.pg-spec textarea,.pg-spec input'),function(x){var b=x.getBoundingClientRect();return b.width>0&&b.top>sp_top&&b.top<700});var b=l[1].getBoundingClientRect();return [b.left+b.width/2,b.top+b.height/2]})())".replace("sp_top",str(sp[1]))))
ev("""__tdbg(`boardSetTool("rect")`)""")
click(*fld);print("A: cuadrado + clic en campo ->",objs(),"foco:",ev("document.activeElement.tagName"))
# crear cuadrado debajo del panel de texto por programa
ev("""__tdbg(`(function(){var h=BOARD.host.getBoundingClientRect(),v=boardV();var x=(%d-h.left-v.ox)/v.k,y=(%d-h.top-v.oy)/v.k;BOARD.objects.push({id:boardId(),type:"rect",x:x-30,y:y-30,w:200,h:140,color:"#d33",sw:3});boardCommit();boardSetTool("select")})()`)"""%(sp[0]+sp[2]/2,sp[1]+sp[3]/2));time.sleep(.5)
print("creado",objs())

rb=json.loads(ev("""JSON.stringify(__tdbg('(function(){var o=BOARD.objects.filter(function(o){return !o.virtual})[0],h=BOARD.host.getBoundingClientRect(),v=boardV();return [h.left+v.ox+o.x*v.k,h.top+v.oy+o.y*v.k,o.w*v.k,o.h*v.k]})()'))"""))
print("rect pantalla",rb)
gap=json.loads(ev("""JSON.stringify((function(rb){var out=[];var sp=document.querySelector('.pg-spec');for(var y=rb[1]+2;y<rb[1]+rb[3];y+=2)for(var x=rb[0]+2;x<rb[0]+rb[2];x+=3){var e=document.elementFromPoint(x,y);if(e&&e.closest&&e.closest('.pg-spec')&&!e.closest('input,textarea,button,select,a'))return [x,y,e.className]}return null})(%s))"""%json.dumps(rb)))
print("hueco",gap)
if gap:
    click(gap[0],gap[1]);print("B: clic en hueco ->",objs())
    call("Input.dispatchKeyEvent",{"type":"keyDown","key":"Delete","code":"Delete","windowsVirtualKeyCode":46});call("Input.dispatchKeyEvent",{"type":"keyUp","key":"Delete","code":"Delete","windowsVirtualKeyCode":46});time.sleep(.4)
    print("tras Supr ->",objs())
