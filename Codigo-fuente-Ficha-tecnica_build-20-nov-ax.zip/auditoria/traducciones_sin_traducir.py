exec(open("auditoria/cdp.py").read())
import time,json,re
s.settimeout(90)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
H=open("auditoria/harvest.js").read()
allt={}
def grab(tag):
    r=json.loads(ev("JSON.stringify("+H+")"))
    for t in r: allt.setdefault(t,tag)
def closeall():
    ev("""(function(){document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));[].forEach.call(document.querySelectorAll('[aria-label=Close],[aria-label=Cerrar],.portal-modal-close,#cancelProject,#versionCompareClose,#pdfExportClose,[data-pba4x],#crClose'),function(b){if(b.offsetParent!==null)b.click()})})()""");time.sleep(.4)
def clk(js_cond):
    return ev("(function(){var b=[].find.call(document.querySelectorAll('button,[role=button],a,summary'),function(b){return b.offsetParent!==null&&(%s)});if(b){b.click();return true}return false})()"%js_cond)
ev("localStorage.clear();localStorage.setItem('pb-lang','es')");call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(4)
ev("document.getElementById('versionCompareDemo').click()");time.sleep(3)
print(ev("location.href+' '+document.title"))
grab("proj")
print("share:",clk("/Compartir/.test(b.textContent+b.title+(b.getAttribute('aria-label')||''))"));time.sleep(1.2);grab("share");closeall()
print("cmp:",clk("b.id==='versionCompareOpen'"));time.sleep(2);grab("cmp")
ev("""(function(){var s=[].slice.call(document.querySelectorAll('#versionCompareModal select'));console.log(s.length);if(s.length>1){s[0].selectedIndex=0;s[1].selectedIndex=s[1].options.length-1;s.forEach(function(x){x.dispatchEvent(new Event('change',{bubbles:true}))})}})()""");time.sleep(2);grab("cmpres")
print(ev("document.querySelector('#versionCompareResults')?document.querySelector('#versionCompareResults').innerText.slice(0,400):'none'"))
closeall()
# click a change row in the pdf export modal etc
print("pdf:",clk("b.id==='pdfExportOpen'"));time.sleep(1.5);grab("pdf");
ev("document.getElementById('pdfExportStart').scrollIntoView()");grab("pdf2");closeall()
# project-level things: color add inside project
clk("b.id==='addColorBtn'");time.sleep(.8);grab("addcolor");closeall()
# status chip click
ev("""(function(){var b=document.querySelector('.approval-chip');if(b)b.click()})()""");time.sleep(.5);grab("chip")
# delete image modal
# back to home, folder
clk("b.id==='returnToProjects'");time.sleep(1.5);grab("home2")

arr=list(allt.items())
CODE="(function(a){var l=I18N.lang;I18N.lang='en';I18N.cache={};var o=a.map(function(t){return i18nTr(t)});I18N.lang=l;return JSON.stringify(o)})(" + json.dumps([t for t,_ in arr]) + ")"
res=json.loads(ev('__tdbg('+json.dumps(CODE)+')'))
for (t,tag),r in zip(arr,res):
    if r==t and re.search(r'[A-Za-zÁÉÍÓÚÑáéíóúñ]{3}',t): print("UNTR",tag,'|',t[:200])
print("total",len(arr))
if len(sys.argv)>1:
    for (t,tag),r in zip(arr,res):
        if tag in sys.argv[1:]: print(tag,'|',t[:80],'=>',r[:80])
