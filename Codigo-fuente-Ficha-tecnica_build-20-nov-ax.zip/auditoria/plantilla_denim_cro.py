exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(90)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1.2)
print("plantillas en el formulario:",ev("JSON.stringify([].map.call(document.querySelectorAll('#npTemplates .np-row strong'),function(e){return e.textContent}))"))
print("detalle:",ev("JSON.stringify([].map.call(document.querySelectorAll('#npTemplates .np-row em'),function(e){return e.textContent}))"))
# select Denim CRO and create
ev("(function(){var r=[].find.call(document.querySelectorAll('#npTemplates input[name=npTpl]'),function(i){return i.value==='tpl-builtin-denim-cro'});r.click()})()");time.sleep(.3)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','SICKO19');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(5)
print("páginas:",ev("JSON.stringify(__tdbg('PG.pages.map(function(p){return p.v.label})'))"))
print("secciones de la ficha:",ev("JSON.stringify(__tdbg('data[active].map(function(g){return g.name})'))"))
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/tp1.png","wb").write(base64.b64decode(rc["result"]["data"]))
ev("""__tdbg(`(function(){var p=PG.pages.find(function(q){return q.v.label==="Wash"});pgCenter(p.v.id,true)})()`)""");time.sleep(1.5)
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/tp2.png","wb").write(base64.b64decode(rc["result"]["data"]))
