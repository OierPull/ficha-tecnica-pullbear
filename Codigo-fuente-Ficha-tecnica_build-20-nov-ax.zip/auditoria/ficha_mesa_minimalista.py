exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
ev("""__tdbg(`(function(){var g=data[active].find(function(x){return x.name==="Dibujo plano"});for(var k=0;k<3;k++){var it=item("Título "+(k+1),["Descripción"],false);it.userCreated=true;it.fields[0].value=k==0?"":"yaaa texto "+k;if(k==1)it.fields[0].status="ok";g.items.push(it)}persist();render();pgLayerBuild(true);var p=PG.pages.find(function(q){return q.v.id==="sketch"});pgCenter(p.v.id,true)})()`)""");time.sleep(2)
ev("__tdbg('boardSetPct(110)')");time.sleep(.6)
ev("__tdbg('(function(){var p=PG.pages.find(function(q){return q.v.id===\"sketch\"}),v=boardV();BOARD.panX+=-p.ox*v.k-v.ox-(PG.CX-60)*v.k+100;BOARD.panY+=100-v.oy;boardRedraw();pgLayerPos()})()')");time.sleep(.6)
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/mn1a.png","wb").write(base64.b64decode(rc["result"]["data"]))
# hover on 2nd block
pt=json.loads(ev("JSON.stringify((function(){var b=document.querySelectorAll('.pg-spec .pgs-blk')[1];var r=b.getBoundingClientRect();return [r.left+r.width/2,r.top+30]})())"))
mouse("mouseMoved",*pt);time.sleep(.4)
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/mn1b.png","wb").write(base64.b64decode(rc["result"]["data"]))
