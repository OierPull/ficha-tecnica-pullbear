exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
ev("""__tdbg(`(function(){var p=PG.pages[2];pgCenter(p.v.id,true)})()`)""");time.sleep(1.5)
def pt(x,y,t,**k):
    d={"type":t,"x":x,"y":y,"button":"left","clickCount":1};d.update(k);call("Input.dispatchMouseEvent",d)
def drag(x,y,dx,dy):
    pt(x,y,"mouseMoved");pt(x,y,"mousePressed");pt(x+dx/2,y+dy/2,"mouseMoved",buttons=1);pt(x+dx,y+dy,"mouseMoved",buttons=1);pt(x+dx,y+dy,"mouseReleased");time.sleep(.6)
def click(x,y):
    pt(x,y,"mouseMoved");pt(x,y,"mousePressed");pt(x,y,"mouseReleased");time.sleep(.5)
def nums(): return ev("""JSON.stringify(__tdbg('(function(){var m=boardNumMapAll();return BOARD.objects.filter(function(o){return o.type==="rect"}).map(function(o){return [o.id.slice(-3),o.no||null,m[o.id]&&m[o.id].n]})})()'))""")
for i in range(3):
    ev("""__tdbg(`boardSetTool("rect")`)""");drag(300+i*110,300,80,70)
print("números",nums())
print("spec nums",ev("JSON.stringify([].map.call(document.querySelectorAll('.pg-spec .pgs-n'),function(e){return e.textContent}))"))
# seleccionar el 1º cuadrado
ev("""__tdbg(`(function(){var o=BOARD.objects.filter(function(o){return o.type==="rect"})[0];BOARD.sel=o.id;boardRedraw();boardCtxBar&&boardOverlay()})()`)""");time.sleep(.8)
print("barra:",ev("JSON.stringify([].map.call(document.querySelectorAll('.board-ctxbar .pg-numctl'),function(g){return [g.hidden,g.textContent.replace(/\\s+/g,' '),g.querySelector('input').value]}))"))
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/nm1.png","wb").write(base64.b64decode(rc["result"]["data"]))
# poner 3 (ocupado) -> confirm
ev("(function(){var i=document.querySelector('[data-pgnov]');i.focus();i.value='3';i.dispatchEvent(new Event('change',{bubbles:true}))})()");time.sleep(.6)
print("modal:",ev("(document.querySelector('.ui-modal')||{}).textContent"))
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/nm2.png","wb").write(base64.b64decode(rc["result"]["data"]))
ev("document.querySelector('.ui-modal [data-ui=yes]').click()");time.sleep(.8)
print("tras intercambiar",nums())
# número libre 7
ev("(function(){var i=document.querySelector('[data-pgnov]');i.focus();i.value='7';i.dispatchEvent(new Event('change',{bubbles:true}))})()");time.sleep(.6)
print("tras 7",nums(),ev("JSON.stringify([].map.call(document.querySelectorAll('.pg-spec .pgs-n'),function(e){return e.textContent}))"))

rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/nm3.png","wb").write(base64.b64decode(rc["result"]["data"]))
# edición en el bloque: pulsar el número del 2º bloque y escribir uno ocupado
r=json.loads(ev("JSON.stringify((function(){var n=document.querySelectorAll('.pg-spec .pgs-n')[1].getBoundingClientRect();return [n.left+n.width/2,n.top+n.height/2]})())"))
click(*r);print("input en bloque:",ev("!!document.querySelector('.pgs-nin')"))
ev("(function(){var i=document.querySelector('.pgs-nin');i.value='1'})()");call("Input.dispatchKeyEvent",{"type":"keyDown","key":"Enter","code":"Enter","windowsVirtualKeyCode":13,"text":"\r"});call("Input.dispatchKeyEvent",{"type":"keyUp","key":"Enter","code":"Enter","windowsVirtualKeyCode":13});time.sleep(.7)
print("modal bloque:",ev("(document.querySelector('.ui-modal')||{textContent:null}).textContent"))
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/nm4.png","wb").write(base64.b64decode(rc["result"]["data"]))
ev("document.querySelector('.ui-modal [data-ui=yes]').click()");time.sleep(.8)
print("tras",nums(),ev("JSON.stringify([].map.call(document.querySelectorAll('.pg-spec .pgs-n'),function(e){return e.textContent}))"))
