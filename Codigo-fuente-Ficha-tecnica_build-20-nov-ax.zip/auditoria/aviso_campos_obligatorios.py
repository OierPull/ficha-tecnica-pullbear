exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
ev("document.getElementById('pdfExportOpen').click()");time.sleep(1.2)
def st(): return ev("JSON.stringify((function(){var o=document.getElementById('pgPdfWarn');var vis=function(e){return e&&!e.hidden&&getComputedStyle(e).display!=='none'};return {texto:o.querySelector('.pg-mf-box > p').textContent,filas:o.querySelectorAll('.pg-mf-row').length,sinCompletar:vis(o.querySelector('[data-pgwarn=go]')),descargar:vis(o.querySelector('[data-pgmfgo]'))}})())")
print("al abrir:",st())
n=int(ev("document.querySelectorAll('#pgPdfWarn .pg-mf-in').length"))
for i in range(n):
    ev("(function(){var e=document.querySelectorAll('#pgPdfWarn .pg-mf-in')[%d];if(e.tagName==='SELECT'){e.selectedIndex=1;e.dispatchEvent(new Event('change',{bubbles:true}))}else{e.value='ok';e.dispatchEvent(new Event('input',{bubbles:true}))}})()"%i);time.sleep(.3)
    print("tras rellenar %d/%d:"%(i+1,n),st())
rc=call("Page.captureScreenshot",{"format":"png","clip":{"x":150,"y":0,"width":900,"height":700,"scale":1}});open("/tmp/opencode/wn1.png","wb").write(base64.b64decode(rc["result"]["data"]))
