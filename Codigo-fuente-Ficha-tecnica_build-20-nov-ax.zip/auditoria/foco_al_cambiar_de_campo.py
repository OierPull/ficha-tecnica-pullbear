exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('clickfield(0')[0])
def pos(sel_i):
    return json.loads(ev("JSON.stringify((function(){var f=[].filter.call(document.querySelectorAll('.pg-spec textarea,.pg-spec input'),function(x){var b=x.getBoundingClientRect();return b.width>0&&b.left>0&&b.left<1100&&b.top>80&&b.top<700});var b=f[%d].getBoundingClientRect();return [b.left+30,b.top+b.height/2]})())"%sel_i))
def click(r):
    for t in("mouseMoved","mousePressed","mouseReleased"):call("Input.dispatchMouseEvent",{"type":t,"x":r[0],"y":r[1],"button":"left","clickCount":1})
ev("""__tdbg(`(function(){var p=PG.pages[2];pgCenter(p.v.id,true)})()`)""");time.sleep(1.5)
click(pos(0));time.sleep(.3);call("Input.insertText",{"text":"Hola"});time.sleep(.5)
print("n campos visibles",ev("document.querySelectorAll('.pg-spec textarea,.pg-spec input').length"))
ev("window.__s=[];document.addEventListener('focusout',function(e){window.__s.push(e.target.className+'|'+e.relatedTarget)},true);new MutationObserver(function(m){window.__s.push('MUT '+m.length+' '+(new Error().stack||''))}).observe(document.querySelector('.pg-layer')||document.body,{subtree:true,childList:true})")
click(pos(1));time.sleep(.2);call("Input.insertText",{"text":"y"});time.sleep(.8)
print(info(),ev("JSON.stringify(window.__s)")[:600])
