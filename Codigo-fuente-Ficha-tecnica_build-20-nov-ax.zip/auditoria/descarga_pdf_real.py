exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(120)
EV=[]
def call(method,params=None):
    global i;i+=1;send({"id":i,"method":method,"params":params or {}})
    while True:
        m=recv()
        if "method" in m: EV.append(m)
        if m.get("id")==i:return m
def pump(t=.5):
    s.settimeout(t)
    try:
        while True: EV.append(recv())
    except Exception: pass
    s.settimeout(120)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
call("Runtime.enable");call("Page.enable");call("Browser.setDownloadBehavior",{"behavior":"allow","downloadPath":"/tmp/opencode/dl","eventsEnabled":True}) if False else None
call("Page.setDownloadBehavior",{"behavior":"allow","downloadPath":"/tmp/opencode/dl"})
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(4)
ev("document.getElementById('versionCompareDemo').click()");time.sleep(3)
ev("document.getElementById('versionCompareClose').click()");time.sleep(1)
ev("document.getElementById('pdfExportOpen').click()");time.sleep(1.2)
print("aviso:",ev("(function(){var w=document.getElementById('pgPdfWarn');return w?w.innerText.replace(/\\n/g,' / ').slice(0,200):null})()"))
print("botones aviso:",ev("JSON.stringify([].map.call(document.querySelectorAll('#pgPdfWarn button'),function(b){return [b.textContent.trim(),b.getAttribute('data-pgwarn')]}))"))
ev("(function(){var b=document.querySelector('#pgPdfWarn [data-pgwarn=go]');if(b)b.click()})()");time.sleep(1.5)
print("modal oculto:",ev("document.getElementById('pdfExportModal').hidden"))
print("botones modal:",ev("JSON.stringify([].map.call(document.querySelectorAll('#pdfExportModal button'),function(b){return [b.id,b.textContent.trim().slice(0,30),b.offsetParent!==null]}))"))
EV.clear()
ev("setTimeout(function(){var b=[].find.call(document.querySelectorAll('#pdfExportModal button'),function(b){return /#FF0000/.test(b.textContent)&&b.offsetParent!==null});window.__btn=b&&b.outerHTML.slice(0,200);b.click()},20)")
t0=time.time()
while time.time()-t0<25:
    pump(1)
    for m in EV:
        mm=m.get("method")
        if mm in("Page.javascriptDialogOpening",):
            print("DIALOG",m["params"]["message"][:120]);send({"id":900+int(time.time()),"method":"Page.handleJavaScriptDialog","params":{"accept":True}})
        if mm=="Runtime.exceptionThrown":print("EXC",m["params"]["exceptionDetails"].get("exception",{}).get("description","")[:400])
        if mm=="Runtime.consoleAPICalled" and m["params"]["type"]=="error":print("console.error",[str(a.get("description") or a.get("value"))[:300] for a in m["params"]["args"]])
        if mm=="Page.downloadWillBegin":print("DOWNLOAD",m["params"].get("suggestedFilename"))
    EV.clear()
import os
print("botón pulsado:",ev("window.__btn"));print("archivos:",os.listdir("/tmp/opencode/dl") if os.path.isdir("/tmp/opencode/dl") else None)
print("estado modal:",ev("document.getElementById('pdfExportModal').hidden+' | '+document.getElementById('pdfExportStart').textContent"))
