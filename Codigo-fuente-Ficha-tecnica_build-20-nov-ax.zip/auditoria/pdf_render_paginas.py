exec(open("auditoria/cdp.py").read())
import time,json,sys
s.settimeout(240)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
LANG=sys.argv[1] if len(sys.argv)>1 else "es"
ev("localStorage.clear();localStorage.setItem('pb-lang','%s')"%LANG);call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(4)
ev("document.getElementById('versionCompareDemo').click()");time.sleep(3)
# add an annotated image to the first page so annotations are visible
ev("""__tdbg(`(function(){var p=PG.pages[1];var c=document.createElement("canvas");c.width=1800;c.height=1800;var x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,1800,1800);for(var i=0;i<60;i++){x.fillStyle=i%2?"#6b4a32":"#8a6a50";x.fillRect(300+i*20,200,10,1400)}x.fillStyle="#222";x.font="bold 90px Arial";x.fillText("DETALLE 123",500,900);BOARD.objects.push({id:"im",type:"image",x:p.ox+60,y:60,w:320,h:320,src:c.toDataURL()});BOARD.objects.push({id:"rc1",type:"rect",x:p.ox+120,y:120,w:140,h:90,sw:3,color:"#d64545"});BOARD.objects.push({id:"ar",type:"arrow",x1:p.ox+420,y1:200,x2:p.ox+300,y2:260,sw:3,color:"#d64545",text:"1,5 cm"});BOARD.objects.push({id:"tx",type:"text",x:p.ox+420,y:320,text:"Nota técnica",size:15,color:"#d64545"});boardCommit()})()`)""");time.sleep(2)
for f in ("pdfjs.min.js",):
    ev("new Promise(function(r){var s=document.createElement('script');s.src='/%s';s.onload=r;document.head.appendChild(s)})"%f)
ev("pdfjsLib.GlobalWorkerOptions.workerSrc='/pdfjs.worker.min.js'")
t0=time.time()
ev("window.__pbCombine={parts:[]}")
code="""(async function(){var plan=buildExportPagePlan('red'),keys=plan.map(pdfPageKey),sel=plan.map(function(p,i){return i});window.__pdfok=null;await new Promise(function(res){startPdfExport('red',keys,function(ok){window.__pdfok=ok;res()})});return window.__pdfok})()"""
print("export ok:",ev("__tdbg(%s)"%json.dumps(code)),round(time.time()-t0,1),"s")
print("bytes:",ev("window.__pbCombine.parts.length&&window.__pbCombine.parts[0].bytes.length"))
render="""(async function(scale){var b=window.__pbCombine.parts[0].bytes,doc=await pdfjsLib.getDocument({data:b.slice()}).promise,out=[];for(var i=1;i<=doc.numPages;i++){var pg=await doc.getPage(i),vp=pg.getViewport({scale:scale}),cv=document.createElement('canvas');cv.width=vp.width;cv.height=vp.height;await pg.render({canvasContext:cv.getContext('2d'),viewport:vp}).promise;out.push(cv.toDataURL('image/png'))}return JSON.stringify(out)})(%s)"""
rr=ev(render%("1.6"))
if isinstance(rr,dict):print(str(rr)[:600]);sys.exit(1)
r=json.loads(rr)
for i,u in enumerate(r):
    open("/tmp/pdfout/%s_p%d.png"%(LANG,i+1),"wb").write(base64.b64decode(u.split(",")[1]))
print("páginas:",len(r))
