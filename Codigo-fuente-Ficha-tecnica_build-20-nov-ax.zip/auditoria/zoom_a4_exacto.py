exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
def st(): return json.loads(ev("JSON.stringify(__tdbg('(function(){var v=boardV();return {pct:boardPct(),sheetPx:v.k*PG.SHW,label:document.querySelector(\"[data-zinput]\").value,zoom:BOARD.zoom}})()'))"))
print("inicial",st())
ev("__tdbg('boardSetPct(100)')");time.sleep(.3);print("100%",st())
# type exact value with real keyboard
r=json.loads(ev("JSON.stringify((function(){var e=document.querySelector('[data-zinput]');var b=e.getBoundingClientRect();return [b.left+b.width/2,b.top+b.height/2]})())"))
mouse("mouseMoved",r[0],r[1]);mouse("mousePressed",r[0],r[1],1);mouse("mouseReleased",r[0],r[1],0);time.sleep(.3)
print("foco en input:",ev("document.activeElement.matches('[data-zinput]')"),"selección:",ev("document.activeElement.selectionEnd-document.activeElement.selectionStart"))
for ch in "73":
    call("Input.dispatchKeyEvent",{"type":"keyDown","text":ch,"key":ch});call("Input.dispatchKeyEvent",{"type":"keyUp","key":ch})
call("Input.dispatchKeyEvent",{"type":"keyDown","key":"Enter","code":"Enter","windowsVirtualKeyCode":13,"text":"\r"});call("Input.dispatchKeyEvent",{"type":"keyUp","key":"Enter","code":"Enter","windowsVirtualKeyCode":13});time.sleep(.4)
print("tras escribir 73:",st())
# buttons
for b in ("in","in","out"):
    ev("document.querySelector('[data-bz=%s]').click()"%b);time.sleep(.2);print(b,round(st()["pct"],1),st()["label"])
ev("document.querySelector('[data-bz100]').click()");time.sleep(.3);print("A4 100:",st())
ev("document.querySelector('[data-bz=fit]').click()");time.sleep(.5);print("fit:",st())
# ctrl+wheel anchored at pointer
ev("__tdbg('boardSetPct(100)')");time.sleep(.2)
pt=json.loads(ev("JSON.stringify(__tdbg('(function(){var r=BOARD.host.getBoundingClientRect();return [r.left+r.width/2+100,r.top+r.height/2]})()'))"))
b4=json.loads(ev("JSON.stringify(__tdbg('(function(){var v=boardV(),r=BOARD.host.getBoundingClientRect();return [(%f-r.left-v.ox)/v.k,(%f-r.top-v.oy)/v.k]})()'))"%(pt[0],pt[1])))
call("Input.dispatchMouseEvent",{"type":"mouseWheel","x":pt[0],"y":pt[1],"deltaX":0,"deltaY":-120,"modifiers":2})
time.sleep(.4)
b5=json.loads(ev("JSON.stringify(__tdbg('(function(){var v=boardV(),r=BOARD.host.getBoundingClientRect();return [(%f-r.left-v.ox)/v.k,(%f-r.top-v.oy)/v.k]})()'))"%(pt[0],pt[1])))
print("wheel pct",round(st()["pct"],1),"punto bajo cursor antes/después",[round(x) for x in b4],[round(x) for x in b5])
# resize invariance
call("Emulation.setDeviceMetricsOverride",{"width":1100,"height":800,"deviceScaleFactor":1,"mobile":False});time.sleep(1)
ev("__tdbg('boardSetPct(100)')");time.sleep(.3);a=st()
call("Emulation.setDeviceMetricsOverride",{"width":1400,"height":900,"deviceScaleFactor":1,"mobile":False});time.sleep(1.2)
print("100 antes/después de redimensionar:",round(a["pct"],1),round(st()["pct"],1),round(st()["sheetPx"],1))
call("Emulation.clearDeviceMetricsOverride");time.sleep(.5)
ev("__tdbg('boardSetPct(100)')");time.sleep(.4)
r=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/zm1.png","wb").write(base64.b64decode(r["result"]["data"]))
print("a4 btn:",ev("!!document.getElementById('a4PreviewOpen')"))
