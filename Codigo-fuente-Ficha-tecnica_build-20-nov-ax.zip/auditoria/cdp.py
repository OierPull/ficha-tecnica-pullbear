import socket,os,base64,json,struct,sys,urllib.request
port=open(os.path.expanduser("~/.config/google-chrome/DevToolsActivePort")).read().split()[0]
tabs=json.load(urllib.request.urlopen(f"http://127.0.0.1:{port}/json/list"))
t=[x for x in tabs if x["type"]=="page" and "8765" in x["url"]][0]
s=socket.create_connection(("127.0.0.1",int(port)));s.settimeout(30)
k=base64.b64encode(os.urandom(16)).decode()
s.send(f"GET /devtools/page/{t['id']} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {k}\r\nSec-WebSocket-Version: 13\r\n\r\n".encode())
buf=b""
while b"\r\n\r\n" not in buf: buf+=s.recv(4096)
buf=buf.split(b"\r\n\r\n",1)[1]
def rd(n):
    global buf
    while len(buf)<n: buf+=s.recv(1<<20)
    r,buf=buf[:n],buf[n:];return r
def send(o):
    d=json.dumps(o).encode();m=os.urandom(4);n=len(d)
    h=bytes([0x81])+(bytes([0x80|n]) if n<126 else bytes([0xFE])+struct.pack(">H",n) if n<65536 else bytes([0xFF])+struct.pack(">Q",n))
    s.send(h+m+bytes(b^m[i%4] for i,b in enumerate(d)))
def recv():
    data=b""
    while True:
        b1,b2=rd(2);fin=b1&0x80;l=b2&0x7f
        if l==126:l=struct.unpack(">H",rd(2))[0]
        elif l==127:l=struct.unpack(">Q",rd(8))[0]
        data+=rd(l)
        if fin:return json.loads(data)
i=0
def call(method,params=None):
    global i;i+=1;send({"id":i,"method":method,"params":params or {}})
    while True:
        m=recv()
        if m.get("id")==i:return m
def ev(expr):
    r=call("Runtime.evaluate",{"expression":expr,"awaitPromise":True,"returnByValue":True})
    return r.get("result",{}).get("result",{}).get("value",r)
