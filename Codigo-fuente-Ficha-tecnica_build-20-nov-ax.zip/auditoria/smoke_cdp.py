exec(open("/tmp/opencode/cdp.py").read())
import time,json
EV=[]
def call(method,params=None):
    global i;i+=1;send({"id":i,"method":method,"params":params or {}})
    while True:
        m=recv()
        if "method" in m: EV.append(m)
        if m.get("id")==i:return m
def drain(t=0.5):
    s.settimeout(t)
    try:
        while True:
            EV.append(recv())
    except Exception: pass
    s.settimeout(60)
s.settimeout(60)
call("Runtime.enable");call("Log.enable");call("Page.enable")
call("Page.reload",{"ignoreCache":True});time.sleep(6)
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});time.sleep(5)
R={}
def check(name,val,exp=True):
    R[name]=("OK" if val==exp else "FALLA (%r)"%(val,))
ev("document.getElementById('newProjectBtn').click()");time.sleep(1.2)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');set('newProjectSupplier','Prov');set('newProjectStyle','S1');set('newProjectSeason','V26');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(3)
check("hojas creadas",ev("__tdbg('PG.pages.length')"),7)
check("cada hoja con título, ficha y casilla de imagen",ev("(function(){var L=document.querySelector('.pg-layer');return window.__PG.pages.every(function(p){var id=p.v.id;return !!(L.querySelector('.pg-lab[data-pglab=\\''+id+'\\']')&&L.querySelector('.pg-spec[data-pgv=\\''+id+'\\']')&&L.querySelector('.pg-grid[data-pggrid=\\''+id+'\\'] .pg-cell-add'))})})()"))
# watchdog: remove a title and wait
ev("document.querySelector('.pg-lab[data-pglab=\"denim\"]:not(.is-cont)').remove()");time.sleep(5)
check("la mesa se autorrepara (título borrado)",ev("!!document.querySelector('.pg-lab[data-pglab=\"denim\"]:not(.is-cont)')"))
# ghost picture does not hide add-image
ev("""__tdbg(`(function(){var p=PG.pages.find(function(x){return x.v.id==="denim"});BOARD.objects.push({id:"ghost",type:"image",x:p.ox+300,y:200,w:0,h:0,src:"data:image/png;base64,AAAA"});pgLayerBuild(true)})()`)""")
check("imagen fantasma no oculta 'Añadir imagen'",ev("!!document.querySelector('.pg-grid[data-pggrid=denim] .pg-cell-add')"))
ev("__tdbg('BOARD.objects=BOARD.objects.filter(function(o){return o.id!==\"ghost\"});pgLayerBuild(true)')")
# markers
ev("""__tdbg(`(function(){var g=data[active][1];g.items=[];for(var i=0;i<9;i++){var it={name:"Título "+(i+1),optional:false,fields:[{label:"Descripción",value:"x",status:"pending",appliesTo:"all"},{label:"Detalle",value:"y",status:"pending",appliesTo:"all"}],userCreated:true,uid:"u"+i};it.boardObjId="t"+i;it.boardViewId="__pages__";g.items.push(it);BOARD.objects.push({id:"t"+i,type:"rect",x:1656+120+(i%5)*130,y:140+Math.floor(i/5)*250,w:100,h:160,sw:4,color:"#d64545"})}boardCommit();pgLayerBuild(true);boardRedraw()})()`)""");time.sleep(1)
check("9 apartados reparten en 3 páginas",ev("__tdbg('PG.pages.find(function(p){return p.v.id===\"sketch\"}).chunks')"),3)
check("numeración 1..9",ev("__tdbg('Object.keys(boardNumMapAll()).length')"),9)
ev("__tdbg('data[active][1].items[0].fields.forEach(function(f){f.status=\"ok\"});boardRedraw()')")
check("aprobado => verde",ev("__tdbg('boardEffColor(BOARD.objects.find(function(o){return o.id===\"t0\"}))')"),"#3aa655")
ev("__tdbg('pgSetZoomTool(true)')");check("cursor lupa",ev("__tdbg('getComputedStyle(BOARD.svg).cursor.indexOf(\"svg+xml\")>0')"));ev("__tdbg('pgSetZoomTool(false)')")
check("botón Vista A4 eliminado",not ev("!!document.getElementById('a4PreviewOpen')"))
check("zoom 100% estable",abs(ev("__tdbg('(function(){boardSetPct(100);return boardPct()})()')")-100)<0.5)
ev("__tdbg('pbA4Open()')")
for _ in range(40):
    time.sleep(1)
    if ev("!!document.querySelector('#pbA4 iframe')"):break
check("Vista A4 genera el PDF",ev("!!document.querySelector('#pbA4 iframe')"))
ev("document.querySelector('[data-pba4x]').click()")
ev("localStorage.clear()")
drain(1)
errs=[]
for m in EV:
    if m.get("method")=="Runtime.exceptionThrown":
        d=m["params"]["exceptionDetails"];errs.append("EXC "+(d.get("exception",{}).get("description") or d.get("text"))[:160])
    elif m.get("method")=="Runtime.consoleAPICalled" and m["params"]["type"]=="error":
        errs.append("console.error "+" ".join(str(a.get("value",a.get("description","")))[:100] for a in m["params"]["args"]))
    elif m.get("method")=="Log.entryAdded" and m["params"]["entry"]["level"]=="error":
        errs.append("log "+m["params"]["entry"]["text"][:140])
for k,v in R.items(): print(("✔" if v=="OK" else "✘"),k,"" if v=="OK" else v)
print("errores de consola:",len(errs))
for e in errs[:10]: print(" ",e)
