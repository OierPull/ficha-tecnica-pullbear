exec(open("auditoria/cdp.py").read())
import time,json
EV=[]
def call(method,params=None):
    global i;i+=1;send({"id":i,"method":method,"params":params or {}})
    while True:
        m=recv()
        if "method" in m: EV.append(m)
        if m.get("id")==i:return m
def pump(t=.5):
    s.settimeout(t)
    try:
        while True: EV.append(recv())
    except Exception: pass
    s.settimeout(90)
s.settimeout(90)
call("Page.enable");call("DOM.enable");call("Page.setInterceptFileChooserDialog",{"enabled":True})
call("Page.bringToFront")
call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(3)
def mouse(t,x,y,b=0):
    call("Input.dispatchMouseEvent",{"type":t,"x":x,"y":y,"button":"left","buttons":b,"clickCount":1})
def click_el(js):
    r=json.loads(ev("JSON.stringify((function(){var e=%s;if(!e)return null;var r=e.getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})())"%js))
    mouse("mouseMoved",r[0],r[1]);mouse("mousePressed",r[0],r[1],1);mouse("mouseReleased",r[0],r[1],0)
def choose(path):
    for _ in range(20):
        pump(.3)
        for m in EV:
            if m.get("method")=="Page.fileChooserOpened":
                EV.remove(m)
                call("DOM.setFileInputFiles",{"files":[path],"backendNodeId":m["params"]["backendNodeId"]});return True
        time.sleep(.2)
    return False
def state(pid):
    return json.loads(ev("""JSON.stringify((function(){var P=window.__PG,p=P.pages.find(function(q){return q.v.id==="%s"});return {grid:P.grid[p.v.id]&&[P.grid[p.v.id].c,P.grid[p.v.id].r],cellbtn:!!document.querySelector('.pg-grid[data-pggrid=%s] .pg-cell-add'),free:!!document.querySelector('.pg-grid[data-pggrid=%s].is-free')}})())"""%(pid,pid,pid)))
def pics(pid):
    return json.loads(ev("""JSON.stringify(__tdbg(`(function(){var p=PG.pages.find(function(q){return q.v.id==="%s"});return pgPicsOf(p,BOARD.objects).map(function(o){return [Math.round(o.x-p.ox),Math.round(o.y),Math.round(o.w),Math.round(o.h),o.cell,o.fit||""]})})()`))"""%pid))
# navigate to denim page: pan
def V(): return json.loads(ev("JSON.stringify(__tdbg('boardV()'))"))
def pan(pgx,tx=40,ty=130):
    for _ in range(8):
        v=V();dx=tx-pgx*v["k"]-v["ox"];dy=ty-v["oy"]
        if abs(dx)<2 and abs(dy)<2:break
        ev("__tdbg('BOARD.panX=BOARD.panX+%f;BOARD.panY=BOARD.panY+%f;boardRedraw();pgLayerPos()')"%(dx,dy))
pan(3312)
print("estado inicial",state("denim"))
click_el("document.querySelector('.pg-grid[data-pggrid=denim] .pg-cell-add')")
print("file chooser (cell)",choose("/tmp/opencode/img_a.png"));time.sleep(2)
print("1ª imagen (desde la casilla)",pics("denim"),state("denim"))
click_el("document.querySelector('.board-island [data-bupload]')||[].find.call(document.querySelectorAll('.board-island button'),function(b){return /imagen/i.test(b.title||b.getAttribute('aria-label')||'')})")
print("file chooser (barra)",choose("/tmp/opencode/img_b.png"));time.sleep(2)
print("2ª imagen (barra)",pics("denim"),state("denim"))
r=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/q1.png","wb").write(base64.b64decode(r["result"]["data"]))
