(function(){var out={};function add(t){t=(t||"").replace(/\s+/g," ").trim();if(t&&/[A-Za-zÁÉÍÓÚáéíóúñÑ]/.test(t))out[t]=1}
var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null);var n;while(n=w.nextNode()){var p=n.parentElement;if(!p||/^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName))continue;add(n.nodeValue)}
[].forEach.call(document.querySelectorAll("[title],[placeholder],[aria-label],[alt]"),function(e){["title","placeholder","aria-label","alt"].forEach(function(a){if(e.hasAttribute(a))add(e.getAttribute(a))})});
[].forEach.call(document.querySelectorAll("option"),function(o){add(o.textContent)});
return Object.keys(out)})()
