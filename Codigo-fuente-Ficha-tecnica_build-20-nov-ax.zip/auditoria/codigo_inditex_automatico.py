exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
ev("document.getElementById('addColorBtn').click()");time.sleep(1)
print("diálogo:",ev("!!document.getElementById('colorDialog')"))
# 1) typing HEX
r=json.loads(ev("JSON.stringify((function(){var d=document.querySelector('#colorDialog details.cd-adv');if(d)d.open=true;var e=document.querySelector('.cd-hextext');var b=e.getBoundingClientRect();return [b.left+b.width/2,b.top+b.height/2]})())"))
def st(): return ev("JSON.stringify([document.getElementById('cdPantone').value,document.getElementById('cdHint').textContent,document.querySelector(".cd-ind").hidden,document.getElementById('cdHex').value])")
for hx in ("#6B4A33","#FF0000","#123456"):
    mouse("mouseMoved",r[0],r[1]);mouse("mousePressed",r[0],r[1],1);mouse("mouseReleased",r[0],r[1],0)
    ev("document.querySelector('.cd-hextext').select()")
    call("Input.insertText",{"text":hx});time.sleep(.5)
    print("HEX",hx,"=>",st())
# 2) drag in the SV picker
rr=json.loads(ev("JSON.stringify((function(){var e=document.querySelector('.cd-sv');var b=e.getBoundingClientRect();return [b.left,b.top,b.width,b.height]})())"))
x0,y0=rr[0]+rr[2]*.2,rr[1]+rr[3]*.3
mouse("mouseMoved",x0,y0);mouse("mousePressed",x0,y0,1)
for k in range(1,6): mouse("mouseMoved",x0+rr[2]*.12*k,y0+rr[3]*.1*k,1);time.sleep(.1);print("  arrastre",k,json.loads(st())[:2])
mouse("mouseReleased",x0+rr[2]*.6,y0+rr[3]*.5,0)
# 3) submit: exact Inditex color used?
print("antes de guardar",st())
ev("document.querySelector('.cd-submit').click()");time.sleep(1)
print("colorOptions:",ev("JSON.stringify(__tdbg('colorOptions.map(function(c){return [c.name,c.pantone,c.hex]})'))"))
