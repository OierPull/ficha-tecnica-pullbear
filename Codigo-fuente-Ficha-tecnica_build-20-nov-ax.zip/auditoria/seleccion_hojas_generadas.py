exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(60)
call("Page.bringToFront")
call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');set('newProjectStyle','S1');set('newProjectSeason','V26');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(3)
ev("""__tdbg(`(function(){var g=data[active][1];g.items=[];for(var i=0;i<9;i++){var it={name:"Título "+(i+1),optional:false,fields:[{label:"Descripción",value:"x",status:"pending",appliesTo:"all"},{label:"Detalle",value:"y",status:"pending",appliesTo:"all"}],userCreated:true,uid:"u"+i};it.boardObjId="t"+i;it.boardViewId="__pages__";g.items.push(it);BOARD.objects.push({id:"t"+i,type:"rect",x:1656+120+(i%5)*130,y:140+Math.floor(i/5)*250,w:100,h:160,sw:4,color:"#d64545"})}boardCommit();pgLayerBuild(true);boardRedraw();pgLayerBuild(true);boardRedraw()})()`)""");time.sleep(1)
def V(): return json.loads(ev("JSON.stringify(__tdbg('boardV()'))"))
def pan(tx,ty,pgx=1656):
    for _ in range(8):
        v=V();dx=tx-pgx*v["k"]-v["ox"];dy=ty-v["oy"]
        if abs(dx)<2 and abs(dy)<2:break
        ev("__tdbg('BOARD.panX=BOARD.panX+%f;BOARD.panY=BOARD.panY+%f;boardRedraw();pgLayerPos()')"%(dx,dy))
def mouse(t,x,y,b=0):
    call("Input.dispatchMouseEvent",{"type":t,"x":x,"y":y,"button":"left","buttons":b,"clickCount":1})
def click(x,y):
    mouse("mouseMoved",x,y);mouse("mousePressed",x,y,1);mouse("mouseReleased",x,y,0);time.sleep(.5)
def info():
    return json.loads(ev("""JSON.stringify((function(){var b=document.querySelector('.board-ctxbar'),ov=document.querySelector('.board-ov'),r=b&&!b.hidden?b.getBoundingClientRect():null,hs=ov&&ov.querySelector('[data-h=nw]'),h=hs?hs.getBoundingClientRect():null;return {bar:r&&[Math.round(r.left),Math.round(r.top),Math.round(r.width)],handleNW:h&&[Math.round(h.left),Math.round(h.top)],bar_hidden:!b||b.hidden}})())"""))
def target(idx,ci):
    return json.loads(ev("JSON.stringify(__tdbg('(function(){var o=BOARD.objects.find(function(o){return o.id===\"t%d\"});var v=boardV(),r=BOARD.host.getBoundingClientRect();var off=%d*(PG.SHW+PG.VG);return {x:r.left+v.ox+(o.x+off)*v.k,y:r.top+v.oy+(o.y+o.h/2)*v.k,w:o.w*v.k,left:r.left+v.ox+(o.x+off)*v.k}})()'))"%(idx,ci)))
pan(40,130)
res=[]
for (idx,ci,label) in [(1,0,"pág1"),(5,1,"pág2"),(8,2,"pág3 (mirror)")]:
    t=target(idx,ci)
    click(t["x"],t["y"])
    inf=info()
    res.append(1)
    print(label,"click x=%.0f"%t["x"],inf)

# page 3
pan(40,130,pgx=1656+2*(1536+96))
t=target(8,2);click(t["x"],t["y"]);print("pág3 real",t["x"],info())
pan(40,130,pgx=1656+1*(1536+96))
t=target(6,1);click(t["x"],t["y"]);print("pág2 sel t6",info())
ev("document.querySelector('.board-ctxbar [data-bcolorpop]').click()");time.sleep(.4)
cp=json.loads(ev("JSON.stringify((function(){var p=document.querySelector('.board-colorpop'),b=document.querySelector('.board-ctxbar [data-bcolorpop]'),pr=p&&p.getBoundingClientRect(),br=b.getBoundingClientRect();return {pop:pr&&[Math.round(pr.left),Math.round(pr.top),Math.round(pr.width)],btn:[Math.round(br.left),Math.round(br.top)]}})())"))
print("colorpop",cp)
ev("document.querySelector('[data-bcp-more]').click()");time.sleep(.4)
ip=json.loads(ev("JSON.stringify((function(){var p=document.querySelector('.board-indpop'),b=document.querySelector('.board-ctxbar [data-bcolorpop]'),pr=p&&p.getBoundingClientRect(),br=b.getBoundingClientRect();return {pop:pr&&[Math.round(pr.left),Math.round(pr.top),Math.round(pr.width)],btn:[Math.round(br.left),Math.round(br.top)]}})())"))
print("indpop",ip)
r=call("Page.captureScreenshot",{"format":"png","clip":{"x":0,"y":0,"width":1300,"height":900,"scale":.7}});open("/tmp/opencode/g2.png","wb").write(base64.b64decode(r["result"]["data"]))
