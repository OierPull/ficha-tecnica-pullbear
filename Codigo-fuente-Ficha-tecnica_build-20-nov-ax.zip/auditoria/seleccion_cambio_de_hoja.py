exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(90)
call("Page.bringToFront")
call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(3)
ev("""__tdbg(`(function(){var g=data[active][1];g.items=[];for(var i=0;i<9;i++){var it={name:"Título "+(i+1),optional:false,fields:[{label:"Descripción",value:"x",status:"pending",appliesTo:"all"},{label:"Detalle",value:"y",status:"pending",appliesTo:"all"}],userCreated:true,uid:"u"+i};it.boardObjId="t"+i;it.boardViewId="__pages__";g.items.push(it);BOARD.objects.push({id:"t"+i,type:"rect",x:1656+120+(i%5)*130,y:140+Math.floor(i/5)*250,w:100,h:160,sw:4,color:"#d64545"})}boardCommit();pgLayerBuild(true);boardRedraw();pgLayerBuild(true);boardRedraw()})()`)""");time.sleep(1)
def V(): return json.loads(ev("JSON.stringify(__tdbg('boardV()'))"))
def pan(tx,ty,pgx=1656):
    for _ in range(8):
        v=V();dx=tx-pgx*v["k"]-v["ox"];dy=ty-v["oy"]
        if abs(dx)<2 and abs(dy)<2:break
        ev("__tdbg('BOARD.panX=BOARD.panX+%f;BOARD.panY=BOARD.panY+%f;boardRedraw();pgLayerPos()')"%(dx,dy))
def mouse(t,x,y,b=0):
    call("Input.dispatchMouseEvent",{"type":t,"x":x,"y":y,"button":"left","buttons":b,"clickCount":1})
def click(x,y):
    mouse("mouseMoved",x,y);mouse("mousePressed",x,y,1);mouse("mouseReleased",x,y,0);time.sleep(.5)
def target(idx,ci):
    return json.loads(ev("JSON.stringify(__tdbg('(function(){var o=BOARD.objects.find(function(o){return o.id===\"t%d\"});var v=boardV(),r=BOARD.host.getBoundingClientRect();var off=%d*(PG.SHW+PG.VG);return {x:r.left+v.ox+(o.x+off)*v.k,y:r.top+v.oy+(o.y+o.h/2)*v.k}})()'))"%(idx,ci)))
def sel(): return ev("JSON.stringify(__tdbg('[BOARD.sel,PG.selPtr&&PG.selPtr.off,PG.focus]'))")
pan(40,130)
t=target(6,1);click(t["x"],t["y"]);print("click 7 (pág2) ->",sel())
t=target(3,0);print("pos 4",t);click(t["x"],t["y"]);print("click 4 (pág1) ->",sel())

t=target(0,0);click(t["x"],t["y"]);print("sel t0 pág1",sel())
t=target(5,1);click(t["x"],t["y"]);print("click t5 pág2 ->",sel())
t=target(7,1);click(t["x"],t["y"]);print("click t7 pág2 ->",sel())
t=target(1,0);click(t["x"],t["y"]);print("click t1 pág1 ->",sel())
# resize on page 2 via handle
t=target(6,1);click(t["x"],t["y"]);print("sel t6",sel())
hb=json.loads(ev("JSON.stringify((function(){var h=document.querySelector('.board-ov [data-h=se]').getBoundingClientRect();return [h.left+h.width/2,h.top+h.height/2]})())"))
before=ev("JSON.stringify(__tdbg('(function(){var o=BOARD.objects.find(function(o){return o.id===\"t6\"});return [o.w,o.h]})()'))")
mouse("mouseMoved",hb[0],hb[1]);mouse("mousePressed",hb[0],hb[1],1)
for k in range(1,6): mouse("mouseMoved",hb[0]+8*k,hb[1]+5*k,1)
mouse("mouseReleased",hb[0]+40,hb[1]+25,0);time.sleep(.5)
after=ev("JSON.stringify(__tdbg('(function(){var o=BOARD.objects.find(function(o){return o.id===\"t6\"});return [o.w,o.h]})()'))")
print("resize pág2",before,"->",after,sel())
print(ev("JSON.stringify(__tdbg('[!!document.querySelector(\".pg-spec[data-pgv=photo]\")&&getComputedStyle(document.querySelector(\".pg-spec[data-pgv=photo]\")).display]'))"))
