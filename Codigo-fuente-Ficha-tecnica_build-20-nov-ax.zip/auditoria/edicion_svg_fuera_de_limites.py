exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(90)
call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});time.sleep(5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(3)
def V(): return json.loads(ev("JSON.stringify(__tdbg('boardV()'))"))
def pan(pgx,tx=40,ty=200):
    for _ in range(8):
        v=V();dx=tx-pgx*v["k"]-v["ox"];dy=ty-v["oy"]
        if abs(dx)<2 and abs(dy)<2:break
        ev("__tdbg('BOARD.panX=BOARD.panX+%f;BOARD.panY=BOARD.panY+%f;boardRedraw();pgLayerPos()')"%(dx,dy))
pan(3312)
def mouse(t,x,y,b=0):
    call("Input.dispatchMouseEvent",{"type":t,"x":x,"y":y,"button":"left","buttons":b,"clickCount":1})
VARS={
 "overflow:hidden inline":'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300" style="overflow:hidden"><path d="M60 240 L150 70 L240 240" fill="none" stroke="#000" stroke-width="10"/></svg>',
 "clipPath (Illustrator)":'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300"><defs><clipPath id="c"><rect width="300" height="300"/></clipPath></defs><g clip-path="url(#c)"><path d="M60 240 L150 70 L240 240" fill="none" stroke="#000" stroke-width="10"/></g></svg>',
 "grupo con transform":'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300"><g transform="translate(20 10) scale(.8)"><path d="M60 240 L150 70 L240 240" fill="none" stroke="#000" stroke-width="10"/></g></svg>',
 "triángulo cerrado (polygon)":'<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300"><polygon points="60,240 150,70 240,240" fill="#ccc" stroke="#000" stroke-width="8"/></svg>',
}
for name,svg in VARS.items():
    ev("__tdbg('BOARD.objects=BOARD.objects.filter(function(o){return o.type!==\"image\"});if(SVGE)boardSvgEditEnd();boardRedraw()')")
    ev("__tdbg(%s)"%json.dumps("boardAddSvgVector(%s,{x:3312+500,y:350},0)"%json.dumps(svg)));time.sleep(.8)
    ev("""__tdbg(`(function(){var o=BOARD.objects[BOARD.objects.length-1];boardSvgEditStart(o);var el=SVGE.svg.querySelector("path,polygon");svgpStart(el)})()`)""");time.sleep(.6)
    an=json.loads(ev("JSON.stringify([].map.call(document.querySelectorAll('.svgp-ov circle.svgp-a'),function(e){var r=e.getBoundingClientRect();return [Math.round(r.left+r.width/2),Math.round(r.top+r.height/2)]}))"))
    if len(an)<2: print(name,"sin anclas",an);continue
    apex=min(an,key=lambda p:p[1]);x,y=apex
    mouse("mouseMoved",x,y);mouse("mousePressed",x,y,1)
    for k in range(1,11): mouse("mouseMoved",x+22*k,y-18*k,1)
    mouse("mouseReleased",x+220,y-180,0);time.sleep(.5)
    st=json.loads(ev("""JSON.stringify((function(){var el=document.querySelector('.svge svg path, .svge svg polygon');var r=el.getBoundingClientRect();var an=[].map.call(document.querySelectorAll('.svgp-ov circle.svgp-a'),function(e){var q=e.getBoundingClientRect();return [Math.round(q.left+q.width/2),Math.round(q.top+q.height/2)]});var vis=document.elementsFromPoint(an[0][0]+5,an[0][1]+5).length;var cs=getComputedStyle(document.querySelector('.svge svg'));return {bbox:[Math.round(r.left),Math.round(r.top),Math.round(r.width),Math.round(r.height)],anchors:an,overflow:cs.overflow,svgInline:document.querySelector('.svge svg').getAttribute('style')}})())"""))
    print(name,"->",st)
    r=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/v5_%s.png"%name.split()[0].replace(":",""),"wb").write(base64.b64decode(r["result"]["data"]))
