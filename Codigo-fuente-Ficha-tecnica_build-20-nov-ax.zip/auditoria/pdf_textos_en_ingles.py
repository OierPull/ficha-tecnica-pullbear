exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(120)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
EV=[]
def call(method,params=None):
    global i;i+=1;send({"id":i,"method":method,"params":params or {}})
    while True:
        m=recv()
        if "method" in m: EV.append(m)
        if m.get("id")==i:return m
call("Runtime.enable")
ev("localStorage.clear();localStorage.setItem('pb-lang','en')");call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(4)
ev("document.getElementById('versionCompareDemo').click()");time.sleep(3)
ev("window.__pt=[];var _dt=PDFLib.PDFPage.prototype.drawText;PDFLib.PDFPage.prototype.drawText=function(t){window.__pt.push(String(t));return _dt.apply(this,arguments)}")
ev("document.getElementById('a4PreviewOpen').click()")
for _ in range(60):
    time.sleep(.5)
    if ev("!!document.querySelector('#pbA4 iframe')"):break
time.sleep(4)
def shot(n):
    r=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/%s.png"%n,"wb").write(base64.b64decode(r["result"]["data"]))
shot("en5a")
print(ev("JSON.stringify(Array.from(new Set(window.__pt)))"))
for m in EV:
    if m.get("method")=="Runtime.exceptionThrown":print("EXC",m["params"]["exceptionDetails"].get("exception",{}).get("description","")[:300])
