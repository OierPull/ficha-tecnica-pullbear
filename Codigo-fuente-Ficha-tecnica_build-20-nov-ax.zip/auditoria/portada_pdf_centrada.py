exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
print(ev("JSON.stringify(__tdbg('PG.pages.map(function(p){return [p.v.id,p.v.label,Math.round(p.ox),(p.v.relatedSections||[]).map(function(i){return data[active][i].name})]})'))"))
ev("""__tdbg(`(function(){var p=PG.pages[0];var c=document.createElement("canvas");c.width=400;c.height=500;var x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,400,500);x.fillStyle="#6b4a32";x.fillRect(60,40,280,420);var src=c.toDataURL();BOARD.objects.push({id:"im",type:"image",x:p.ox+120,y:80,w:300,h:375,src:src,fit:"free"});boardCommit()})()`)""");time.sleep(1.5)
ev("document.getElementById('a4PreviewOpen').click()")
for _ in range(40):
    time.sleep(.5)
    if ev("!!document.querySelector('#pbA4 iframe')"):break
time.sleep(3)
r=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/z1a.png","wb").write(base64.b64decode(r["result"]["data"]))
