exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(90)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
call("Page.bringToFront")
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(1.5)
ev("""(function(){var set=(id,v)=>{var e=document.getElementById(id);e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}))};set('newProjectModel','TEST');document.querySelector('#newProjectModel').form.querySelector('[type=submit]').click()})()""");time.sleep(5)
def V(): return json.loads(ev("JSON.stringify(__tdbg('boardV()'))"))
def pan(pgx,tx=40,ty=200):
    for _ in range(8):
        v=V();dx=tx-pgx*v["k"]-v["ox"];dy=ty-v["oy"]
        if abs(dx)<2 and abs(dy)<2:break
        ev("__tdbg('BOARD.panX=BOARD.panX+%f;BOARD.panY=BOARD.panY+%f;boardRedraw();pgLayerPos()')"%(dx,dy))
pan(3312)
def mouse(t,x,y,b=0):
    call("Input.dispatchMouseEvent",{"type":t,"x":x,"y":y,"button":"left","buttons":b,"clickCount":1})
def click(x,y,n=1):
    mouse("mouseMoved",x,y)
    for c in range(n):
        call("Input.dispatchMouseEvent",{"type":"mousePressed","x":x,"y":y,"button":"left","buttons":1,"clickCount":c+1})
        call("Input.dispatchMouseEvent",{"type":"mouseReleased","x":x,"y":y,"button":"left","buttons":0,"clickCount":c+1})
    time.sleep(.5)
svg='''<svg width="236" height="199" viewBox="0 0 236 199" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_1_2)"><rect x="4" y="4" width="228" height="191" stroke="black" stroke-width="8"/><path d="M60 40 L172 52" stroke="black" stroke-width="8"/><path d="M118 85 L170 150 L66 150 Z" stroke="black" stroke-width="8"/></g><defs><clipPath id="clip0_1_2"><rect x="4" y="4" width="228" height="191" fill="white"/></clipPath></defs></svg>'''
print(ev("JSON.stringify(__tdbg(%s))"%json.dumps("boardAddSvgVector(%s,{x:3312+500,y:350},0)"%json.dumps(svg))));time.sleep(1)
ev("""__tdbg(`(function(){var o=BOARD.objects[BOARD.objects.length-1];boardSvgEditStart(o)})()`)""");time.sleep(.8)
def center(sel_js):
    return json.loads(ev("JSON.stringify((function(){var e=%s;var r=e.getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2,r.left,r.top,r.width,r.height]})())"%sel_js))
def shot(name):
    r=call("Page.captureScreenshot",{"format":"png","clip":{"x":0,"y":120,"width":1200,"height":560,"scale":1.3}});open("/tmp/opencode/%s.png"%name,"wb").write(base64.b64decode(r["result"]["data"]))
# select line
ln=center("document.querySelectorAll('.svge svg path')[0]");click(ln[0],ln[1]);time.sleep(.4);shot("y1_line")
print("sel:",ev("JSON.stringify(__tdbg('SVGE.sel.map(function(e){return e.tagName})'))"))
# select triangle by clicking its bottom edge
tr=center("document.querySelectorAll('.svge svg path')[1]");click(tr[0],tr[3]+tr[5]*0.95);time.sleep(.4);shot("y1_tri")
print("sel:",ev("JSON.stringify(__tdbg('SVGE.sel.map(function(e){return e.tagName})'))"))
# frame
fr=center("document.querySelector('.svge svg rect')");click(fr[2]+3,fr[3]+fr[5]/2);time.sleep(.4);shot("y1_frame")
print("sel:",ev("JSON.stringify(__tdbg('SVGE.sel.map(function(e){return e.tagName})'))"))
# triangle node edit and drag apex outside bbox
ev("""__tdbg(`(function(){var ps=SVGE.svg.querySelectorAll("path");SVGE.sel=[ps[1]];svgpStart(ps[1])})()`)""");time.sleep(.6)
an=json.loads(ev("JSON.stringify([].map.call(document.querySelectorAll('.svgp-ov circle.svgp-a'),function(e){var r=e.getBoundingClientRect();return [Math.round(r.left+r.width/2),Math.round(r.top+r.height/2)]}))"))
apex=min(an,key=lambda p:p[1]);x,y=apex
mouse("mouseMoved",x,y);mouse("mousePressed",x,y,1)
for k in range(1,9): mouse("mouseMoved",x+16*k,y-9*k,1)
mouse("mouseReleased",x+128,y-72,0);time.sleep(.5);shot("y1_apex")
print("clip-path restante en el editor:",ev("document.querySelectorAll('.svge svg [clip-path]').length"))
