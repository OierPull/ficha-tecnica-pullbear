exec(open("auditoria/atajos_z_p_v.py").read().split('print("inicio"')[0])
ev("__tdbg('boardSetPct(200)')");time.sleep(.5)
ev("__tdbg('(function(){var p=PG.pages[0],v=boardV();BOARD.panX+=200-(v.ox+p.ox*v.k);BOARD.panY+=160-v.oy;boardRedraw();pgLayerPos()})()')");time.sleep(.5)
v=json.loads(ev("JSON.stringify(__tdbg('(function(){var v=boardV(),r=BOARD.host.getBoundingClientRect(),p=PG.pages[0];return {top:r.top+v.oy,left:r.left+v.ox+p.ox*v.k,k:v.k,w:PG.SHW*v.k}})()'))"))
print(v)
yt=v["top"];x0=v["left"]+300
key("p");time.sleep(.2)
for (x,y) in ((x0,yt+7),(x0+250,yt+7)):
    mouse("mouseMoved",x,y);mouse("mousePressed",x,y,1);mouse("mouseReleased",x,y,0);time.sleep(.2)
print("pts:",ev("__tdbg('PG.pen?PG.pen.pts.length:0')"))
key("v");time.sleep(.6);mouse("mouseMoved",x0+100,yt+200);mouse("mousePressed",x0+100,yt+200,1);mouse("mouseReleased",x0+100,yt+200,0);time.sleep(.4)
print(ev("JSON.stringify(__tdbg('BOARD.objects.filter(function(o){return o.pen}).map(function(o){return [o.x,o.y,o.w,o.h]})'))"))
r=call("Page.captureScreenshot",{"format":"png","clip":{"x":x0-120,"y":yt-30,"width":420,"height":110,"scale":3}});open("/tmp/opencode/ln7.png","wb").write(base64.b64decode(r["result"]["data"]))
