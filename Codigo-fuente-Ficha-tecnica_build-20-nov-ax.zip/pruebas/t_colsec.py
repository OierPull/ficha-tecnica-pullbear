# Apartado plegado: franja fina, sin «N bloques · pulsa para mostrar»
import os
os.environ['NOLEGACY']='1'
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'colsec',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(1800)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','COLSEC'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(2300)
    tg=pg.locator('#sections .section-toggle').first; tg.click(); pg.wait_for_timeout(500)
    h=pg.locator('#sections .section').first.bounding_box()['height']
    r.add('Plegado, el apartado es una franja fina (≤ 44 px)',h<=44,h)
    r.add('Sin el texto «N bloques · pulsa para mostrar»',pg.locator('#sections .section-sum:visible').count()==0,'')
    r.add('Plegado oculta sus bloques',pg.locator('#sections .section').first.locator('.item').count()==0,'')
    pg.locator('#sections .section-toggle').first.click(); pg.wait_for_timeout(500)
    r.add('Pulsar la franja lo vuelve a abrir con sus bloques',pg.locator('#sections .section').first.locator('.item').count()>=1,'')
    r.add('Consola sin errores',not [l for l in lg if 'error' in str(l).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
