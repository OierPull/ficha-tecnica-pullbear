# Cambiar de página y de color sin hojas en blanco ni bloqueos; cada hoja de continuación funciona como una hoja
import os
from h import *
from PIL import Image
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def ink(pg,rect,tag):
    pg.screenshot(path='audit/sw_%s.png'%tag); im=Image.open('audit/sw_%s.png'%tag).convert('L'); x0,y0,x1,y1=[int(v) for v in rect]
    x0=max(0,x0);y0=max(0,y0);x1=min(im.size[0]-1,x1);y1=min(im.size[1]-1,y1); n=0
    for x in range(x0,x1,3):
        for y in range(y0,y1,3):
            if im.getpixel((x,y))<170: n+=1
    return n
SHEET="([id,ci,row])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();const pitch=P.SHH+(P.ROWG||0);const el=document.querySelector('.pg-rowhit[data-pgv=\"'+id+'\"][data-ci=\"'+ci+'\"]');if(el&&row){const b=el.getBoundingClientRect();return [b.left,b.top,b.right,b.bottom]}const x=hr.left+v.ox+(p.ox+ci*(P.SHW+P.VG))*v.k,y=hr.top+v.oy;return [x,y,x+P.SHW*v.k,y+P.SHH*v.k]}"
with sync_playwright() as p:
    ctx=launch(p,'sw',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Switch'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('19-4052'); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
    sk=pg.evaluate("window.__PG.pages.find(x=>x.i===1).v.id"); fa=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id")
    go=lambda i:(pg.evaluate("id=>document.querySelector('.pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",i),pg.wait_for_timeout(1300))
    for vid in (sk,fa):
        go(vid); pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500); empty_click(pg); pg.wait_for_timeout(300)
    go(sk); card='.pg-spec[data-pgv="%s"]:not(.is-preview)'%sk
    for _ in range(7): pg.locator(card+' .pgs-addb').last.click(); pg.wait_for_timeout(450)
    pg.wait_for_timeout(800)
    # segundo color duplicando el primero: misma mesa, fila de abajo
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('18-1664')
    if pg.locator('[data-cdmode="dup"]').count(): pg.locator('[data-cdmode="dup"]').first.click()
    pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(2500)
    pg.mouse.move(720,450)
    for _ in range(4): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(900)
    first=pg.evaluate("window.__PG&&[...document.querySelectorAll('.pg-rowlab')].map(l=>l.dataset.pgrow)[0]")
    nh=pg.evaluate("id=>document.querySelectorAll('.pg-rowhit[data-pgv=\"'+id+'\"]').length",sk); ch=pg.evaluate("id=>window.__PG.pages.find(x=>x.v.id===id).chunks",sk)
    r.add('La fila del otro color tiene una zona de pulsación por hoja (no una para todo el conjunto)',ch>=2 and nh==ch,(nh,ch))
    hs=[pg.evaluate("(id)=>{const e=document.querySelector('.pg-rowhit[data-pgv=\"'+id+'\"][data-ci=\"'+%d+'\"]');const b=e.getBoundingClientRect();return Math.round(b.width)}"%ci,sk) for ci in range(ch)]
    sw=pg.evaluate("Math.round(window.__PG.SHW*window.__pgV().k)")
    r.add('…y cada zona mide lo que una hoja',all(abs(h-sw)<=2 for h in hs),(hs,sw))
    # la fila del otro color: hoja 1 y hoja 2 de Sketch, y Fabric, con su dibujo (no en blanco)
    rk1=pg.evaluate(SHEET,[sk,0,1]); rk2=pg.evaluate(SHEET,[sk,1,1]); rf=pg.evaluate(SHEET,[fa,0,1])
    i1=ink(pg,[rk1[0],rk1[1],rk1[0]+(rk1[2]-rk1[0])*0.62,rk1[3]],'a'); i2=ink(pg,[rk2[0],rk2[1],rk2[0]+(rk2[2]-rk2[0])*0.62,rk2[3]],'b'); i3=ink(pg,[rf[0],rf[1],rf[0]+(rf[2]-rf[0])*0.62,rf[3]],'c')
    r.add('Fila del otro color: Sketch hoja 1, hoja 2 (con la ilustración) y Fabric salen con su dibujo',i1>30 and i2>30 and i3>30,(i1,i2,i3))
    # cambiar de página en la fila activa y activar la otra fila: sin tareas largas
    pg.evaluate("window.__lt=[];new PerformanceObserver(l=>l.getEntries().forEach(e=>window.__lt.push(Math.round(e.duration)))).observe({entryTypes:['longtask']})")
    go(fa); pg.wait_for_timeout(600)
    lt1=pg.evaluate("window.__lt.slice()"); pg.evaluate("window.__lt=[]")
    b=pg.locator('.pg-rowhit[data-pgv="%s"][data-ci="0"]'%fa).first.bounding_box(); pg.mouse.click(b['x']+b['width']/2,b['y']+b['height']/2); pg.wait_for_timeout(1800)
    lt2=pg.evaluate("window.__lt.slice()")
    r.add('Cambiar de página: sin bloqueos largos del navegador (ninguna tarea > 200 ms)',max(lt1 or [0])<200,lt1)
    r.add('Activar el otro color: sin bloqueos largos (ninguna tarea > 250 ms)',max(lt2 or [0])<250,lt2)
    pg.wait_for_timeout(600)
    rk1=pg.evaluate(SHEET,[sk,0,1]); rf=pg.evaluate(SHEET,[fa,0,1])
    j1=ink(pg,[rk1[0],rk1[1],rk1[0]+(rk1[2]-rk1[0])*0.62,rk1[3]],'d'); j3=ink(pg,[rf[0],rf[1],rf[0]+(rf[2]-rf[0])*0.62,rf[3]],'e')
    r.add('Tras cambiar de color, las hojas de la otra fila siguen con su dibujo (no se quedan en blanco)',j1>30 and j3>30,(j1,j3))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
