# FALLO CONOCIDO (también en la 16-nov-v): al dibujar en un color, el texto del otro deja de verse. No forma parte de la batería.
from h import *
def vals(pg,sel): return pg.evaluate("s=>[...document.querySelectorAll(s)].map(e=>e.value)",sel)
with sync_playwright() as p:
    ctx=launch(p,'d277',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(BASE+'modified.html'); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','E'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600); pg.locator('#cdPantone').fill('19-4052'); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1900)
    fa=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id"); did=pg.evaluate("window.__PG.pages.find(x=>x.i===0).v.id")
    pg.locator('.pg-lab[data-pglab="%s"] [data-pgnav="%s"]'%(did,fa)).evaluate('e=>e.click()'); pg.wait_for_timeout(1300)
    L='.pg-spec[data-pgv="%s"]:not(.is-preview) textarea'%fa; PV='.pg-spec.is-preview[data-pgv="%s"] textarea'%fa
    t=pg.locator(L).first; t.click(); t.fill('DEN-A'); empty_click(pg); pg.wait_for_timeout(500)
    def draw(x0,y0,x1,y1):
        pg.locator('[data-btool="rect"]').click(); a=pg.evaluate("([id,a,b,c,d])=>{const P=window.__PG,p=P.pages.find(q=>q.v.id===id),r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV();return [r.left+v.ox+(p.ox+a)*v.k,r.top+v.oy+b*v.k,r.left+v.ox+(p.ox+c)*v.k,r.top+v.oy+d*v.k]}",[fa,x0,y0,x1,y1])
        pg.mouse.move(a[0],a[1]); pg.mouse.down(); pg.mouse.move(a[2],a[3],steps=6); pg.mouse.up(); pg.wait_for_timeout(900); empty_click(pg); pg.wait_for_timeout(300)
    draw(300,250,560,420); print('X tras dibujar:',vals(pg,L))
    pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600); pg.locator('#cdPantone').fill('18-1664'); pg.locator('form.color-dialog .pb-copt[data-pbcopt="empty"]').click(); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1900)
    print('Y activo (vivo):',vals(pg,L),'| X (previa):',vals(pg,PV))
    draw(700,300,900,450); print('Y tras dibujar (vivo):',vals(pg,L),'| X (previa):',vals(pg,PV)); ctx.close()
