# Feedback de usuarios: atajos de Illustrator, flecha de un solo uso, borrar hoja sin saltar, PDF con hoja de cambios opcional y pie limpio
import os,glob,subprocess
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'fb',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','FB'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('19-4052'); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1500)
    Z=lambda:pg.evaluate("window.__BOARD.zoom"); T=lambda:pg.evaluate("window.__BOARD.tool")
    pg.mouse.move(700,450); z0=Z(); pg.keyboard.down('z'); pg.wait_for_timeout(150); pg.mouse.click(700,450); pg.wait_for_timeout(250); z1=Z()
    pg.keyboard.down('Alt'); pg.mouse.click(700,450); pg.keyboard.up('Alt'); pg.wait_for_timeout(250); z2=Z(); pg.keyboard.up('z'); pg.wait_for_timeout(100)
    r.add('Z + clic acerca y Alt + clic aleja (como en Illustrator)',z1>z0*1.3 and abs(z2-z0)<z0*0.05,(round(z0,3),round(z1,3),round(z2,3)))
    pg.keyboard.press('v'); pg.wait_for_timeout(100)
    pg.keyboard.press('Control+='); pg.wait_for_timeout(200); a=Z(); pg.keyboard.press('Control+-'); pg.wait_for_timeout(200); b=Z()
    r.add('Cmd/Ctrl + «+» y «−» acercan y alejan',a>z2*1.15 and abs(b-z2)<z2*0.05,(round(z2,3),round(a,3),round(b,3)))
    tools=[]
    for key,exp in (('m','rect'),('l','ellipse'),('t','text'),('h','hand'),('v','select')):
        pg.keyboard.press(key); pg.wait_for_timeout(120); tools.append((key,T()==exp))
    r.add('M, L, T, H y V eligen rectángulo, elipse, texto, mano y selección',all(x for _,x in tools),tools)
    sk=pg.evaluate("window.__PG.pages[1].v.id")
    W="([id,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    pg.locator('[data-btool="arrow"]').click(); pg.wait_for_timeout(200)
    a1=pg.evaluate(W,[sk,200,200]); a2=pg.evaluate(W,[sk,420,330]); pg.mouse.click(*a1); pg.wait_for_timeout(200); pg.mouse.click(*a2); pg.wait_for_timeout(500); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    na=pg.evaluate("window.__BOARD.objects.filter(o=>o.type==='arrow').length")
    r.add('Tras poner una flecha se vuelve a selección (no obliga a poner más)',na==1 and T()!='arrow',(na,T()))
    # borrar una hoja sin saltar a la primera
    pg.evaluate("id=>{const b=document.querySelector('.pg-gapadd[data-after=\"'+id+'\"]');b.click()}",sk); pg.wait_for_timeout(1500); pg.fill('#tabPopName','Borrar'); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(2800)
    nb=pg.evaluate("window.__PG.pages.find(p=>p.name==='Borrar').v.id")
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",nb); pg.wait_for_timeout(1300)
    zb=Z(); n0=pg.evaluate("window.__PG.pages.length")
    pg.locator('.pg-lab[data-pglab="%s"]:not(.is-cont) [data-pgdelpage]'%nb).evaluate("e=>{e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));e.click()}"); pg.wait_for_timeout(600)
    cf=pg.locator('.ui-confirm button.ui-btn-primary, .ui-confirm [data-ok], [role=dialog] button:has-text(\"Eliminar\")')
    if cf.count(): cf.first.click()
    pg.wait_for_timeout(1800)
    za=Z(); foc=pg.evaluate("(()=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===P.focus);return p&&p.name})()")
    r.add('Al eliminar una hoja se mantiene el zoom y se queda en la anterior (no salta a la primera)',pg.evaluate("window.__PG.pages.length")==n0-1 and abs(za-zb)<zb*0.02 and foc=='Sketch',(n0,pg.evaluate("window.__PG.pages.length"),round(zb,3),round(za,3),foc))
    # PDF
    pg.evaluate("window.__PG&&(window.__PG.pdfOk=true)"); pg.locator('#pdfExportOpen').click(); pg.wait_for_timeout(900)
    ic=pg.evaluate("(()=>{const i=document.getElementById('pdfIncludeChanges'),l=i.closest('label');return [i.checked,!!l&&l.offsetParent!==null,(l&&l.textContent||'').trim()]})()")
    r.add('El diálogo ofrece «Incluir hoja de cambios», desactivada por defecto',ic[0] is False and ic[1] and 'cambios' in ic[2],ic)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    if pg.locator('#pdfExportClose').is_visible(): pg.locator('#pdfExportClose').click(); pg.wait_for_timeout(300)
    [os.remove(x) for x in glob.glob('pdfs/fb__*.pdf')]
    got=export_pdf(pg,'fb',wait=60)
    if got:
        txt=subprocess.run(['pdftotext','-layout',got[0][1],'-'],capture_output=True,text=True).stdout
        r.add('Pie del PDF: solo el número de página (sin «Pull&Bear · Ficha técnica»)','Página 1 de' in txt and 'Pull&Bear · Ficha técnica' not in txt and 'Pull&Bear  Ficha técnica' not in txt,txt[-200:].replace('\n',' | '))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
