# Estado: solo «Aprobado» y «Pendiente»; lo que estaba «Rechazado» pasa a «Pendiente»
import os
os.environ['NOLEGACY']='1'
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def tabstate(pg,name): return pg.evaluate("(n=>{const c=[...document.querySelectorAll('#visualGallery > .gallery-card')].find(c=>c.querySelector('.tab-name').textContent.trim()===n);return c?c.querySelector('.gallery-state').className:null})",name)
with sync_playwright() as p:
    ctx=launch(p,'norej',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(1800)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','NOREJ'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(2300)
    select_thumb(pg,thumb(pg,'Linning')); pg.wait_for_timeout(500)
    pg.locator('#sections .approval-chip').first.click(force=True); pg.wait_for_timeout(300)
    opts=pg.evaluate("[...document.querySelectorAll('.approval-menu:not([hidden]) [data-apply-status]')].filter(b=>getComputedStyle(b).display!=='none').map(b=>b.textContent.trim())")
    r.add('El menú de estado solo ofrece «Aprobado» y «Pendiente»',opts==['Aprobado','Pendiente'],opts)
    pg.locator('.approval-menu:not([hidden]) [data-apply-status="ok"]').first.click(); pg.wait_for_timeout(900)
    r.add('Aprobar sigue funcionando',('state-ok' in (tabstate(pg,'Linning') or '')),tabstate(pg,'Linning'))
    n=pg.evaluate("(()=>{let n=0;for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i),v=localStorage.getItem(k);if(v&&v.indexOf('\"status\":\"ok\"')>=0&&k.indexOf('version-meta')<0){localStorage.setItem(k,v.split('\"status\":\"ok\"').join('\"status\":\"rejected\"'));n++}}return n})()")
    r.add('(preparación) se simula una ficha antigua con el apartado «Rechazado»',n>0,n)
    pg.reload(); pg.wait_for_timeout(2600)
    if not pg.locator('#visualGallery').is_visible(): pg.locator('#projectGrid .project-card').first.click(); pg.wait_for_timeout(2400)
    st=tabstate(pg,'Linning'); r.add('Al abrir, lo rechazado aparece como pendiente (sin rojo)',st and 'state-rejected' not in st and 'state-pending' in st,st)
    left=pg.evaluate("(()=>{let n=0;for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i),v=localStorage.getItem(k);if(k.indexOf('version-meta')<0&&v&&v.indexOf('\"status\":\"rejected\"')>=0)n++}return n})()")
    r.add('…y queda guardado como pendiente (no queda ningún «rechazado»)',left==0,left)
    r.add('Ningún icono rojo de rechazado en las pestañas',pg.locator('#visualGallery .gallery-state.state-rejected').count()==0,'')
    r.add('Consola sin errores',not [l for l in lg if 'error' in str(l).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
