# Los textos de cada color son independientes (escribir en uno no cambia los otros)
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
FIND=r"""(sel,l)=>{const f=[...document.querySelectorAll(sel+' .pgs-f')].find(f=>{const e=f.querySelector('.pgs-lab');return e&&(e.value||e.firstChild.textContent).trim().normalize('NFC')===l.normalize('NFC')});return f?f.querySelector('textarea'):null}"""
TYP="([sel,l,v])=>{const t=("+FIND+")(sel,l);if(!t)return 'NO';t.focus();t.value=v;t.dispatchEvent(new Event('input',{bubbles:true}));t.dispatchEvent(new Event('change',{bubbles:true}));t.blur();return 'OK'}"
GET="([sel,l])=>{const t=("+FIND+")(sel,l);return t?t.value:null}"
def live(pid): return '.pg-spec[data-pgv="%s"]:not(.is-preview)'%pid
def prv(cid,pid): return '.pg-spec.is-preview[data-pgrow="%s"][data-pgv="%s"]'%(cid,pid)
def addcolor(pg,code):
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(code); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1900)
with sync_playwright() as p:
    ctx=launch(p,'indepf',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Indep'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    addcolor(pg,'19-4052'); addcolor(pg,'18-1664')
    d0=pg.evaluate("window.__PG.pages.find(x=>x.i===0).v.id"); fa=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id")
    cols=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].map(l=>[l.getAttribute('data-pgrow'),l.classList.contains('is-on')])")
    act=[c for c,on in cols if on][0]; other=[c for c,on in cols if not on][0]
    print('typ',pg.evaluate(TYP,[live(d0),'Patrón','HHA'])); pg.wait_for_timeout(1500)
    pg.evaluate("id=>document.querySelector('.pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",fa); pg.wait_for_timeout(1300)
    print('LABS',pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-f .pgs-lab')].map(e=>JSON.stringify(e.value||e.textContent))",live(fa)))
    print('typ',pg.evaluate(TYP,[live(fa),'Acabado','Lavado A'])); pg.wait_for_timeout(1500)
    r.add('Escribir en «Patrón» de un color no lo escribe en el otro',pg.evaluate(GET,[prv(other,d0),'Patrón'])=='',pg.evaluate(GET,[prv(other,d0),'Patrón']))
    r.add('Escribir en «Acabado» de un color no lo escribe en el otro',pg.evaluate(GET,[prv(other,fa),'Acabado']) in ('',None),pg.evaluate(GET,[prv(other,fa),'Acabado']))
    pg.evaluate("c=>document.querySelector('.pg-rowhit[data-pgrow=\"'+c+'\"]').click()",other); pg.wait_for_timeout(1700)
    r.add('Al activar el otro color, su «Patrón» sigue vacío',pg.evaluate(GET,[live(d0),'Patrón'])=='',pg.evaluate(GET,[live(d0),'Patrón']))
    r.add('Al activar el otro color, su «Acabado» sigue vacío',pg.evaluate(GET,[live(fa),'Acabado'])=='',pg.evaluate(GET,[live(fa),'Acabado']))
    pg.evaluate(TYP,[live(fa),'Acabado','Lavado B']); pg.wait_for_timeout(1200)
    r.add('…y lo que escribes en él no cambia el primero',pg.evaluate(GET,[prv(act,fa),'Acabado'])=='Lavado A',pg.evaluate(GET,[prv(act,fa),'Acabado']))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
