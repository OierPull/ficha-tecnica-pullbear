import os,glob
from h import *
import subprocess
from PIL import Image
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'clippdf',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Clip'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",str('2')); pg.wait_for_timeout(900)
    pid=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id")
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500)
    pg.locator('.pg-grid[data-pggrid="%s"] .pg-gbar-v'%pid).click(); pg.wait_for_timeout(800)
    o=pg.evaluate("id=>{const P=window.__PG,p=P.pages.find(q=>q.v.id===id),o=window.__BOARD.objects.find(x=>x.cell===0),r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV();return [r.left+v.ox+(o.x+o.w/2)*v.k,r.top+v.oy+(o.y+o.h/2)*v.k]}",pid)
    pg.mouse.click(*o); pg.wait_for_timeout(400); pg.evaluate("f=>{const g=document.querySelector('.board-ctxbar .pg-fitgrp');g&&g.classList.add('is-open');document.querySelector('.board-ctxbar [data-pgfit='+f+']').click()}",'height'); pg.wait_for_timeout(800); empty_click(pg); pg.wait_for_timeout(500)
    pg.evaluate("window.__PG.pdfOk=true"); [os.remove(x) for x in glob.glob('pdfs/clip__*.pdf')]
    got=export_pdf(pg,'clip',wait=60); ctx.close()
    r.add('PDF descargado',bool(got),got)
    if got:
        for f in glob.glob('audit/clipt-*.png'): os.remove(f)
        subprocess.run(['pdftoppm','-f','2','-l','2','-r','60','-png',got[0][1],'audit/clipt'])
        fs=sorted(glob.glob('audit/clipt-*.png')); im=Image.open(fs[0]).convert('RGB'); W,H=im.size
        a=im.getpixel((int(W*0.42),int(H*0.5))); b=im.getpixel((int(W*0.2),int(H*0.5)))
        r.add('En el PDF, la imagen ampliada no invade la casilla vecina',min(a)>=245,a)
        r.add('…y sí se ve dentro de su propia casilla',max(b)<200,b)
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
