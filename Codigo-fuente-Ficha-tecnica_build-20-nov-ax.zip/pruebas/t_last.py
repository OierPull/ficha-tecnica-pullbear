# Cambiar de página o de color sin reconstrucciones innecesarias; páginas ocultas; Interior; diálogo de color sencillo
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
OBS="""()=>{window.__rb=0;window.__lt=[];const L=document.querySelector('.pg-layer');window.__mo&&window.__mo.disconnect();window.__mo=new MutationObserver(ms=>{if(ms.some(m=>m.target===document.querySelector('.pg-layer')&&m.removedNodes.length>3))window.__rb++});window.__mo.observe(document.querySelector('.board-host'),{childList:true,subtree:true});try{new PerformanceObserver(l=>l.getEntries().forEach(e=>window.__lt.push(Math.round(e.duration)))).observe({entryTypes:['longtask']})}catch(e){}}"""
with sync_playwright() as p:
    ctx=launch(p,'last',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Last'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    names=pg.evaluate("window.__PG.pages.map(p=>p.name)")
    r.add('Construcción, Etiquetado y Packaging ocultas (no borradas) y Confección se llama Interior',('Interior' in names) and not any(n in names for n in ('Construcción','Construcción y costuras','Etiquetado','Packaging','Confección')),names)
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(800)
    f=pg.locator('form.color-dialog')
    r.add('«Añadir color»: sin biblioteca y con el selector visual a la vista',f.locator('.cd-sv').is_visible() and not f.locator('.cd-lib').is_visible(),'')
    pg.locator('#cdPantone').fill('19-4052'); f.locator('.cd-submit').click(); pg.wait_for_timeout(1800)
    for i in (1,2):
        vid=pg.evaluate("i=>window.__PG.pages.find(x=>x.i===i).v.id",i); pg.evaluate("id=>document.querySelector('.pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",vid); pg.wait_for_timeout(900)
        pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1200); empty_click(pg); pg.wait_for_timeout(300)
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('18-1664')
    if pg.locator('[data-cdmode="dup"]').count(): pg.locator('[data-cdmode="dup"]').first.click()
    pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(2500)
    pg.mouse.move(720,450)
    for _ in range(3): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(2500)
    fa=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id"); sk=pg.evaluate("window.__PG.pages.find(x=>x.i===1).v.id")
    pg.evaluate(OBS); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",fa); pg.wait_for_timeout(1800)
    rb=pg.evaluate("window.__rb"); lt=pg.evaluate("window.__lt")
    r.add('Cambiar a otra página del mismo color: no se reconstruye nada y no hay bloqueos',rb==0 and max(lt or [0])<100,(rb,lt))
    b=pg.locator('.pg-rowhit[data-pgv="%s"][data-ci="0"]'%fa).first.bounding_box()
    if b and (b['y']<60 or b['y']+b['height']>860):
        pg.mouse.wheel(0,(b['y']-300)); pg.wait_for_timeout(800); b=pg.locator('.pg-rowhit[data-pgv="%s"][data-ci="0"]'%fa).first.bounding_box()
    pg.wait_for_timeout(600); pg.evaluate(OBS)
    pg.mouse.click(b['x']+b['width']/2,b['y']+b['height']/2); pg.wait_for_timeout(2000)
    rb=pg.evaluate("window.__rb"); lt=pg.evaluate("window.__lt")
    r.add('Misma página en otro color: una sola reconstrucción (la necesaria) y sin bloqueos largos',rb<=1 and max(lt or [0])<150,(rb,lt))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
