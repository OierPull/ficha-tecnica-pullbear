# El reloj de historial solo aparece cuando el contenido cambia de verdad («vacío» = «no existía»)
import os,glob
os.environ['NOLEGACY']='1'
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def newver(pg,sec):
    pg.locator('[data-pbh-ver]').click(); pg.wait_for_timeout(300); pg.locator('[data-pbh-new]').click(); pg.wait_for_timeout(1500); select_thumb(pg,thumb(pg,sec)); pg.wait_for_timeout(600)
def ind(pg): return pg.evaluate("[...document.querySelectorAll('#sections .item')].map(it=>[(it.querySelector('.item-name')||{}).textContent,[...it.querySelectorAll('.field')].filter(f=>f.querySelector('.fhist')).map(f=>(f.querySelector('.field-label-row label')||f.querySelector('.field-label-row')).childNodes[0].textContent.trim())])")
with sync_playwright() as p:
    ctx=launch(p,'fh',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(1800)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','FH'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(2300)
    select_thumb(pg,thumb(pg,'Forro')); pg.wait_for_timeout(500)
    f0=lambda: pg.locator('#sections .item').first.locator('textarea, input[type=text]').first
    f0().fill('Popelín algodón'); pg.wait_for_timeout(800)
    newver(pg,'Forro')                                  # V2: se añade un bloque nuevo, vacío
    nb0=pg.locator('#sections .item').count(); pg.locator('#sections .add-btn').first.click(); pg.wait_for_timeout(900)
    r.add('(preparación) se añade un bloque nuevo en V2',pg.locator('#sections .item').count()==nb0+1,pg.locator('#sections .item').count())
    f0().fill('Popelín poliéster'); pg.wait_for_timeout(800)
    newver(pg,'Forro')                                  # V3: sin cambios
    pg.wait_for_timeout(1200); d=ind(pg)
    r.add('Primer bloque: solo el campo que cambió lleva el reloj',d[0][1]==[d[0][1][0]] if d[0][1] else False,d[0])
    r.add('Bloque añadido después y vacío («no existía» → «vacío»): sin reloj',d[-1][1]==[],d[-1])
    last=pg.locator('#sections .item').last.locator('textarea, input[type=text]').first; last.fill('Bolsillo interior'); pg.wait_for_timeout(1500)
    d2=ind(pg); r.add('Si ese campo nuevo se rellena, ya sí aparece el reloj',len(d2[-1][1])==1,d2[-1])
    pg.locator('#sections .item').last.locator('.fhist').first.hover(); pg.wait_for_timeout(400)
    tip=pg.evaluate("document.getElementById('pbHistPop').innerText.replace(/\\n/g,' | ')")
    r.add('…y la ventanita muestra el cambio (antes vacío, ahora el texto)','Bolsillo interior' in tip,tip[:160])
    r.add('Consola sin errores',not [l for l in lg if 'error' in str(l).lower()][:1],str(lg[:2]))
    ctx.close()
    # la ficha de ejemplo sigue mostrando sus cinco indicadores
    f=glob.glob('/mnt/user-data/outputs/Ficha-compartida_EJ-HIST*.json')
    if f:
        ctx=launch(p,'fh2',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(1800)
        with pg.expect_file_chooser() as fc: pg.locator('#openSharedBtn').click()
        fc.value.set_files(f[0]); pg.wait_for_timeout(1200); pg.locator('[data-sh="new"]').click(); pg.wait_for_timeout(4000)
        select_thumb(pg,thumb(pg,'Tejido')); pg.wait_for_timeout(1500)
        r.add('La ficha de ejemplo sigue mostrando sus 5 indicadores en Tejido',pg.locator('#sections .fhist').count()==5,pg.locator('#sections .fhist').count())
        ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
