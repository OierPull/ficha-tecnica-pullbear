# Títulos para todos, nombres unificados, papelera visible, página sin columna, tamaños y grosores libres, pluma con zoom, desagrupar, edición directa de puntos
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'pen2',1440,900); ctx.add_init_script("try{if(!sessionStorage.getItem('x')){localStorage.setItem('pb-canvas-pref','0');sessionStorage.setItem('x','1')}}catch(e){}")
    pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','P2'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3500)
    labs=pg.evaluate("[...document.querySelectorAll('.pg-layer .pg-lab:not(.is-preview):not(.is-cont) .pgl-cur')].filter(e=>e.getBoundingClientRect().width>0).map(e=>e.textContent.trim())")
    r.add('Con la preferencia antigua «clásica» guardada, se ven igualmente los títulos de las páginas',len(labs)>=5 and 'Diseño' in labs,labs[:7])
    def blk(name): return pg.evaluate("n=>{const P=window.__PG,p=P.pages.find(x=>x.name===n);const s=document.querySelector('.pg-layer .pg-spec[data-pgv=\"'+p.v.id+'\"]:not(.is-preview)');return s?[[...s.querySelectorAll('.pgs-bh')].map(b=>(b.querySelector('input,.pgs-bn,strong')||b).value||(b.querySelector('input,.pgs-bn,strong')||b).textContent).map(x=>String(x).trim()).slice(0,2),(s.querySelector('.pgs-addb')||{}).textContent]:null}",name)
    got={n:blk(n) for n in ('Fabric','Print / Embroidery','Interior')}
    ok=all(v and v[0] and v[0][0].startswith(exp) for (n,v),exp in zip(got.items(),('Fabric','Print','Interior'))) and 'fabric' in (got['Fabric'][1] or '').lower()
    r.add('Los apartados se llaman como su página (Fabric, Print, Interior) y «+ Añadir fabric»…',ok,got)
    tv=pg.evaluate("[...document.querySelectorAll('.pg-layer .pg-lab:not(.is-preview):not(.is-cont):not(.is-on) .pgl-del')].filter(e=>getComputedStyle(e).opacity==='1'&&e.getBoundingClientRect().width>0).length")
    r.add('La papelera de página se ve aunque la hoja no esté seleccionada',tv>=1,tv)
    # página sin columna
    gr=pg.evaluate("window.__PG.pages.find(p=>p.name==='Print / Embroidery').v.id")
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",gr); pg.wait_for_timeout(1200)
    for _ in range(3):
        d=pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) .pgs-del'%gr)
        if not d.count(): break
        d.first.click(); pg.wait_for_timeout(500)
        cf=pg.locator('.ui-confirm .ui-btn-primary, [role=dialog] button:has-text("Eliminar")')
        if cf.count() and cf.first.is_visible(): cf.first.click()
        pg.wait_for_timeout(1300)
    show=pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) .pg-specshow'%gr)
    addb=pg.evaluate("id=>{const b=document.querySelector('.pg-layer .pg-spec[data-pgv=\"'+id+'\"]:not(.is-preview) .pgs-addb');return !!b&&getComputedStyle(b).display!=='none'}",gr)
    r.add('Sin apartados: desaparece «+ Añadir…» y queda la pestaña «Campos»',show.count()==1 and show.is_visible() and not addb,(show.count(),addb))
    pg.locator('.pg-grid[data-pggrid="%s"] .pg-gbar-v'%gr).click(); pg.wait_for_timeout(1500)
    nb=pg.evaluate("id=>document.querySelectorAll('.pg-layer .pg-spec[data-pgv=\"'+id+'\"]:not(.is-preview) .pgs-blk').length",gr)
    r.add('Añadir cuadrícula en una hoja sin columna no vuelve a crear apartados',nb==0,nb)
    show.click(); pg.wait_for_timeout(1500)
    nb2=pg.evaluate("id=>document.querySelectorAll('.pg-layer .pg-spec[data-pgv=\"'+id+'\"]:not(.is-preview) .pgs-blk').length",gr)
    r.add('«Campos» vuelve a mostrar la columna',nb2>=1,nb2)
    # texto
    sk=pg.evaluate("window.__PG.pages[1].v.id"); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    W="([id,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    pg.locator('[data-btool="text"]').click(); pg.mouse.click(*pg.evaluate(W,[sk,200,150])); pg.wait_for_timeout(300); pg.keyboard.type('Hola'); pg.wait_for_timeout(200)
    sz=pg.evaluate("(()=>{const o=window.__BOARD.objects.find(o=>o.type==='text');return o&&o.size})()")
    vis=pg.evaluate("(()=>{const g=document.querySelector('.board-ctxbar .pg-numctl');return g&&!g.hidden?[g.querySelector('.pg-numlab').textContent,g.querySelector('input').value]:null})()")
    r.add('El texto nace con tamaño 28 (el pequeño de antes) y la barra muestra «Tamaño» editable',sz==28 and vis==['Tamaño','28'],(sz,vis))
    pg.locator('.board-ctxbar [data-pgnum="+"]').click(); pg.wait_for_timeout(200)
    inp=pg.locator('.board-ctxbar [data-pgnumv]'); inp.fill('50'); inp.press('Enter'); pg.wait_for_timeout(300)
    sz2=pg.evaluate("window.__BOARD.objects.find(o=>o.type==='text').size")
    r.add('Tamaño libre: «+» suma y se puede escribir cualquier valor (50)',sz2==50,sz2)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200); empty_click(pg); pg.wait_for_timeout(200)
    # flecha
    pg.locator('[data-btool="arrow"]').click(); pg.mouse.click(*pg.evaluate(W,[sk,250,500])); pg.wait_for_timeout(150); pg.mouse.click(*pg.evaluate(W,[sk,500,600])); pg.wait_for_timeout(400); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    aid=pg.evaluate("window.__BOARD.objects.find(o=>o.type==='arrow').id"); pg.evaluate("id=>{window.__BOARD.sel=id;}",aid)
    pg.mouse.click(*pg.evaluate(W,[sk,375,550])); pg.wait_for_timeout(400)
    if pg.locator('.board-ctxbar [data-pgnum="+"]').is_visible():
        for _ in range(3): pg.locator('.board-ctxbar [data-pgnum="+"]').click(); pg.wait_for_timeout(120)
    sw=pg.evaluate("window.__BOARD.objects.find(o=>o.type==='arrow').sw")
    r.add('Las flechas tienen grosor ajustable (más gordas o más finas)',sw==7,sw)
    empty_click(pg); pg.wait_for_timeout(200)
    # pluma con zoom a mitad
    pg.locator('.board-island [data-pgpen="curve"]').click(); pg.wait_for_timeout(200)
    pts=[(150,200),(300,120),(450,300)]
    pg.mouse.click(*pg.evaluate(W,[sk,*pts[0]])); pg.mouse.click(*pg.evaluate(W,[sk,*pts[1]]))
    pg.mouse.move(700,450); pg.keyboard.down('Control'); pg.mouse.wheel(0,-240); pg.keyboard.up('Control'); pg.wait_for_timeout(500)
    pg.mouse.click(*pg.evaluate(W,[sk,*pts[2]])); pg.keyboard.press('Enter'); pg.wait_for_timeout(500)
    o=pg.evaluate("(()=>{const P=window.__PG,o=window.__BOARD.objects.filter(o=>o.pen).pop();const p=P.pages[1];return o?[o.x-p.ox,o.y,o.w,o.h,o.pen.sw]:null})()")
    okz=o and o[0]<150 and o[0]+o[2]>450 and o[1]<120 and o[1]+o[3]>300 and o[0]>100 and o[0]+o[2]<520
    r.add('Pluma: cambiar el zoom a mitad del trazo no descuadra los puntos',bool(okz),o)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    pid=pg.evaluate("window.__BOARD.objects.filter(o=>o.pen).pop().id"); pg.evaluate("id=>{window.__BOARD.sel=id;window.__boardCtx&&window.__boardCtx()}",pid)
    c=pg.evaluate(W,[sk,300,120]); pg.mouse.click(c[0],c[1]+2); pg.wait_for_timeout(400)
    vis=pg.evaluate("(()=>{const g=document.querySelector('.board-ctxbar .pg-numctl');return g&&!g.hidden?[g.querySelector('.pg-numlab').textContent,g.querySelector('input').value]:null})()")
    if vis:
        inp=pg.locator('.board-ctxbar [data-pgnumv]'); inp.fill('12'); inp.press('Enter'); pg.wait_for_timeout(300)
    st=pg.evaluate("(()=>{const o=window.__BOARD.objects.filter(o=>o.pen).pop();return [o.pen.sw,decodeURIComponent(o.src.split(',')[1]).indexOf('stroke-width=\"12\"')>=0]})()")
    r.add('Pluma: el grosor de la línea se ajusta desde la barra',vis and vis[0]=='Grosor' and st==[12,True],(vis,st))
    # doble clic directo en el trazo -> puntos
    pg.mouse.dblclick(c[0],c[1]+2); pg.wait_for_timeout(700)
    sv=pg.evaluate("window.__svgp&&window.__svgp()")
    r.add('Doble clic en un trazo: se entra directamente a editar sus puntos (anclas a la vista)',bool(sv),sv)
    if sv:
        before=sv['n']
        pg.evaluate("window.__svgpSel(1)"); pg.keyboard.press('Delete'); pg.wait_for_timeout(400)
        a2=pg.evaluate("window.__svgp()"); aft=[a2 and a2['n'],a2 and a2.get('d')]
        r.add('Borrar un ancla une el trazo y conserva la curva',aft[0]==before-1 and 'C' in (aft[1] or ''),(before,aft))
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
