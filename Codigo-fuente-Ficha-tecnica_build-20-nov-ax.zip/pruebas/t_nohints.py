# Sin avisos ni notificaciones
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'nh',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','N'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    VIS="()=>[...document.querySelectorAll('.arrow-hint,.board-hint,.app-toast')].filter(e=>{const s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&e.getBoundingClientRect().height>0}).length"
    pg.locator('[data-btool="arrow"]').click(); pg.wait_for_timeout(400); a=pg.evaluate(VIS)
    pg.mouse.click(600,400); pg.wait_for_timeout(200); pg.mouse.click(760,480); pg.wait_for_timeout(500); b=pg.evaluate(VIS)
    pg.keyboard.press('Escape'); pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('19-4052'); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(500); c=pg.evaluate(VIS)
    r.add('No aparece ningún aviso ni notificación (herramienta, flecha terminada, color añadido)',a==0 and b==0 and c==0,(a,b,c))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
