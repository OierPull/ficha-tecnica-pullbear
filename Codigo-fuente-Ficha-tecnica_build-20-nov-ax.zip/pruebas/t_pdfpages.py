# Modo páginas: «Añadir página» al final y PDF real con cabecera/pie automáticos y lo escrito en las hojas
import os,glob
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'pdfpg',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(20000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','EJ-PDF · Pantalón'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3200)
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500)
    n0=pg.evaluate("window.__PG.pages.length"); last=pg.evaluate("window.__PG.pages[window.__PG.pages.length-1].name")
    pg.locator('.board-host .pg-addlast').click(); pg.wait_for_timeout(900)
    r.add('«Añadir página» propone una página nueva al final («%s 2»)'%last,pg.locator('#tabPop').is_visible() and pg.locator('#tabPopName').input_value()==last+' 2',pg.locator('#tabPopName').input_value())
    pg.fill('#tabPopName','Medidas'); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(2500)
    names=pg.evaluate("window.__PG.pages.map(p=>p.name)")
    r.add('…y la crea al final, recolocando las hojas',len(names)==n0+1 and names[-1]=='Medidas',names[-3:])
    tej=pg.evaluate("window.__PG.pages.find(x=>x.name==='Fabric').v.id")
    pg.evaluate("n=>{const c=[...document.querySelectorAll('#visualGallery .gallery-card')].find(c=>(c.querySelector('.tab-name')||{}).textContent===n);c.querySelector('.gallery-thumb').click()}",'Fabric'); pg.wait_for_timeout(900)
    f=pg.locator('.pg-spec[data-pgv="%s"] .pgs-f:has(input.pgs-lab[value="Acabado"]) textarea'%tej); f.click(); f.type('475'); pg.wait_for_timeout(500); pg.mouse.click(5,700); pg.wait_for_timeout(600)
    med=pg.evaluate("window.__PG.pages.find(x=>x.name==='Medidas').v.id")
    pg.evaluate("n=>{const c=[...document.querySelectorAll('#visualGallery .gallery-card')].find(c=>(c.querySelector('.tab-name')||{}).textContent===n);c.querySelector('.gallery-thumb').click()}",'Medidas'); pg.wait_for_timeout(900)
    m=pg.locator('.pg-spec[data-pgv="%s"] textarea'%med).first; m.click(); m.type('Talla M: cintura 76'); pg.wait_for_timeout(500); pg.mouse.click(5,700); pg.wait_for_timeout(600)
    os.makedirs('pdfs',exist_ok=True); [os.remove(x) for x in glob.glob('pdfs/pgpdf__*.pdf')]
    pg.evaluate("window.__PG&&(window.__PG.pdfOk=true)")  # «Descargar igualmente» si faltan obligatorios

    got=export_pdf(pg,'pgpdf',wait=60)
    r.add('El PDF se descarga desde el modo páginas',len(got)>=1,got)
    if got:
        n,_,tx=pdf_info(got[0][1]); allt=' '.join(tx)
        r.add('Lleva una página por cada apartado con contenido, incluida la nueva «Medidas» (%d páginas)'%n,n>=3 and 'Medidas' in allt and 'cintura 76' in allt,n)
        r.add('Cabecera y pie automáticos (PULL&BEAR, apartado, «Página 1 de N»)',('PULL&BEAR' in allt or 'PULL&amp;BEAR' in allt) and 'Página 1 de' in allt and 'Fabric' in allt,allt[:120])
        import re as _re
        from pypdf import PdfReader
        rd=PdfReader(got[0][1]); ws=[]
        for pgx in rd.pages:
            cs=pgx.get_contents().get_data().decode('latin-1')
            ws+= [float(a) for a,b in _re.findall(r'([0-9.]+) 0 0 ([0-9.]+) [-0-9.]+ [-0-9.]+ cm',cs)]
        r.add('En el PDF, la imagen de la hoja ocupa todo el ancho del cuerpo de la página',any(abs(w-841.89)<1.5 for w in ws),sorted(set(round(w) for w in ws))[-4:])
        r.add('Lo escrito en la hoja sale en el PDF (Peso 475 en Tejido)',any('Fabric' in t and '475' in t for t in tx),'')
    r.add('Consola sin errores',not [l for l in lg if 'error' in str(l).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
