# Al quitar / recuperar la columna, las imágenes de la cuadrícula siguen en sus casillas; selector de ajuste; color de pluma; barra limpia
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
IMG=[f for f in ('pantalon.svg','img_a.png','img_b.png','img_c.png') if os.path.exists(f)]
with sync_playwright() as p:
    ctx=launch(p,'refit',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','RF'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    def go(name):
        pid=pg.evaluate("n=>window.__PG.pages.find(p=>p.name===n).v.id",name); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",pid); pg.wait_for_timeout(1200); return pid
    def pics(pid): return pg.evaluate("""id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id);return window.__BOARD.objects.filter(o=>o.type==='image'&&typeof o.cell==='number'&&o.x>=p.ox-50&&o.x<p.ox+P.SHW+50).map(o=>{const c=window.__pgCellRect?window.__pgCellRect(id,o.cell):null;return {cell:o.cell,fit:o.fit||'contain',x:o.x,y:o.y,w:o.w,h:o.h,c:c}})}""",pid)
    def inside(L):
        def ok(q):
            c=q['c']
            if not c: return False
            hx=q['x']>=c['x']-1 and q['x']+q['w']<=c['x']+c['w']+1
            vy=q['y']>=c['y']-1 and q['y']+q['h']<=c['y']+c['h']+1
            if q['fit']=='width': return hx and abs((q['x']+q['w']/2)-(c['x']+c['w']/2))<2
            if q['fit']=='height': return vy and abs((q['y']+q['h']/2)-(c['y']+c['h']/2))<2
            return hx and vy
        return all(ok(q) for q in L)
    def ordered(L): s=sorted(L,key=lambda q:q['cell']); return all(s[i]['x']<s[i+1]['x'] for i in range(len(s)-1))
    def delblocks(pid):
        for _ in range(4):
            d=pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) .pgs-del'%pid)
            if not d.count(): break
            d.first.click(); pg.wait_for_timeout(500)
            cf=pg.locator('.ui-confirm .ui-btn-primary, [role=dialog] button:has-text("Eliminar")')
            if cf.count() and cf.first.is_visible(): cf.first.click()
            pg.wait_for_timeout(1200)
    pg.evaluate("window.__pgCellRect=function(id,i){const P=window.__PG,p=P.pages.find(x=>x.v.id===id);return null}")
    has=pg.evaluate("typeof window.__pgCellRectReal")
    # caso A: 3 columnas, 3 imágenes
    pid=go('Print / Embroidery')
    for _ in range(2): pg.locator('.pg-grid[data-pggrid="%s"] .pg-gbar-v'%pid).click(); pg.wait_for_timeout(900)
    for k in range(3): pg.set_input_files('.board-island [data-bupload-file]',IMG[0]); pg.wait_for_timeout(1500)
    pg.evaluate("window.__pgCellRect=function(id,i){return window.__pgCR(id,i)}")
    a0=pics(pid)
    r.add('Caso A: 3 imágenes en 3 columnas, cada una en su casilla',len(a0)==3 and inside(a0) and ordered(a0),[(q['cell'],round(q['x'])) for q in a0])
    delblocks(pid); pg.wait_for_timeout(800)
    a1=pics(pid); wider=a1 and a0 and all(q1['c']['w']>q0['c']['w']*1.2 for q0,q1 in zip(sorted(a0,key=lambda q:q['cell']),sorted(a1,key=lambda q:q['cell'])))
    r.add('Caso A: al quitar la columna siguen ordenadas y ocupan sus casillas ampliadas',len(a1)==3 and inside(a1) and ordered(a1) and wider,[(q['cell'],round(q['x']),round(q['w'])) for q in a1])
    pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) .pg-specshow'%pid).click(); pg.wait_for_timeout(1500)
    a2=pics(pid)
    r.add('Caso A: al recuperar la columna vuelven a sus casillas (más estrechas)',len(a2)==3 and inside(a2) and ordered(a2),[(q['cell'],round(q['x']),round(q['w'])) for q in a2])
    # caso B: 2x2 con «Ancho» y una colocada a mano
    pid=go('Interior')
    pg.locator('.pg-grid[data-pggrid="%s"] .pg-gbar-v'%pid).click(); pg.wait_for_timeout(900); pg.locator('.pg-grid[data-pggrid="%s"] .pg-gbar-h'%pid).click(); pg.wait_for_timeout(900)
    for k in range(4): pg.set_input_files('.board-island [data-bupload-file]',IMG[0]); pg.wait_for_timeout(1400)
    b0=pics(pid)
    pg.evaluate("id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id);const L=window.__BOARD.objects.filter(o=>o.type==='image'&&typeof o.cell==='number'&&o.x>=p.ox-50&&o.x<p.ox+P.SHW+50).sort((a,b)=>a.cell-b.cell);L[1].fit='width';const c=window.__pgCR(id,L[1].cell);window.__pgPlace(L[1],c);const m=L[2];m.fit='manual';m.w*=0.5;m.h*=0.5;window.__boardCommit()}",pid); pg.wait_for_timeout(600)
    delblocks(pid); pg.wait_for_timeout(800)
    b1=pics(pid)
    r.add('Caso B (2×2, una en «Ancho» y otra a mano): todas siguen dentro de su casilla al quitar la columna',len(b1)==4 and inside(b1),[(q['cell'],q['fit'],round(q['x']),round(q['w'])) for q in b1])
    # selector de ajuste
    q=sorted(b1,key=lambda q:q['cell'])[0]
    W="([id,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+wx*v.k,hr.top+v.oy+wy*v.k]}"
    pg.mouse.click(*pg.evaluate(W,[pid,q['x']+q['w']/2,q['y']+q['h']/2])); pg.wait_for_timeout(500)
    t0=pg.evaluate("(()=>{const t=document.querySelector('.board-ctxbar [data-pgfittrig]');return t&&t.offsetParent?t.textContent.trim():null})()")
    pg.locator('.board-ctxbar [data-pgfittrig]').click(); pg.wait_for_timeout(200); pg.locator('.board-ctxbar [data-pgfitopt="height"]').click(); pg.wait_for_timeout(500)
    t1=pg.evaluate("document.querySelector('.board-ctxbar [data-pgfittrig]').textContent.trim()")
    bar=pg.evaluate("(()=>{const b=document.querySelector('.board-ctxbar');const vis=s=>{const e=b.querySelector(s);return !!e&&getComputedStyle(e).display!=='none'&&!e.closest('[hidden]')};return [vis('.board-ctx-svg'),vis('[data-bact=\"del\"]')]})()")
    r.add('El selector de ajuste muestra el modo actual y se actualiza al elegir otro',t0=='Entera' and t1=='Alto',(t0,t1))
    r.add('La barra ya no tiene lápiz ni papelera',bar==[False,False],bar)
    pg.keyboard.press('Escape'); empty_click(pg); pg.wait_for_timeout(200)
    # color de pluma
    sk=go('Sketch'); pg.keyboard.press('Shift+P')
    for xy in [(150,150),(350,250),(550,150)]: pg.mouse.click(*pg.evaluate(W,[sk,pg.evaluate("id=>window.__PG.pages.find(p=>p.v.id===id).ox",sk)+xy[0],xy[1]])); pg.wait_for_timeout(300)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    ox=pg.evaluate("id=>window.__PG.pages.find(p=>p.v.id===id).ox",sk)
    pg.mouse.click(*pg.evaluate(W,[sk,ox+250,200])); pg.wait_for_timeout(400)
    cv=pg.evaluate("(()=>{const e=document.querySelector('.board-ctxbar .board-color-ctx');return !!e&&!e.hidden&&getComputedStyle(e).display!=='none'})()")
    if cv: pg.locator('.board-ctxbar [data-bcolorpop]').click(); pg.wait_for_timeout(300); pg.locator('.pg-penpal [data-pgpc="#2f6fde"]').click(); pg.wait_for_timeout(400)
    pc=pg.evaluate("(()=>{const o=window.__BOARD.objects.filter(o=>o.pen).pop();return o?[o.pen.color,decodeURIComponent(o.src.split(',')[1]).indexOf('#2f6fde')>=0]:null})()")
    r.add('Los trazos de pluma muestran el color en la barra y se puede cambiar',cv and pc==['#2f6fde',True],(cv,pc))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
