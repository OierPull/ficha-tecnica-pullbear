# Estados en la hoja (página, bloque, campo) y PDF sin miniaturas recortadas
import os,glob
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def scr(pg,wx,wy): return pg.evaluate("([x,y])=>{const r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV(),P=window.__PG;return [r.left+v.ox+(x+P.DX)*v.k,r.top+v.oy+y*v.k]}",[wx,wy])
with sync_playwright() as p:
    ctx=launch(p,'status',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Estados'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",str('2')); pg.wait_for_timeout(900)
    tid=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id"); lab='.pg-lab[data-pglab="%s"]:not(.is-cont)'%tid; card='.pg-spec[data-pgv="%s"]'%tid
    r.add('Cada página tiene su estado junto al nombre («Pendiente»)',pg.locator(lab+' .pg-st').text_content().strip()=='Pendiente','')
    pg.locator(lab+' .pg-st').evaluate('e=>e.click()'); pg.wait_for_timeout(300)
    r.add('Al pulsarlo se abre el menú «Aprobado / Pendiente»',pg.locator('#pgStMenu').is_visible() and 'Aprobado' in pg.locator('#pgStMenu').inner_text(),'')
    pg.locator('#pgStMenu [data-pgstset="ok"]').click(); pg.wait_for_timeout(900)
    ok=pg.locator(card+' .pgs-fst.is-ok').count(); tot=pg.locator(card+' .pgs-fst').count()
    r.add('Aprobar la página aprueba todos sus campos',ok==tot and tot>0 and pg.locator(lab+' .pg-st').inner_text().strip()=='Aprobado',(ok,tot))
    tabok=pg.evaluate("(()=>{const c=[...document.querySelectorAll('#visualGallery .gallery-card')].find(c=>/Fabric/.test(c.textContent));const s=c&&c.querySelector('.gallery-state');return s?s.className:''})()")
    r.add('…y la pestaña lo refleja',('ok' in tabok),tabok)
    pg.locator(card+' .pgs-bh .pg-st').first.click(); pg.wait_for_timeout(300); pg.locator('#pgStMenu [data-pgstset="pending"]').click(); pg.wait_for_timeout(900)
    r.add('El estado de un bloque se cambia con su menú (vuelve a «Pendiente»)',pg.locator(card+' .pgs-fst.is-ok').count()==0 and pg.locator(card+' .pgs-bh .pg-st').first.inner_text().strip()=='Pendiente','')
    pg.locator(card+' .pgs-fst').first.click(); pg.wait_for_timeout(800)
    r.add('Un campo se aprueba con su círculo',pg.locator(card+' .pgs-fst').first.get_attribute('aria-pressed')=='true','')
    pg.locator(card+' .pgs-fst').first.click(); pg.wait_for_timeout(800)
    r.add('…y vuelve a pendiente con otro clic',pg.locator(card+' .pgs-fst').first.get_attribute('aria-pressed')=='false','')
    pg.locator(card+' .pgs-fst').nth(1).click(); pg.wait_for_timeout(800)
    # anotación en Dibujo plano y PDF
    pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",str('1')); pg.wait_for_timeout(900)
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500)
    ox=pg.evaluate("window.__PG.pages.find(x=>x.i===1).ox")
    pg.locator('[data-btool="rect"]').click(); a=scr(pg,ox+150,150); b=scr(pg,ox+320,320); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(1200); pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
    dc='.pg-spec[data-pgv="%s"]'%pg.evaluate("window.__PG.pages.find(x=>x.i===1).v.id")
    f=pg.locator(dc+' textarea').first; f.click(); f.type('Bolsillo'); pg.wait_for_timeout(300); empty_click(pg); pg.wait_for_timeout(500)
    pg.reload(); pg.wait_for_timeout(2600); pg.locator('#projectGrid .project-card').first.click(); pg.wait_for_timeout(3200)
    r.add('Los estados se conservan al recargar',pg.locator(card+' .pgs-fst.is-ok').count()==1,pg.locator(card+' .pgs-fst.is-ok').count())
    os.makedirs('pdfs',exist_ok=True); [os.remove(x) for x in glob.glob('pdfs/stat__*.pdf')]
    pg.evaluate("window.__PG&&(window.__PG.pdfOk=true)")  # «Descargar igualmente» si faltan obligatorios

    got=export_pdf(pg,'stat',wait=60)
    if got:
        from pypdf import PdfReader
        rd=PdfReader(got[0][1]); info=[]
        for pgx in rd.pages:
            t=pgx.extract_text() or ''
            info.append(('Sketch' in t,len(pgx.images)))
        dp=[n for (isdp,n) in info if isdp]
        r.add('En el PDF, el bloque anotado ya no lleva la miniatura recortada (solo la imagen de la hoja)',bool(dp) and dp[0]==1,info)
    else: r.add('PDF descargado',False,'')
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
