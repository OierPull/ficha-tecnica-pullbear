# Mesas independientes por color, filas completas, botón fijo, etiquetas, continuación y creación de página sin saltos
import os,json
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def step(name,fn):
    try:
        ok,det=fn(); r.add(name,bool(ok),det)
    except Exception as e: r.add(name,False,'EXC '+str(e)[:160])
def pid(pg,i): return pg.evaluate("i=>window.__PG.pages.find(x=>x.i===i).v.id",i)
def scrw(pg,id_,x,y): return pg.evaluate("([id,x,y])=>{const P=window.__PG,p=P.pages.find(q=>q.v.id===id),r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV();return [r.left+v.ox+(p.ox+x)*v.k,r.top+v.oy+y*v.k]}",[id_,x,y])
def addcolor(pg,code,mode='copy'):
    pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600); pg.locator('#cdPantone').fill(code)
    if mode=='empty': pg.locator('form.color-dialog .pb-copt[data-pbcopt="empty"]').click()
    pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1900)
def rects(pg): return sorted(pg.evaluate("window.__BOARD.objects.filter(o=>o.type==='rect').map(o=>[Math.round(o.x1!=null?o.x1:o.x),Math.round(o.y1!=null?o.y1:o.y)])"))
def zoomout(pg,n):
    pg.mouse.move(720,450)
    for _ in range(n): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(70)
    pg.wait_for_timeout(500)
with sync_playwright() as p:
    ctx=launch(p,'rows2',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Indep'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    addcolor(pg,'19-4052')
    fa=pid(pg,2); did=pid(pg,0); pg.locator('.pg-lab[data-pglab="%s"] [data-pgnav="%s"]'%(did,fa)).evaluate('e=>e.click()'); pg.wait_for_timeout(1300)
    t=pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) textarea'%fa).first; t.click(); t.fill('DEN-A'); empty_click(pg); pg.wait_for_timeout(500)
    ox=pg.evaluate("id=>window.__PG.pages.find(x=>x.v.id===id).ox",fa)
    pg.locator('[data-btool="rect"]').click(); a=scrw(pg,fa,300,250); b=scrw(pg,fa,560,420); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(900); empty_click(pg); pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
    rA=rects(pg)
    addcolor(pg,'18-1664','empty')
    INDEP=pg.evaluate('window.__pgIndep()')
    if INDEP: step('Un color nuevo («vacío») no hereda los dibujos del anterior',lambda:(rects(pg)==[] ,rects(pg)))
    fa=pid(pg,2); ox=pg.evaluate("id=>window.__PG.pages.find(x=>x.v.id===id).ox",fa)
    pg.locator('[data-btool="rect"]').click(); a=scrw(pg,fa,700,300); b=scrw(pg,fa,900,450); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(900); empty_click(pg); pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
    rB=rects(pg)
    # mover el dibujo del segundo color
    c=scrw(pg,fa,800,300); pg.mouse.click(*c); pg.wait_for_timeout(300); pg.mouse.move(*c); pg.mouse.down(); pg.mouse.move(c[0]+90,c[1]+70,steps=8); pg.mouse.up(); pg.wait_for_timeout(900); empty_click(pg)
    rB2=rects(pg)
    zoomout(pg,4)
    first=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')][0].getAttribute('data-pgrow')")
    # cabeceras de las filas de otros colores
    step('Cada fila de otro color tiene su cabecera con el índice de todas las páginas y su estado',lambda:(pg.locator('.pg-lab.is-preview[data-pgrow="%s"][data-ci="0"] .pgl-nav'%first).count()>=7 and pg.locator('.pg-lab.is-preview[data-pgrow="%s"] .pgl-stp'%first).count()>=7,pg.locator('.pg-lab.is-preview[data-pgrow="%s"] .pgl-nav'%first).count()))
    step('Las etiquetas de color llevan su código (y su «×» para eliminar el color)',lambda:(pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].every(l=>getComputedStyle(l).backgroundColor!=='rgba(0, 0, 0, 0)'&&/\\d|#/.test(l.querySelector('span').textContent))"),pg.evaluate("[...document.querySelectorAll('.pg-rowlab span')].map(s=>s.textContent)")))
    def nooverlap():
        bad=[]
        for z in range(4):
            res=pg.evaluate("""()=>{const P=window.__PG,v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect(),labs=[...document.querySelectorAll('.pg-rowlab')],ai=labs.findIndex(l=>l.classList.contains('is-on')),pitch=P.SHH+200,out=[];
              labs.forEach(l=>{if(l.hidden||l.classList.contains('is-float'))return;const b=l.getBoundingClientRect();if(!b.width)return;const i=labs.indexOf(l);P.pages.forEach(p=>{const dy=(i-ai)*pitch,x0=hr.left+v.ox+p.ox*v.k,x1=x0+(p.chunks||1)*(P.SHW+P.VG)*v.k-P.VG*v.k*((p.chunks||1)>1?1:0),y0=hr.top+v.oy+dy*v.k,y1=y0+P.SHH*v.k;if(b.right>x0+1&&b.left<x1-1&&b.bottom>y0&&b.top<y1)out.push([i,p.name])})});
              return out}""")
            bad+=res
            pg.mouse.move(720,450); pg.keyboard.down('Control'); pg.mouse.wheel(0,200); pg.keyboard.up('Control'); pg.wait_for_timeout(300)
        return (not bad,bad[:3])
    step('Las etiquetas de color no se meten en las páginas (salvo flotando en su pastilla para seguir visibles)',nooverlap)
    zoomout(pg,0)
    # botón «+ Color» fijo
    def varcard():
        r=pg.evaluate("(()=>{const v=document.querySelector('.pg-addvar').getBoundingClientRect();const ls=[...document.querySelectorAll('.pg-rowhit[data-ci=\"0\"]')].map(e=>e.getBoundingClientRect().bottom);const sp=[...document.querySelectorAll('.pg-layer .pg-spec:not(.is-preview)')].map(e=>e.getBoundingClientRect().bottom);return [Math.round(v.top),Math.round(Math.max(...ls,...sp))]})()")
        return (r[0]>=r[1]-2,r)
    step('«Crear nueva variante de color» está en la mesa, debajo de la última fila',varcard)
    step('Al pulsarla se abre el diálogo con «Duplicar otro color» y «Color vacío»',lambda:(pg.evaluate("document.querySelector('.pg-addvar').click()") is None and pg.wait_for_timeout(900) is None and pg.locator('form.color-dialog .pb-copt').count()==2,''))
    pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
    if pg.locator('form.color-dialog').count() and pg.locator('form.color-dialog').is_visible():
        bb=pg.locator('form.color-dialog button:has-text("Cancelar")')
        if bb.count(): bb.first.click(); pg.wait_for_timeout(400)
    zoomout(pg,4)
    def activate():
        loc=pg.locator('.pg-rowhit[data-pgrow="%s"][data-pgv="%s"]'%(first,fa)).first
        for _ in range(25):
            bx=loc.bounding_box()
            if bx and bx['width']>300: break
            pg.mouse.move(720,450); pg.keyboard.down('Control'); pg.mouse.wheel(0,-150); pg.keyboard.up('Control'); pg.wait_for_timeout(60)
        pg.wait_for_timeout(300)
        for _ in range(30):
            bx=loc.bounding_box()
            if bx and 80<bx['y']+bx['height']/2<820 and 40<bx['x']+bx['width']/2<1400: break
            dx=0 if not bx else (150 if bx['x']+bx['width']/2>1400 else (-150 if bx['x']+bx['width']/2<40 else 0)); dy=0 if not bx else (150 if bx['y']+bx['height']/2>820 else (-150 if bx['y']+bx['height']/2<80 else 0))
            pg.mouse.move(720,450); pg.mouse.wheel(dx,dy); pg.wait_for_timeout(60)
        pg.wait_for_timeout(300); bx=loc.bounding_box()
        pg.mouse.click(bx['x']+bx['width']/2,bx['y']+bx['height']/2); pg.wait_for_timeout(1500)
        return (pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].findIndex(l=>l.classList.contains('is-on'))==0"),'')
    step('Un clic sobre otro color lo activa sin cambiar la mesa de sitio',activate)
    if INDEP: step('Cada color conserva su propio dibujo: el primero sigue donde estaba',lambda:(rects(pg)==rA,(rects(pg),rA)))
    # volver al segundo: su dibujo movido se conserva y es distinto
    last=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].slice(-1)[0].getAttribute('data-pgrow')")
    if INDEP:
        def back():
            loc=pg.locator('.pg-spec.is-preview[data-pgrow="%s"][data-pgv="%s"] textarea'%(last,fa)).first; bx=loc.bounding_box()
            pg.mouse.click(bx['x']+bx['width']/2,bx['y']+bx['height']/2); pg.wait_for_timeout(1500); rr=rects(pg)
            return (rr==rB2 and rr!=rA and rB2!=rB,(rr,rB2,rB))
        step('El segundo color conserva su dibujo movido, sin afectar al primero',back)
    # sin «a qué color aplica»
    step('Los campos ya no llevan el indicador «a qué colores aplica»',lambda:(pg.locator('.pg-layer .pgs-scope').count()==0,pg.locator('.pg-layer .pgs-scope').count()))
    # persistencia por color
    pg.reload(); pg.wait_for_timeout(2600); pg.locator('#projectGrid .project-card').first.click(); pg.wait_for_timeout(3500)
    step('Al recargar se conserva la mesa',lambda:(len(rects(pg))>=1 ,rects(pg)))
    # hoja de continuación: índice y sin el aviso antiguo
    tr=pid(pg,4); pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",4); pg.wait_for_timeout(1200)
    card='.pg-spec[data-pgv="%s"]:not(.is-preview)'%tr
    for k in range(7):
        (pg.locator(card+' .pgs-trimpick [data-pgtrim="Otro"]').click() if pg.locator(card+' .pgs-trimpick [data-pgtrim="Otro"]').count() else (pg.locator(card+' .pgs-addb').last.click(), pg.wait_for_timeout(300), pg.locator('#pgStMenu [data-pgtrim="Otro"]').click())); pg.wait_for_timeout(500)
    pg.wait_for_timeout(900)
    step('La hoja de continuación tiene el mismo índice y estado que las demás, sin el aviso «Misma ilustración…»',lambda:(pg.locator('.pg-lab.is-cont:not(.is-preview) .pgl-idx .pgl-nav').count()>=8 and 'Misma ilustración' not in pg.evaluate("document.querySelector('.pg-layer').textContent"),pg.locator('.pg-lab.is-cont:not(.is-preview) .pgl-nav').count()))
    # crear página sin saltos
    fo=pid(pg,2); pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",2); pg.wait_for_timeout(1300)
    lab='.pg-lab[data-pglab="%s"]:not(.is-cont)'%fo
    pg.locator(lab+' .pgl-add').evaluate('e=>e.click()'); pg.wait_for_timeout(1300); pg.fill('#tabPopName','Lavados')
    pg.evaluate("window.__pan=[];window.__pt=performance.now();const f=()=>{window.__pan.push([performance.now(),window.__BOARD.panX,window.__BOARD.panY,window.__PG.focus]);window.__raf=requestAnimationFrame(f)};f()")
    pg.evaluate("window.__tc=performance.now()"); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(2600); pg.evaluate("cancelAnimationFrame(window.__raf)")
    def smooth():
        d=pg.evaluate("(()=>{const a=window.__pan.filter(x=>x[0]>=window.__tc),fin=a[a.length-1],mx=Math.max(...a.map(x=>Math.abs(x[1]-fin[1])+Math.abs(x[2]-fin[2]))),foc=window.__PG.pages.find(p=>p.v.id===window.__PG.focus);return {mx:Math.round(mx),focus:foc&&foc.name,seen:[...new Set(a.map(x=>x[3]))].length}})()")
        return (d['mx']<=40 and d['focus']=='Lavados' and d['seen']<=2,d)
    step('Al crear una página la vista no salta ni va a otra página: te quedas en la nueva',smooth)
    step('Consola sin errores',lambda:(not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2])))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
