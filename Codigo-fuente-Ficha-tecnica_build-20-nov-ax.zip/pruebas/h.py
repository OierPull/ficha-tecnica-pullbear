import json, os, shutil, sys, time, re
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8765/'
class Run:
    def __init__(s,page,logs): s.pg=page; s.logs=logs
def launch(p,profile,w=1440,h=900,fresh=True,mobile=False):
    path='profile/'+profile
    if fresh and os.path.exists(path): shutil.rmtree(path)
    ctx=p.chromium.launch_persistent_context(path,viewport={'width':w,'height':h},accept_downloads=True,
        has_touch=mobile,is_mobile=mobile,device_scale_factor=1)
    return ctx
def new_page(ctx):
    pg=ctx.new_page(); logs=[]
    if os.environ.get('NOLEGACY'): pg.add_init_script("try{localStorage.setItem('pb-test-noexample','1')}catch(e){}")
    pg.on('console',lambda m: logs.append(('console.'+m.type,m.text[:240])) if m.type in('error','warning') else None)
    pg.on('pageerror',lambda e: logs.append(('pageerror',str(e)[:240])))
    pg.on('requestfailed',lambda r: logs.append(('reqfailed',r.url[:100])))
    pg.on('dialog',lambda d: d.accept())
    return pg,logs
def open_sheet(pg,file,new=False):
    pg.goto(BASE+file); pg.wait_for_timeout(1200)
    if pg.locator('#technicalSheetApp').is_visible(): return
    pg.locator('#projectGrid > *').first.click(); pg.wait_for_timeout(1500)
def thumb(pg,label_sub):
    # \u00edndice de miniatura por etiqueta (aria-label de la tarjeta)
    return pg.evaluate("(l)=>{const a=[...document.querySelectorAll('[data-gallery-index]')];return a.findIndex(c=>(c.innerText+' '+(c.getAttribute('aria-label')||'')+' '+(c.querySelector('img')?c.querySelector('img').alt:'')).toLowerCase().includes(l.toLowerCase()))}",label_sub)
def select_thumb(pg,i):
    el=pg.locator('[data-select-index]').nth(i)
    try: el.click(timeout=3000)
    except Exception: el.dispatch_event('click')
    pg.wait_for_timeout(600)
def thumb_index(pg,label): return thumb(pg,label)
def sections(pg): return pg.evaluate("[...document.querySelectorAll('#sections .section-name')].map(e=>e.innerText.trim())")
class R:
    def __init__(s): s.rows=[]
    def add(s,name,ok,detail=''): s.rows.append((name,ok,detail)); print(('PASS' if ok else 'FAIL'),'|',name,('| '+str(detail)) if detail else '')
import subprocess,glob
def pdf_info(path):
    n=int(re.search(r'Pages:\s+(\d+)',subprocess.run(['pdfinfo',path],capture_output=True,text=True).stdout).group(1))
    tx=[subprocess.run(['pdftotext','-f',str(i),'-l',str(i),path,'-'],capture_output=True,text=True).stdout for i in range(1,n+1)]
    return n,None,tx
def export_pdf(pg,tag,colors=('Negro',),changes=False,wait=45):
    os.makedirs('pdfs',exist_ok=True); got=[]
    def on_dl(d):
        f='pdfs/%s__%02d.pdf'%(tag,len(got)+1); d.save_as(f); got.append((d.suggested_filename,f))
    pg.on('download',on_dl); pg.locator('#pdfExportOpen').click(); pg.wait_for_timeout(700)
    btns=pg.locator('#pdfColorButtons [data-pdf-colorbtn]')
    if btns.count() and pg.locator('#pdfColorButtons').is_visible():
        names=btns.evaluate_all("l=>l.map(b=>b.dataset.name)"); order=[c for c in names if c in colors] or names[:1]
        for lab in order:
            n0=len(got); pg.locator('#pdfColorButtons [data-pdf-colorbtn][data-name="%s"]'%lab).click(); t=0
            while t<wait*2 and len(got)<=n0: pg.wait_for_timeout(500); t+=1
        try: pg.locator('#pdfExportClose').click(timeout=1500)
        except Exception: pass
    else:
        pg.locator('#pdfExportStart').click(); t=0
        while t<wait*2 and not got: pg.wait_for_timeout(500); t+=1
    pg.remove_listener('download',on_dl); return got

def empty_click(pg):
    """Pulsa en un punto vacío de la mesa (solo lienzo, fuera de hojas y tarjetas) para deseleccionar."""
    pt=pg.evaluate("""()=>{const host=document.querySelector('.board-host');if(!host)return [5,880];const c=host.querySelector('canvas');const P=window.__PG,v=window.__pgV&&window.__pgV(),hr=host.getBoundingClientRect();
      const inSheet=(x,y)=>{if(!P||!v)return false;const wx=(x-hr.left-v.ox)/v.k,wy=(y-hr.top-v.oy)/v.k;return P.pages.some(p=>wx>=p.ox-40&&wx<=p.ox+(P.SHW+P.VG)*(p.chunks||1)+40)&&wy>-120&&wy<P.SHH+(P.ROWG||400)*4};
      const cands=[];for(let y=hr.bottom-30;y>hr.top+90;y-=37)for(let x=hr.left+8;x<hr.right-8;x+=61)cands.push([x,y]);
      for(const [x,y] of cands){const e=document.elementFromPoint(x,y);if(e&&(e.tagName==='CANVAS'||(e.classList&&e.classList.contains('board-ov')))&&host.contains(e)&&!inSheet(x,y))return [x,y]}
      for(const [x,y] of cands){const e=document.elementFromPoint(x,y);if(e&&(e.tagName==='CANVAS'||(e.classList&&e.classList.contains('board-ov')))&&host.contains(e))return [x,y]}return [5,880]}""")
    print('MUESTRA',pg.evaluate("()=>{const hr=document.querySelector('.board-host').getBoundingClientRect();return [[hr.left+20,hr.bottom-40],[hr.left+300,hr.top+150],[hr.right-30,hr.bottom-60]].map(([x,y])=>{const e=document.elementFromPoint(x,y);return e?e.tagName+'.'+String(e.className&&e.className.baseVal!==undefined?e.className.baseVal:e.className).slice(0,30):null})}")) if __import__('os').environ.get('DBGC') else None
    print('PUNTO',pt,pg.evaluate('([x,y])=>{const e=document.elementFromPoint(x,y);return e?e.tagName+"."+String(e.className).slice(0,30):null}',pt)) if __import__('os').environ.get('DBGC') else None
    pg.mouse.click(pt[0],pt[1])
