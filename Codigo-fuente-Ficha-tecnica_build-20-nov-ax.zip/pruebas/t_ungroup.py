# Desagrupar: icono claro y atajo Cmd/Ctrl + Mayús + G
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'ung',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','U'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    sk=pg.evaluate("window.__PG.pages[1].v.id"); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1800)
    b=pg.locator('.board-ctxbar [data-bgrp="ungroup"]')
    vis=b.count() and b.first.is_visible()
    ic=b.first.inner_html() if b.count() else ''
    r.add('Desagrupar tiene un icono claro (marco discontinuo con dos piezas)','stroke-dasharray' in ic and 'Mayús + G' in (b.first.get_attribute('title') or ''),(vis,(b.first.get_attribute('title') if b.count() else None)))
    n0=pg.evaluate("window.__BOARD.objects.length")
    pg.keyboard.press('Control+Shift+G'); pg.wait_for_timeout(900)
    n1=pg.evaluate("window.__BOARD.objects.length")
    r.add('Cmd/Ctrl + Mayús + G desagrupa el dibujo en piezas',n1>n0,(n0,n1))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
