# Tarjeta de carpeta con los mismos apartados abajo que una tarjeta de ficha
import os
os.environ['NOLEGACY']='1'
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'cardt',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(1800)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Ficha suelta'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(2300)
    pg.locator('#metaSupplierValue').fill('Proveedor 3'); pg.wait_for_timeout(400); pg.locator('#returnToProjects').click(); pg.wait_for_timeout(700)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Baggy barrel jeans'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(2300)
    pg.locator('#metaSupplierValue').fill('showzone'); pg.wait_for_timeout(300); pg.evaluate("window.__pbAddSupplier('copy','Proveedor ejemplo')"); pg.wait_for_timeout(2600)
    pg.locator('#returnToProjects').click(); pg.wait_for_timeout(900)
    fol=pg.locator('#projectGrid .pb-folder').first; card=pg.locator('#projectGrid .project-card').first
    sf=fol.evaluate("e=>[...e.querySelector('.project-card-body').children].map(c=>c.className)"); sc=card.evaluate("e=>[...e.querySelector('.project-card-body').children].map(c=>c.className)")
    r.add('La parte de abajo de la carpeta tiene los mismos apartados que una ficha',sf==sc,(sf,sc))
    t=fol.locator('.project-card-body').inner_text()
    r.add('Sin «Carpeta», sin nombre de carpeta y sin «N fichas · N proveedores»',('Carpeta' not in t and 'fichas ·' not in t and fol.locator('.pb-folder-kicker:visible, .pb-folder-n:visible').count()==0),t.replace('\n',' | '))
    r.add('Título y prenda iguales que en la ficha (de su primera ficha)',fol.locator('.project-card-title').inner_text()=='Baggy barrel jeans' and fol.locator('.project-card-sub').inner_text()==card.locator('.project-card-sub').inner_text(),fol.locator('.project-card-title').inner_text())
    r.add('Colores como en la ficha y, abajo, sus proveedores en pastillas',fol.locator('.project-card-colors li').count()==2 and fol.locator('.project-card-foot .pb-suppill').all_inner_texts()==['showzone','Proveedor ejemplo'],fol.locator('.project-card-foot').inner_text())
    st=pg.evaluate("(()=>{const a=document.querySelector('#projectGrid .pb-folder .project-card-title'),b=document.querySelector('#projectGrid .project-card .project-card-title');const f=e=>{const c=getComputedStyle(e);return [c.fontSize,c.fontWeight,c.color]};return [f(a),f(b)]})()")
    r.add('Mismo estilo de título en carpeta y ficha',st[0]==st[1],st)
    fol.hover(); pg.wait_for_timeout(200); r.add('La carpeta ya no muestra «Ver fichas» (diseño minimalista)',not fol.locator('[data-pbf-view]').is_visible(),'')
    pg.mouse.move(2,2); pg.wait_for_timeout(200); g=pg.locator('#projectGrid').bounding_box(); pg.screenshot(path='cards.png',clip={'x':g['x'],'y':g['y'],'width':min(760,g['width']),'height':min(560,g['height'])})
    r.add('Consola sin errores',not [l for l in lg if 'error' in str(l).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
