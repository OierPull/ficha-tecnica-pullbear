# Fabric sin el campo «Color» (en fichas nuevas y existentes), y sin pedirlo como obligatorio
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'fabc',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','FC'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    fa=pg.evaluate("window.__PG.pages.find(p=>p.name==='Fabric').v.id")
    labs=lambda:pg.evaluate("id=>[...document.querySelectorAll('.pg-layer .pg-spec[data-pgv=\"'+id+'\"]:not(.is-preview) .pgs-f .pgs-lab')].map(e=>{return (e.tagName==='INPUT'?e.value:e.textContent).replace('*','').trim()})",fa)
    l0=labs()
    r.add('Fabric ya no tiene el campo «Color»','Color' not in l0 and any('Referencia del tejido' in x for x in l0),l0)
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",fa); pg.wait_for_timeout(1000)
    pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) .pgs-addb'%fa).last.click(); pg.wait_for_timeout(1500)
    l1=labs()
    r.add('Un apartado nuevo de Fabric tampoco lo trae','Color' not in l1 and len(l1)>len(l0),l1)
    pg.locator('#pdfExportOpen').click(); pg.wait_for_timeout(800)
    rows=pg.evaluate("[...document.querySelectorAll('#pgPdfWarn .pg-mf-row b')].map(b=>b.textContent)")
    r.add('El aviso del PDF ya no pide «Color» en Fabric','Color' not in rows,rows)
    r.add('Linning conserva su «Color»',pg.evaluate("(()=>{const P=window.__PG,p=P.pages.find(x=>x.name==='Linning');return [...document.querySelectorAll('.pg-layer .pg-spec[data-pgv=\"'+p.v.id+'\"]:not(.is-preview)')].some(s=>[...s.querySelectorAll('.pgs-lab')].some(l=>{return (l.tagName==='INPUT'?l.value:l.textContent).replace('*','').trim()==='Color'}))})()"),'')
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
