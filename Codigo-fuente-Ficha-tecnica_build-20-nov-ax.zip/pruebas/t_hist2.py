# El reloj de versiones aparece en los campos que cambiaron y muestra los cambios al pasar el ratón
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'hist2',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Hist'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    fa=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id"); did=pg.evaluate("window.__PG.pages.find(x=>x.i===0).v.id")
    pg.locator('.pg-lab[data-pglab="%s"] [data-pgnav="%s"]'%(did,fa)).evaluate('e=>e.click()'); pg.wait_for_timeout(1300)
    card='.pg-spec[data-pgv="%s"]:not(.is-preview)'%fa
    t=pg.locator(card+' textarea').first; t.click(); t.fill('Popelín algodón'); empty_click(pg); pg.wait_for_timeout(600)
    pg.locator('[data-pbh-ver]').click(); pg.wait_for_timeout(300); pg.locator('[data-pbh-new]').click(); pg.wait_for_timeout(1800)
    pg.evaluate("id=>document.querySelector('#visualGallery [data-select-index=\"2\"]').click()",fa); pg.wait_for_timeout(1000)
    t=pg.locator(card+' textarea').first; t.click(); t.fill('Popelín poliéster'); empty_click(pg); pg.wait_for_timeout(1200)
    n=pg.locator('.pg-layer .pgs-hist').count()
    r.add('El campo que cambió entre versiones muestra el reloj de historial',n>=1,n)
    ok=False; txt=''
    if n:
        pg.locator('.pg-layer .pgs-hist').first.hover(); pg.wait_for_timeout(600)
        vis=pg.locator('#pbHistPop').is_visible() if pg.locator('#pbHistPop').count() else False
        txt=pg.locator('#pbHistPop').inner_text() if pg.locator('#pbHistPop').count() else ''
        ok=vis and 'V1' in txt and 'algodón' in txt and 'poliéster' in txt
    r.add('Al pasar el ratón por el reloj se ven los valores de cada versión',ok,txt[:120])
    pg.mouse.move(700,860); pg.wait_for_timeout(500)
    r.add('…y se oculta al quitar el ratón',not (pg.locator('#pbHistPop').count() and pg.locator('#pbHistPop').is_visible()),'')
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
