# Diálogo de exportar y PDF alineados con los cambios: nombres nuevos, colores independientes, cuadrícula numerada
import os,glob,subprocess
from h import *
from PIL import Image
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def reds(pdf):
    for f in glob.glob('audit/p2-*.png'): os.remove(f)
    subprocess.run(['pdftoppm','-r','50','-png',pdf,'audit/p2'])
    best=0
    for f in sorted(glob.glob('audit/p2-*.png')):
        im=Image.open(f).convert('RGB'); W,H=im.size; n=0
        for x in range(0,int(W*0.68),2):
            for y in range(int(H*0.12),int(H*0.95),2):
                p=im.getpixel((x,y))
                if abs(p[0]-214)<30 and abs(p[1]-69)<30 and abs(p[2]-69)<30: n+=1
        best=max(best,n)
    return best
def text(pdf): return subprocess.run(['pdftotext','-layout',pdf,'-'],capture_output=True,text=True).stdout
with sync_playwright() as p:
    ctx=launch(p,'pdf2',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','PDF2'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('19-4052','18-1664'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
    li=pg.evaluate("window.__PG.pages.find(x=>x.i===3).v.id"); pg.evaluate("id=>document.querySelector('.pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",li); pg.wait_for_timeout(1300)
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500); empty_click(pg)
    pg.locator('.pg-grid[data-pggrid="%s"] .pg-gbar-v'%li).click(); pg.wait_for_timeout(1500)
    pg.evaluate("window.__PG&&(window.__PG.pdfOk=true)")
    pg.locator('#pdfExportOpen').click(); pg.wait_for_timeout(900)
    names=pg.evaluate("[...document.querySelectorAll('#pdfPageList .pdf-page-option strong')].map(e=>e.textContent.trim())")
    r.add('El diálogo usa los nombres nuevos de las páginas',('Diseño' in names and 'Linning' in names and 'Identificación' not in names and 'Forro' not in names),names)
    btn=pg.evaluate("[...document.querySelectorAll('#pdfColorButtons .pdf-color-btn')].map(b=>b.textContent)")
    r.add('Cada color tiene su botón con el nombre y «Descargar PDF»',len(btn)==2 and all('Descargar PDF' in b for b in btn) and any('Fiery Red' in b for b in btn),btn)
    tab=pg.evaluate("(()=>{const t=document.querySelector('.pdfx-tab.is-on'),a=getComputedStyle(t);return [a.backgroundColor,a.color]})()")
    r.add('El proveedor seleccionado se ve (pastilla oscura con texto claro)',tab[0]!=tab[1],tab)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
    if pg.locator('#pdfExportClose').is_visible(): pg.locator('#pdfExportClose').click(); pg.wait_for_timeout(300)
    [os.remove(x) for x in glob.glob('pdfs/pdf2__*.pdf')]
    got=export_pdf(pg,'pdf2',colors=('Classic Blue','Fiery Red'),wait=60)
    files={n:f for n,f in got}
    blue=[f for n,f in got if 'Blue' in n]; red=[f for n,f in got if 'Red' in n]
    r.add('Se descarga un PDF por color',len(blue)==1 and len(red)==1,[n for n,f in got])
    if red:
        tr=text(red[0]); nr=reds(red[0])
        r.add('PDF del color con la cuadrícula: página «Linning» con sus bloques vinculados (Linning y Linning 2)',('Linning' in tr and 'Linning 2' in tr),'')
        r.add('…y los números de las casillas en rojo sobre la imagen',nr>40,nr)
    if blue:
        tb=text(blue[0]); nb=reds(blue[0])
        r.add('El PDF del otro color es independiente: sin esa cuadrícula ni sus números',('Forro 2' not in tb) and nb<20,(nb,'Forro 2' in tb))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
