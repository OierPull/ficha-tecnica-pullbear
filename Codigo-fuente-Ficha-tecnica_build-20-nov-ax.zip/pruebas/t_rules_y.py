# Reglas de la ficha: obligatorios, campos por página, páginas fijas, botones de añadir, tipos de trim, aviso del PDF y nuevo color
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def scr(pg,wx,wy): return pg.evaluate("([x,y])=>{const r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV(),P=window.__PG;return [r.left+v.ox+(x+P.DX)*v.k,r.top+v.oy+y*v.k]}",[wx,wy])
def pid(pg,i): return pg.evaluate("i=>window.__PG.pages.find(x=>x.i===i).v.id",i)
def tab(pg,i): pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",str(('%d'%i))); pg.wait_for_timeout(900)
def labels(pg,sel): return pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-blk')].map(b=>[...b.querySelectorAll('.pgs-f')].map(f=>{const l=f.querySelector('.pgs-lab');return (l.value||l.firstChild.textContent).trim()}))",sel)
with sync_playwright() as p:
    ctx=launch(p,'rules_y',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Reglas'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    idc='.pg-spec[data-pgv="%s"]'%pid(pg,0)
    req=pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-lab.is-req')].map(e=>e.firstChild.textContent.trim())",idc)
    r.add('Identificación: obligatorios todos menos Colores y Patrón',sorted(req)==sorted(['Referencia','Departamento','Temporada','Proveedor','Fecha']),req)
    r.add('…los obligatorios no se pueden borrar ni renombrar',pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-f.is-req')].every(f=>!f.querySelector('.pgs-delf')&&!f.querySelector('input.pgs-lab'))",idc),'')
    # Tejido
    tab(pg,2); tc='.pg-spec[data-pgv="%s"]'%pid(pg,2)
    ab=pg.locator(tc+' .pgs-addb').first; r.add('El botón de añadir usa la palabra de la página («+ Añadir tejido»)',ab.inner_text().strip()=='+ Añadir tejido',ab.inner_text())
    ab.click(); pg.wait_for_timeout(1200)
    tl=labels(pg,tc); treq=pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-lab.is-req')].map(e=>e.firstChild.textContent.trim())",tc)
    r.add('Tejido: solo «Referencia del tejido», «Color» y «Acabado»',tl and tl[-1]==['Referencia del tejido','Color','Acabado'],tl)
    r.add('…y «Acabado» es el único opcional',sorted(set(treq))==['Color','Referencia del tejido'],treq)
    # Dibujo plano
    tab(pg,1); dox=pg.evaluate("window.__PG.pages.find(x=>x.i===1).ox"); dc='.pg-spec[data-pgv="%s"]'%pid(pg,1)
    pg.locator('[data-btool="ellipse"]').click(); a=scr(pg,dox+150,150); b=scr(pg,dox+300,300); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(1200); pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
    dl=labels(pg,dc)
    r.add('Dibujo plano: cada detalle tiene un único campo «Descripción», opcional',dl and dl[0]==['Descripción'] and pg.locator(dc+' .pgs-lab.is-req').count()==0,dl)
    print('ANTES',pg.locator('#colorDialog').is_visible()); empty_click(pg); pg.wait_for_timeout(300); print('DESPUES',pg.locator('#colorDialog').is_visible())
    # Trims
    tab(pg,4); trc='.pg-spec[data-pgv="%s"]'%pid(pg,4)
    pg.locator(trc+' .pgs-addb').first.click(); pg.wait_for_timeout(400)
    menu=pg.locator('#pgStMenu.pg-trimmenu')
    r.add('Trims: «+ Añadir trim» pregunta el tipo (Botón, Cremallera, Hilo, Otro)',menu.is_visible() and all(t in menu.inner_text() for t in ('Botón','Cremallera','Hilo','Otro')),'')
    menu.locator('[data-pgtrim="Botón"]').click(); pg.wait_for_timeout(1200)
    trl=labels(pg,trc); names=pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-tin')].map(e=>e.value)",trc)
    r.add('…crea el trim del tipo elegido, con «Referencia» en lugar de «Código»',any('Bot' in n for n in names) and any('Referencia' in l and 'Código' not in l for l in trl),(names,trl[-1:]))
    # páginas fijas
    dels=pg.evaluate("[...document.querySelectorAll('.pg-lab:not(.is-cont) .pgl-del')].map(b=>b.closest('.pg-lab').querySelector('.pgl-cur').textContent.trim())")
    r.add('Solo se puede eliminar la página Forro (las demás son obligatorias)',dels==['Linning'],dels)
    tab(pg,2); tx=pg.evaluate("(()=>{const c=document.querySelector('#visualGallery .gallery-card:has(.gallery-thumb.active) .tab-del');return c?getComputedStyle(c).display:'no'})()")
    tab(pg,3); fx=pg.evaluate("(()=>{const c=document.querySelector('#visualGallery .gallery-card:has(.gallery-thumb.active) .tab-del');return c?getComputedStyle(c).display:'no'})()")
    r.add('…tampoco desde la pestaña: sin «×» en Tejido, con «×» en Forro',tx=='none' and fx!='none',(tx,fx))
    # aviso del PDF
    pg.locator('#pdfExportOpen').click(); pg.wait_for_timeout(500)
    w=pg.locator('#pgPdfWarn')
    r.add('Al descargar con obligatorios vacíos, avisa de cuáles faltan',w.is_visible() and 'Departamento' in w.inner_text() and 'Referencia del tejido' in w.inner_text(),'')
    w.locator('[data-pgwarn="fix"]').click(); pg.wait_for_timeout(1200)
    r.add('«Revisar» lleva al primer campo que falta y los marca',pg.locator('.pgs-f.is-req.is-empty.show-missing').count()>0 and pg.evaluate("!!document.activeElement.closest('.pgs-f.is-req')"),'')
    pg.locator('#pdfExportOpen').click(); pg.wait_for_timeout(500); pg.locator('#pgPdfWarn [data-pgwarn="go"]').click(); pg.wait_for_timeout(1200)
    r.add('«Descargar igualmente» abre la exportación',pg.locator('.pdf-export-box').count()>0 and pg.locator('.pdf-export-box').first.is_visible(),'')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
    for x in ('#pdfExportClose','.pdf-export-box [data-close]','.pdf-export-box .modal-close'):
        if pg.locator(x).count() and pg.locator(x).first.is_visible(): pg.locator(x).first.click(); break
    pg.wait_for_timeout(400)
    # nuevo color con las mismas opciones (tarjetas) y elegir el color de origen
    def addcolor(code,mode='copy',src=None):
        pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600)
        pg.locator('#cdPantone').fill(code); pg.wait_for_timeout(200)
        if pg.locator('form.color-dialog .pb-copt').count():
            if mode=='empty': pg.locator('form.color-dialog .pb-copt:has(input[value="empty"])').click()
            elif src: pg.locator('form.color-dialog select[name="pbcsrc"]').select_option(src)
        pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1500)
    addcolor('19-4052'); 
    tab(pg,2); f=pg.locator(tc+' .pgs-f:has(.pgs-lab.is-req) textarea').first; f.click(); f.fill('DEN-001'); pg.wait_for_timeout(500); empty_click(pg); pg.wait_for_timeout(500)
    firstcol=pg.evaluate("selectedColors[active]") if False else pg.evaluate("(()=>{const c=document.querySelector('#colorSwatches .color-chip[aria-pressed=\"true\"]');return c&&c.getAttribute('data-color-id')})()")
    pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600)
    cards=pg.locator('form.color-dialog .pb-copt').count()
    r.add('«Nuevo color» ofrece las opciones en tarjetas, como «Nuevo proveedor» (duplicar / vacío)',cards==2,cards)
    pg.locator('#cdPantone').fill('18-1664'); pg.locator('form.color-dialog .pb-copt:has(input[value="empty"])').click(); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1500)
    tab(pg,2); v_empty=pg.locator(tc+' .pgs-f:has(.pgs-lab.is-req) textarea').first.input_value()
    r.add('«Color vacío» crea el color sin contenido',v_empty=='',v_empty)
    pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600)
    hassel=pg.locator('form.color-dialog select[name="pbcsrc"]').count()==1
    pg.locator('#cdPantone').fill('14-4122'); pg.locator('form.color-dialog select[name="pbcsrc"]').select_option(firstcol); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
    tab(pg,2); v_copy=pg.locator(tc+' .pgs-f:has(.pgs-lab.is-req) textarea').first.input_value()
    r.add('Se puede elegir de qué color copiar (copia el contenido del primero aunque estuvieras en otro)',hassel and v_copy=='DEN-001',(hassel,v_copy))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
