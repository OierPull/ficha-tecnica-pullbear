# Transiciones, arrastrar apartados, «+» junto a la activa y sin miniaturas en el panel
import os
os.environ['NOLEGACY']='1'
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def names(pg): return pg.evaluate("[...document.querySelectorAll('#visualGallery > .gallery-card:not([hidden]) .tab-name')].map(e=>e.textContent.trim())")
def act(pg): return pg.evaluate("(document.querySelector('#visualGallery > .gallery-card:has(.gallery-thumb.active) .tab-name')||{}).textContent")
def card(pg,n): return pg.locator('#visualGallery > .gallery-card:not([hidden])').filter(has=pg.locator('.tab-name',has_text=n)).first
def drag(pg,src,dst,cancel=False):
    a=card(pg,src).bounding_box(); b=card(pg,dst).bounding_box()
    pg.mouse.move(a['x']+a['width']/2,a['y']+a['height']/2); pg.mouse.down(); pg.mouse.move(a['x']+a['width']/2-10,a['y']+20,steps=3)
    pg.mouse.move(b['x']+8,b['y']+a['height']/2,steps=8); pg.wait_for_timeout(100)
    if cancel: pg.keyboard.press('Escape')
    pg.mouse.up(); pg.wait_for_timeout(700)
with sync_playwright() as p:
    ctx=launch(p,'tabs',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(1800)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','UNO'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(2300)
    pg.locator('#metaSupplierValue').fill('Prov A'); pg.wait_for_timeout(400)
    pg.evaluate("window.__pbAddSupplier('copy','Prov B')"); pg.wait_for_timeout(2600)
    c1=pg.locator('#colorSwatches .color-chip').nth(1)
    if c1.get_attribute('aria-pressed')!='true': c1.click(); pg.wait_for_timeout(700)
    # cambio de proveedor: una sola carga y ya en el primer color
    pg.evaluate("window.__opens=0;window.__rv=0;const o=window.openPortalProject;")
    t=pg.evaluate("""()=>new Promise(res=>{const t0=performance.now();const b=[...document.querySelectorAll('.pbh-sname')].find(x=>x.getAttribute('aria-pressed')==='false');const name=b.childNodes[0].textContent.trim();let firstOk=-1;b.click();const iv=setInterval(()=>{const on=document.querySelector('.pbh-tab.is-on .pbh-sname');const c=document.querySelector('#colorSwatches .color-chip');if(firstOk<0&&on&&on.childNodes[0].textContent.trim()===name&&c&&c.getAttribute('aria-pressed')==='true')firstOk=Math.round(performance.now()-t0)},5);setTimeout(()=>{clearInterval(iv);const c=document.querySelector('#colorSwatches .color-chip');res([firstOk,c&&c.getAttribute('aria-pressed')])},1200)})""")
    r.add('Cambiar de proveedor: la cabecera y el primer color quedan listos en una sola carga (%s ms)'%t[0],0<=t[0]<400 and t[1]=='true',t)
    # entrar en una ficha desde la pantalla principal: cabecera al instante
    pg.locator('#returnToProjects').click(); pg.wait_for_timeout(800)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','DOS'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(2300)
    pg.locator('#metaSupplierValue').fill('Prov Z'); pg.wait_for_timeout(500); pg.locator('#returnToProjects').click(); pg.wait_for_timeout(800)
    lag=pg.evaluate("""()=>new Promise(res=>{const c=[...document.querySelectorAll('#projectGrid .pb-folder')].find(x=>/UNO/.test(x.textContent));c.click();const t0=performance.now();requestAnimationFrame(()=>{const sup=document.querySelector('.pbh-tab.is-on .pbh-sname');res([Math.round(performance.now()-t0),sup?sup.childNodes[0].textContent.trim():null])})})""")
    r.add('Al entrar en una ficha, la cabecera ya muestra sus proveedores en el primer fotograma (no los de la anterior)',lag[1] in ('Prov A','Prov B'),lag)
    pg.wait_for_timeout(1500)
    # apartados
    select_thumb(pg,thumb(pg,'Fabric')); pg.wait_for_timeout(400)
    an=pg.evaluate("[...document.querySelectorAll('#sections .item > .fields')].map(f=>getComputedStyle(f).animationName)")
    r.add('Cambiar de apartado es instantáneo (sin animación de aparición del panel)',all(a=='none' for a in an),an[:3])
    ad=pg.evaluate("(()=>{const a=document.querySelector('#visualGallery .tab-add'),c=document.querySelector('#visualGallery > .gallery-card:has(.gallery-thumb.active)');return Math.round(a.getBoundingClientRect().left-c.getBoundingClientRect().right)})()")
    r.add('El «+» aparece justo a la derecha de la pestaña seleccionada',-2<=ad<=12,ad)
    n0=names(pg); drag(pg,'Linning','Fabric'); n1=names(pg)
    r.add('Arrastrar «Forro» delante de «Tejido» cambia el orden',n1.index('Linning')==n1.index('Fabric')-1 and len(n1)==len(n0),n1[:5])
    r.add('…y el apartado abierto sigue siendo el mismo (Tejido)',act(pg)=='Fabric',act(pg))
    drag(pg,'Trims','Sketch',cancel=True); r.add('Esc cancela el arrastre',names(pg)==n1,names(pg)[:5])
    drag(pg,'Diseño','Linning'); r.add('Identificación queda fija la primera',names(pg)[0]=='Diseño' and names(pg)==n1,names(pg)[:4])
    card(pg,'Trims').locator('.gallery-thumb').click(); pg.wait_for_timeout(500); r.add('Un clic normal sigue seleccionando el apartado',act(pg)=='Trims',act(pg))
    pg.reload(); pg.wait_for_timeout(2600)
    if not pg.locator('#visualGallery').is_visible():
        pg.locator('#projectGrid .pb-folder').filter(has_text='UNO').first.click(); pg.wait_for_timeout(2400)
    r.add('El orden se mantiene al recargar',names(pg)[:4]==n1[:4],names(pg)[:4])
    pg.evaluate("(()=>{const it=document.querySelector('#sections .item');const d=document.createElement('div');d.className='linked-crop-preview';d.innerHTML='<canvas width=80 height=50></canvas>';it.appendChild(d)})()")
    r.add('El panel no muestra miniaturas de recorte',pg.evaluate("[...document.querySelectorAll('#sections .linked-crop-preview')].every(e=>e.offsetParent===null)"),'')
    r.add('Consola sin errores',not [l for l in lg if 'error' in str(l).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
