# Clics «humanos» (pulsar, esperar 150 ms, soltar) en los controles principales: todos funcionan a la primera
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'clk',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','CL'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    def human(loc_or_xy,hold=150):
        if isinstance(loc_or_xy,(list,tuple)): x,y=loc_or_xy
        else:
            b=loc_or_xy.bounding_box(); x,y=b['x']+b['width']/2,b['y']+b['height']/2
        pg.mouse.move(x,y); pg.mouse.down(); pg.wait_for_timeout(hold); pg.mouse.up(); pg.wait_for_timeout(600)
    def go(name):
        pid=pg.evaluate("n=>window.__PG.pages.find(p=>p.name===n).v.id",name); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",pid); pg.wait_for_timeout(1200); return pid
    W="([wx,wy])=>{const v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+wx*v.k,hr.top+v.oy+wy*v.k]}"
    di=pg.evaluate("window.__PG.pages[0].v.id")
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500)
    pg.locator('.pg-grid[data-pggrid="%s"] .pg-gbar-v'%di).click(); pg.wait_for_timeout(1300); empty_click(pg); pg.wait_for_timeout(300)
    o=pg.evaluate("(()=>{const o=window.__BOARD.objects.find(o=>o.type==='image'&&!o.pen);return [o.id,o.x+o.w/2,o.y+o.h/2]})()")
    human(pg.evaluate(W,o[1:]))
    r.add('Seleccionar una imagen a la primera',pg.evaluate("window.__BOARD.sel")==o[0],pg.evaluate("window.__BOARD.sel"))
    human(pg.locator('.board-ctxbar [data-pgfittrig]'))
    op=pg.evaluate("!document.querySelector('.board-ctxbar .pg-fitmenu').hidden")
    if op: human(pg.locator('.board-ctxbar [data-pgfitopt="height"]'))
    r.add('Abrir el ajuste y elegir «Alto» a la primera',op and pg.evaluate("id=>window.__BOARD.objects.find(o=>o.id===id).fit",o[0])=='height',op)
    pg.keyboard.press('Escape'); empty_click(pg); pg.wait_for_timeout(300)
    li=go('Linning'); card='.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview)'%li
    n0=pg.locator(card+' .pgs-blk').count(); human(pg.locator(card+' .pgs-addb').last); n1=pg.locator(card+' .pgs-blk').count()
    r.add('«+ Añadir linning» a la primera',n1==n0+1,(n0,n1))
    human(pg.locator(card+' .pgs-blk').nth(1).locator('.pgs-bh .pgs-del')); pg.wait_for_timeout(700); n2=pg.locator(card+' .pgs-blk').count()
    r.add('La «×» de un apartado lo elimina a la primera',n2==n1-1,(n1,n2))
    human(pg.locator(card+' .pgs-bh .pgs-del').first); pg.wait_for_timeout(1500); n3=pg.locator(card+' .pgs-blk').count()
    r.add('…también el último, sin que vuelva a crearse solo',n3==0 and pg.locator(card+' .pg-specshow').count()==1,n3)
    human(pg.locator(card+' .pg-specshow')); pg.wait_for_timeout(900)
    r.add('«Campos» a la primera',pg.locator(card+' .pgs-blk').count()>=1,'')
    tr=go('Trims'); tc='.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview)'%tr
    human(pg.locator(tc+' .pgs-trimpick [data-pgtrim="Hilo"]')); pg.wait_for_timeout(900)
    r.add('Elegir un trim en el selector a la primera',pg.locator(tc+' .pgs-blk').count()==1,pg.locator(tc+' .pgs-blk').count())
    sk=go('Sketch')
    human(pg.locator('.pg-gapadd[data-after="%s"]'%sk)); pg.wait_for_timeout(1500)
    r.add('El «+» entre hojas abre «Nueva página» a la primera',pg.locator('#tabPop').count()==1,'')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(1500)
    human(pg.locator('.board-island [data-btool="rect"]'))
    r.add('Herramienta de la barra inferior a la primera',pg.evaluate("window.__BOARD.tool")=='rect','')
    a=pg.evaluate(W,[pg.evaluate("id=>window.__PG.pages.find(p=>p.v.id===id).ox",sk)+200,200]); b=[a[0]+120,a[1]+90]
    pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=5); pg.mouse.up(); pg.wait_for_timeout(400); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    rid=pg.evaluate("window.__BOARD.objects.find(o=>o.type==='rect').id"); empty_click(pg); pg.wait_for_timeout(200)
    human([a[0]+60,a[1]])
    sel=pg.evaluate("window.__BOARD.sel")==rid
    if sel: human(pg.locator('.board-ctxbar [data-pgnum="+"]'))
    sw=pg.evaluate("id=>window.__BOARD.objects.find(o=>o.id===id).sw",rid)
    r.add('Seleccionar un rectángulo y subir su grosor a la primera',sel and sw==5,(sel,sw))
    go('Fabric'); pd=pg.locator('.pg-lab[data-pglab="%s"]:not(.is-cont) [data-pgdelpage]'%li)
    bb=pd.first.bounding_box() if pd.count() else None
    if not bb or bb['x']>1400: pd=pg.locator('.no-match-xyz')
    if pd.count():
        n=pg.evaluate("window.__PG.pages.length"); human(pd.first); pg.wait_for_timeout(700)
        cf=pg.locator('.ui-confirm .ui-btn-primary, [role=dialog] button:has-text("Eliminar")')
        if cf.count() and cf.first.is_visible(): human(cf.first)
        pg.wait_for_timeout(1800)
        r.add('La papelera de página la elimina a la primera',pg.evaluate("window.__PG.pages.length")==n-1,(n,pg.evaluate("window.__PG.pages.length")))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
