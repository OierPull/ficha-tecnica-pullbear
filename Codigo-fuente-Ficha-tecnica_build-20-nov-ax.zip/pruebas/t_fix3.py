# Ajuste que siempre se aplica, eliminar «Linning 2», filas iguales a cualquier zoom
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'fix3',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','F3'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    def go(name):
        pid=pg.evaluate("n=>window.__PG.pages.find(p=>p.name===n).v.id",name); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",pid); pg.wait_for_timeout(1200); return pid
    W="([wx,wy])=>{const v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+wx*v.k,hr.top+v.oy+wy*v.k]}"
    sk=go('Sketch')
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500)
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500)
    imgs=pg.evaluate("id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id);return window.__BOARD.objects.filter(o=>o.type==='image'&&!o.pen&&o.x>=p.ox-50&&o.x<p.ox+P.SHW).map(o=>({id:o.id,cell:o.cell,fit:o.fit,x:o.x,y:o.y,w:o.w,h:o.h}))}",sk)
    # forzar que la primera ocupe la casilla 0 y la segunda quede libre y pequeña
    pg.evaluate("ids=>{const B=window.__BOARD;const a=B.objects.find(o=>o.id===ids[0]),b=B.objects.find(o=>o.id===ids[1]);a.cell=0;delete a.fit;b.fit='free';delete b.cell;b.w*=0.4;b.h*=0.4;b.x+=40;window.__boardCommit()}",[imgs[0]['id'],imgs[1]['id']]); pg.wait_for_timeout(500)
    b=pg.evaluate("id=>{const o=window.__BOARD.objects.find(o=>o.id===id);return [o.x+o.w/2,o.y+o.h/2]}",imgs[1]['id'])
    empty_click(pg); pg.wait_for_timeout(200); pg.mouse.click(*pg.evaluate(W,b)); pg.wait_for_timeout(500)
    t0=pg.evaluate("(()=>{const t=document.querySelector('.board-ctxbar [data-pgfittrig]');return t&&t.offsetParent?t.textContent.trim():null})()")
    pg.locator('.board-ctxbar [data-pgfittrig]').click(); pg.wait_for_timeout(200); pg.locator('.board-ctxbar [data-pgfitopt="contain"]').click(); pg.wait_for_timeout(500)
    o1=pg.evaluate("id=>{const o=window.__BOARD.objects.find(o=>o.id===id);return {cell:o.cell,fit:o.fit||'contain',w:o.w}}",imgs[1]['id'])
    t1=pg.evaluate("document.querySelector('.board-ctxbar [data-pgfittrig]').textContent.trim()")
    r.add('«Entera» se aplica aunque la única casilla ya esté ocupada (la imagen se encaja)',o1['cell']==0 and o1['fit']=='contain' and o1['w']>imgs[1]['w']*0.5 and t0=='Libre' and t1=='Entera',(t0,o1,t1))
    pg.locator('.board-ctxbar [data-pgfittrig]').click(); pg.wait_for_timeout(200); pg.locator('.board-ctxbar [data-pgfitopt="width"]').click(); pg.wait_for_timeout(500)
    o2=pg.evaluate("id=>{const o=window.__BOARD.objects.find(o=>o.id===id);return o.fit}",imgs[1]['id']); t2=pg.evaluate("document.querySelector('.board-ctxbar [data-pgfittrig]').textContent.trim()")
    r.add('«Ancho» también cambia la imagen y el selector lo refleja',o2=='width' and t2=='Ancho',(o2,t2))
    pg.keyboard.press('Escape'); empty_click(pg)
    # eliminar Linning 2
    li=go('Linning'); card='.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview)'%li
    pg.locator(card+' .pgs-addb').last.click(); pg.wait_for_timeout(1500)
    names=lambda:pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-tin')].map(i=>i.value)",card)
    n0=names()
    pg.locator(card+' .pgs-blk').nth(1).locator('.pgs-bh .pgs-del').click(); pg.wait_for_timeout(600)
    cf=pg.locator('.ui-confirm .ui-btn-primary, [role=dialog] button:has-text("Eliminar")')
    if cf.count() and cf.first.is_visible(): cf.first.click()
    pg.wait_for_timeout(1300); n1=names()
    r.add('La «×» de «Linning 2» lo elimina',len(n0)==2 and n1==n0[:1],(n0,n1))
    # filas iguales a cualquier zoom
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('17-1230'); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
    sk=go('Sketch')
    def sample():
        return pg.evaluate("""id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();const RI=window.__pgRI?window.__pgRI():null;return null}""",sk)
    def rowimg(tag):
        y=pg.evaluate("""id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();const pr=document.querySelector('.pg-rowslayer .pg-spec.is-preview[data-pgv="'+id+'"]');const r=pr?pr.getBoundingClientRect():null;return r?[hr.left+v.ox+(p.ox+100)*v.k,r.top,hr.left+v.ox+(p.ox+900)*v.k,r.top+(r.height*0.8)]:null}""",sk)
        return y
    reg=rowimg('a')
    ok=True; info=[]
    if reg:
        from PIL import Image
        import io
        def shot():
            b=pg.screenshot(clip={'x':reg[0],'y':reg[1],'width':max(20,reg[2]-reg[0]),'height':max(20,reg[3]-reg[1])})
            im=Image.open(io.BytesIO(b)).convert('L').resize((40,20)); return list(im.getdata())
        a=shot()
        pg.mouse.move(700,450); pg.keyboard.down('Control'); pg.mouse.wheel(0,60); pg.keyboard.up('Control'); pg.wait_for_timeout(700)
        reg=rowimg('b')
        if reg:
            b2=shot(); diff=sum(abs(x-y) for x,y in zip(a,b2))/len(a); info=round(diff,1); ok=diff<40
    r.add('La fila de otro color muestra lo mismo al cambiar de zoom (sin imágenes antiguas)',ok,info)
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
