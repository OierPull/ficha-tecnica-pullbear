# Cuadrícula vinculada a bloques numerados y ajustes de interfaz del 17-nov
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def step(name,fn):
    try:
        ok,det=fn(); r.add(name,bool(ok),det)
    except Exception as e: r.add(name,False,'EXC '+str(e)[:160])
with sync_playwright() as p:
    ctx=launch(p,'glink',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Grid'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('19-4052','18-1664'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
    d0=pg.evaluate("window.__PG.pages.find(x=>x.i===0).v.id"); li=pg.evaluate("window.__PG.pages.find(x=>x.i===3).v.id")
    pg.evaluate("id=>document.querySelector('.pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",li); pg.wait_for_timeout(1400)
    card='.pg-spec[data-pgv="%s"]:not(.is-preview)'%li; grid='.pg-grid[data-pggrid="%s"]'%li
    nb=lambda: pg.locator(card+' .pgs-blk').count()
    nums=lambda: pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-ncell')].map(e=>e.textContent)",card)
    cells=lambda: pg.evaluate("s=>[...document.querySelectorAll(s+' .pg-cellnum')].map(e=>e.textContent)",grid)
    b0=nb()
    pg.locator(grid+' .pg-gbar-v').click(); pg.wait_for_timeout(1500)
    step('«+» de columna: cada casilla queda vinculada a un bloque numerado (1 y 2) a la derecha',lambda:(nums()==['1','2'] and cells()==['1','2'] and nb()==max(b0,2),(nums(),cells(),b0,nb())))
    pg.locator(grid+' .pg-gbar-h').click(); pg.wait_for_timeout(1700)
    step('«+» de fila: aparecen los bloques 3 y 4, también numerados en sus casillas',lambda:(nums()==['1','2','3','4'] and cells()==['1','2','3','4'],(nums(),cells())))
    n4=nb(); pg.locator(grid+' [data-pgg="r-"]').click(); pg.wait_for_timeout(1700)
    step('«−» de fila: se quitan los bloques vacíos de esas casillas',lambda:(nums()==['1','2'] and nb()==n4-2,(nums(),nb(),n4)))
    # el bloque 2 con contenido: al quitar la columna se desvincula pero no se pierde
    t=pg.locator(card+' .pgs-blk').filter(has=pg.locator('.pgs-ncell',has_text='2')).locator('textarea').first
    pg.evaluate("e=>{e.focus();e.value='Vale';e.dispatchEvent(new Event('input',{bubbles:true}));e.blur()}",t.element_handle()); pg.wait_for_timeout(900)
    n2=nb(); pg.locator(grid+' [data-pgg="c-"]').click(); pg.wait_for_timeout(1700)
    step('Volver a una sola casilla: sin números y sin perder lo escrito ni el bloque',lambda:(nums()==[] and cells()==[] and nb()==n2 and pg.evaluate("s=>[...document.querySelectorAll(s+' textarea')].some(e=>e.value==='Vale')",card),(nums(),cells(),nb(),n2)))
    pg.locator(grid+' .pg-gbar-v').click(); pg.wait_for_timeout(1500)
    pg.locator(card+' .pgs-blk').filter(has=pg.locator('.pgs-ncell')).first.hover(); pg.wait_for_timeout(200)
    pg.locator(card+' .pgs-unlink').first.click(); pg.wait_for_timeout(1000)
    step('Se puede desvincular un bloque de su casilla (queda solo el otro)',lambda:(nums()==['1'] and cells()==['1'],(nums(),cells())))
    pg.locator(grid+' [data-pgg="c-"]').click(); pg.wait_for_timeout(1500)
    # casilla vacía: clic en cualquier punto abre «subir imagen»; dibujando, no
    def anyclick():
        bx=pg.locator(grid+' .pg-cell').last.bounding_box()
        with pg.expect_file_chooser(timeout=3000) as fc: pg.mouse.click(bx['x']+30,bx['y']+30)
        return (fc.value is not None,'')
    step('Un clic en cualquier punto de la casilla vacía abre «subir imagen»',anyclick)
    def drawover():
        pg.locator('[data-btool="rect"]').click(); pg.wait_for_timeout(200); n0=pg.evaluate("window.__BOARD.objects.length")
        bx=pg.locator(grid+' .pg-cell').first.bounding_box(); pg.mouse.move(bx['x']+60,bx['y']+60); pg.mouse.down(); pg.mouse.move(bx['x']+220,bx['y']+200,steps=6); pg.mouse.up(); pg.wait_for_timeout(800)
        return (pg.evaluate("window.__BOARD.objects.length")==n0+1,'')
    step('…pero con una herramienta de dibujo se dibuja encima con normalidad',drawover)
    empty_click(pg); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    # «Pendiente» siempre en la esquina
    def corner():
        bad=[]
        for _ in range(3):
            bad+=pg.evaluate("""()=>{const out=[];document.querySelectorAll('.board-host .pg-lab').forEach(l=>{const st=l.querySelector(':scope > .pg-st, :scope > .pgl-stp'),del=l.querySelector(':scope > .pgl-del');if(!st||l.offsetParent===null||l.style.visibility==='hidden')return;const a=l.getBoundingClientRect(),b=st.getBoundingClientRect();if(!b.width)return;if(del){const d=del.getBoundingClientRect();if(Math.abs(a.right-d.right)>2||b.right>d.left+1)out.push('del')}else if(Math.abs(a.right-b.right)>2)out.push(Math.round(a.right-b.right))});return out}""")
            pg.mouse.move(720,450); pg.keyboard.down('Control'); pg.mouse.wheel(0,200); pg.keyboard.up('Control'); pg.wait_for_timeout(400)
        return (not bad,bad[:5])
    step('«Pendiente» (y la papelera, si la hay, a su derecha) siempre en la esquina de cada hoja',corner)
    # bola de color: tamaño fijo con el zoom y fuera de las páginas
    def dot():
        s1=pg.evaluate("[...document.querySelectorAll('.pg-rowlab:not([hidden])')].map(e=>Math.round(e.getBoundingClientRect().width)+'x'+Math.round(e.getBoundingClientRect().height))")
        pg.mouse.move(720,450); pg.keyboard.down('Control'); pg.mouse.wheel(0,-600); pg.keyboard.up('Control'); pg.wait_for_timeout(500)
        s2=pg.evaluate("[...document.querySelectorAll('.pg-rowlab:not([hidden])')].map(e=>Math.round(e.getBoundingClientRect().width)+'x'+Math.round(e.getBoundingClientRect().height))")
        return (s1 and s2 and set(s1+s2)=={'92x30'},(s1,s2))
    step('Las burbujas de color son todas iguales y del mismo tamaño con cualquier zoom',dot)
    step('Cada burbuja es del propio color, con el código en un tono claro que se lee',lambda:(pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].every(l=>{const s=getComputedStyle(l);return s.backgroundColor!=='rgba(0, 0, 0, 0)'&&s.color!==s.backgroundColor&&/\\d|#/.test(l.textContent)})"),pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].map(l=>[getComputedStyle(l).backgroundColor,getComputedStyle(l).color])")))
    # cabecera: colores informativos y limpios
    step('Los colores del proveedor arriba no se pueden pulsar',lambda:(pg.evaluate("[...document.querySelectorAll('#colorSwatches .color-chip')].every(c=>getComputedStyle(c).pointerEvents==='none')"),''))
    step('Sin botón flotante «Añadir color»: en su lugar, «Crear nueva variante de color» en la mesa',lambda:(pg.evaluate("(()=>{const b=document.querySelector('.pg-addcol-fixed'),v=document.querySelector('.pg-addvar');return (!b||getComputedStyle(b).display==='none')&&!!v&&/Crear nueva variante de color/.test(v.textContent)})()"),''))
    # la «×» del campo no se corta
    def xvis():
        f=pg.locator(card+' .pgs-f:has(.pgs-delf)').first; f.hover(); pg.wait_for_timeout(250)
        bx=f.locator('.pgs-delf').bounding_box()
        el=pg.evaluate("([x,y])=>{const e=document.elementFromPoint(x,y);return e&&!!e.closest('.pgs-delf')}",[bx['x']+bx['width']-3,bx['y']+3])
        return (el,bx)
    step('La «×» para borrar un campo se ve entera (no se corta)',xvis)
    step('Consola sin errores',lambda:(not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2])))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
