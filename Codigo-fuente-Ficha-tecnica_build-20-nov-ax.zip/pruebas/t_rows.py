# Una fila por color, colores a la izquierda, «+ Color», índice (ordenar y «+» junto a la actual), página nueva y zoom mínimo
import os,re
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def pid(pg,i): return pg.evaluate("i=>window.__PG.pages.find(x=>x.i===i).v.id",i)
def addcolor(pg,code,mode='copy'):
    pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600); pg.locator('#cdPantone').fill(code)
    if mode=='empty': pg.locator('form.color-dialog .pb-copt[data-pbcopt="empty"]').click()
    pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
with sync_playwright() as p:
    ctx=launch(p,'rows',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Filas'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    addcolor(pg,'19-4052')
    fa=pid(pg,2); did=pid(pg,0); pg.locator('.pg-lab[data-pglab="%s"] [data-pgnav="%s"]'%(did,fa)).evaluate('e=>e.click()'); pg.wait_for_timeout(1200)
    t=pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) textarea'%fa).first; t.click(); t.fill('DEN-A'); empty_click(pg); pg.wait_for_timeout(600)
    addcolor(pg,'18-1664','empty'); addcolor(pg,'14-4122','empty')
    labs=pg.locator('.pg-rowlab').count(); prev=pg.locator('.pg-spec.is-preview[data-pgv="%s"]'%fa).count()
    r.add('Con tres colores hay tres filas en la mesa (una por color)',labs==3 and prev==2,(labs,prev))
    first=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')][0].getAttribute('data-pgrow')")
    pv=pg.evaluate("([id,c])=>{const e=document.querySelector('.pg-spec.is-preview[data-pgrow=\"'+c+'\"][data-pgv=\"'+id+'\"] textarea');return e?e.value:null}",[fa,first])
    av=pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) textarea'%fa).first.input_value()
    r.add('Cada fila muestra el contenido de su color (el primero con su referencia, el nuevo vacío)',pv=='DEN-A' and av=='',(pv,av))
    on=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].map(b=>b.classList.contains('is-on'))")
    r.add('A la izquierda de la página se ven los colores y cuál está seleccionado',on==[False,False,True],on)
    for _ in range(30):
        top=pg.evaluate("c=>document.querySelector('.pg-rowhit[data-pgrow=\"'+c+'\"]').getBoundingClientRect().top",first)
        if top>120: break
        pg.mouse.move(720,450); pg.mouse.wheel(0,-150); pg.wait_for_timeout(60)
    pg.wait_for_timeout(300)
    sy0=pg.evaluate("([id,c])=>Math.round(document.querySelector('.pg-rowhit[data-pgrow=\"'+c+'\"][data-pgv=\"'+id+'\"]').getBoundingClientRect().top)",[fa,first])
    hb=pg.locator('.pg-rowhit[data-pgrow="%s"][data-pgv="%s"]'%(first,fa)).first.bounding_box(); pg.mouse.click(hb['x']+hb['width']/2,hb['y']+hb['height']/2); pg.wait_for_timeout(1500)
    av2=pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) textarea'%fa).first.input_value()
    sy1=pg.evaluate("id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV();return Math.round(r.top+v.oy)}",fa)
    r.add('Pulsar un color lo activa y su fila pasa a ser editable con su contenido',av2=='DEN-A' and pg.locator('.pg-rowlab.is-on[data-pgrow="%s"]'%first).count()==1,av2)
    r.add('…sin que la mesa salte de sitio (la fila se queda donde estaba)',abs(sy0-sy1)<=6,(sy0,sy1))
    def bring(sel):
        for _ in range(40):
            b=pg.locator(sel).first.bounding_box()
            if b and 70<b['y']<820: return True
            pg.mouse.move(720,450); pg.mouse.wheel(0,150 if (b and b['y']>=820) else -150); pg.wait_for_timeout(60)
        return False
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(900)
    r.add('«+ Color» (botón fijo) abre el diálogo con «Duplicar otro color» y «Color vacío»',pg.locator('form.color-dialog').is_visible() and pg.locator('form.color-dialog .pb-copt').count()==2,'')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(500)
    if pg.locator('form.color-dialog').count() and pg.locator('form.color-dialog').is_visible():
        b=pg.locator('form.color-dialog button:has-text("Cancelar")')
        if b.count(): b.first.click(); pg.wait_for_timeout(400)
    # índice
    lab='.pg-lab[data-pglab="%s"]:not(.is-cont)'%fa
    r.add('Sin índice en las cabeceras (se sustituye por los «+» laterales de la hoja seleccionada)',pg.evaluate("s=>{const l=document.querySelector(s);return [...l.querySelectorAll('.pgl-nav:not(.pgl-cur),.pgl-add')].every(e=>getComputedStyle(e).display==='none')}",lab) and pg.locator('.pg-sideadd.r').count()==1,'')
    # página nueva: quedarse en ella
    fl='.pg-lab[data-pglab="%s"]:not(.is-cont)'%fa
    bring(fl); pg.locator(fl+' .pgl-add').evaluate('e=>e.click()'); pg.wait_for_timeout(1100); pg.fill('#tabPopName','Lavados'); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(2600)
    foc=pg.evaluate("(()=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===P.focus);return p&&p.name})()")
    r.add('Al crear una página te quedas en la página nueva (no vuelve a Diseño)',foc=='Lavados',foc)
    # zoom por debajo del 10 %
    pg.mouse.move(720,450)
    for _ in range(30): pg.keyboard.down('Control'); pg.mouse.wheel(0,200); pg.keyboard.up('Control'); pg.wait_for_timeout(40)
    pg.wait_for_timeout(500); z=pg.evaluate("(()=>{const e=[...document.querySelectorAll('.board-host *')].find(x=>/^\\s*\\d+\\s*%\\s*$/.test(x.textContent||'')&&x.children.length===0);return e?parseInt(e.textContent):null})()")
    r.add('El zoom baja por debajo del 10 %',z is not None and z<10,z)
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
