# Cambiar de proveedor: pestañas del mismo tamaño y la vista se conserva (sin reencuadrar)
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'supsw',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Sup'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('19-0303','17-1230'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1500)
    pg.locator('[data-sup-add]').click(); pg.wait_for_timeout(400); pg.fill('#pbSupName','Turquía'); pg.locator('.pb-sup-dlg [data-psd-ok]').click(); pg.wait_for_timeout(3000)
    TAB="()=>[...document.querySelectorAll('header .pbh-tab')].map(t=>{const r=t.getBoundingClientRect();const d=[...t.querySelectorAll('.color-square,.pbh-prev i')].map(i=>Math.round(i.getBoundingClientRect().width));const off=[...t.querySelectorAll('.color-square,.pbh-prev i')].map(i=>{const b=i.getBoundingClientRect();return Math.round((b.top+b.bottom)/2-(r.top+r.bottom)/2)});return {on:t.classList.contains('is-on'),h:Math.round(r.height),w:Math.round(r.width),dots:d,off:off,plus:[...t.querySelectorAll('#addColorBtn')].some(b=>b.offsetParent)}})"
    t1=pg.evaluate(TAB)
    r.add('Pestañas activa e inactiva: misma altura, todos sus colores, mismo tamaño y centrados con el nombre; «+» solo en la seleccionada',len(t1)==2 and len({x['h'] for x in t1})==1 and all(len(x['dots'])==2 for x in t1) and len({d for x in t1 for d in x['dots']})==1 and all(o==0 for x in t1 for o in x['off']) and [x['plus'] for x in t1 if x['on']]==[True] and [x['plus'] for x in t1 if not x['on']]==[False],t1)
    pg.mouse.move(720,450)
    for _ in range(2): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    fab=pg.evaluate("window.__PG.pages[2].v.id"); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",fab); pg.wait_for_timeout(1300)
    v0=pg.evaluate("[+window.__BOARD.zoom.toFixed(3),window.__PG.pages.findIndex(p=>p.v.id===window.__PG.focus)]")
    wa=[x['w'] for x in t1]
    pg.locator('header .pbh-tab:not(.is-on) [data-sup-open]').first.click(); pg.wait_for_timeout(3000)
    v1=pg.evaluate("[+window.__BOARD.zoom.toFixed(3),window.__PG.pages.findIndex(p=>p.v.id===window.__PG.focus)]")
    r.add('Al cambiar de proveedor se conservan el zoom y la página en la que estabas (sin reencuadrar)',v0==v1,(v0,v1))
    t2=pg.evaluate(TAB)
    r.add('…y tras cambiar, los colores siguen en su sitio (centrados, sin subir) y el «+» pasa a la nueva seleccionada',len({x['h'] for x in t2})==1 and all(o==0 for x in t2 for o in x['off']) and [x['plus'] for x in t2 if x['on']]==[True],t2)
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
