# Las herramientas de forma se quedan activas: varias formas seguidas; Esc vuelve a seleccionar
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'stk',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','K'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    sk=pg.evaluate("window.__PG.pages[1].v.id"); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    W="([id,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    N="t=>window.__BOARD.objects.filter(o=>!o.pending&&o.type===t).length"
    for tool in ('ellipse','rect'):
        pg.locator('[data-btool="%s"]'%tool).click(); pg.wait_for_timeout(300)
        for (x,y) in [(150,150),(420,260),(650,520)]:
            a=pg.evaluate(W,[sk,x,y]); b=pg.evaluate(W,[sk,x+120,y+90]); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=5); pg.mouse.up(); pg.wait_for_timeout(400)
        r.add('Herramienta «%s»: tres formas seguidas sin volver a elegirla'%tool,pg.evaluate(N,tool)==3 and pg.evaluate("window.__BOARD.tool")==tool,(pg.evaluate(N,tool),pg.evaluate("window.__BOARD.tool")))
    pg.locator('[data-btool="rect"]').click(); pg.wait_for_timeout(200)
    r.add('Volver a pulsar la herramienta la mantiene activa',pg.evaluate("window.__BOARD.tool")=='rect','')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    r.add('Esc vuelve a «Seleccionar»',pg.evaluate("window.__BOARD.tool")=='select',pg.evaluate("window.__BOARD.tool"))
    a=pg.evaluate(W,[sk,150,450]); b=pg.evaluate(W,[sk,260,520]); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=5); pg.mouse.up(); pg.wait_for_timeout(400)
    r.add('…y ya no dibuja al arrastrar',pg.evaluate(N,'rect')==3,pg.evaluate(N,'rect'))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
