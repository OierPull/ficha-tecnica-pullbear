# Colores por código Inditex, mini ventana de colores del proveedor, barra tras dibujar, grosor recordado, guardar plantilla → crear ficha
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'ind',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    # plantilla: guardar lleva a crear ficha
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(500)
    pg.evaluate("(()=>{const b=document.querySelector('#tplManageBtn')||document.querySelector('#tplOpenBtn')||document.querySelector('[data-np-new]');b&&b.click()})()"); pg.wait_for_timeout(800)
    ns=pg.evaluate("(()=>{const e=document.querySelector('#tplModal .tpl-newsec');return e?getComputedStyle(e).borderTopStyle:null})()")
    r.add('«Nuevo apartado propio» con el mismo aspecto que los apartados (fila con borde discontinuo)',ns=='dashed',ns)
    pg.fill('#tplName','Plantilla rápida'); pg.locator('#tplModal [data-tpl="save"]').click(); pg.wait_for_timeout(1200)
    st=pg.evaluate("(()=>{const m=document.getElementById('newProjectModel');return [!!document.getElementById('tplModal'),!!m&&m.offsetParent!==null,document.activeElement&&document.activeElement.id]})()")
    r.add('Guardar plantilla cierra el diálogo y deja listo «Nuevo desarrollo»',st[0] is False and st[1],st)
    pg.fill('#newProjectModel','IND'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    # color Inditex
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700)
    lab=pg.evaluate("(()=>{const l=document.querySelector('#colorDialog .cd-field span');return l&&l.textContent})()")
    pg.locator('#cdPantone').fill('302'); pg.wait_for_timeout(300)
    hint=pg.evaluate("document.getElementById('cdHint').textContent"); dot=pg.evaluate("getComputedStyle(document.getElementById('cdDot')).backgroundColor")
    r.add('El diálogo pide el «Código Inditex» y al escribir 302 reconoce ORO con su color',lab=='Código Inditex' and 'ORO' in hint and dot.replace(' ','')=='rgb(222,185,31)',(lab,hint,dot))
    pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1500)
    c=pg.evaluate("(()=>{const c=window.__pgcp?null:null;return [...document.querySelectorAll('.board-host .pg-rowlab span')].map(s=>s.textContent.trim())})()")
    r.add('El color se crea con su código Inditex',any('302' in x for x in c),c)
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('974'); pg.wait_for_timeout(300)
    h2=pg.evaluate("document.getElementById('cdHint').textContent")
    r.add('Un código sin color de referencia (974 GROSELLA) pide elegirlo con el selector','GROSELLA' in h2 and 'selector' in h2,h2)
    pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1500)
    # mini ventana de colores del proveedor
    tab=pg.locator('header.sheet-toolbar .pbh-tab.is-on').first; bb=tab.bounding_box()
    pg.mouse.click(bb['x']+30,bb['y']+bb['height']/2); pg.wait_for_timeout(500)
    rows=pg.evaluate("[...document.querySelectorAll('.pg-colpop .pg-colpop-row b')].map(b=>b.textContent)")
    r.add('Volver a pulsar el proveedor abre sus colores (con editar y eliminar)',len(rows)>=2 and any('302' in x for x in rows) and pg.locator('.pg-colpop [data-pgcoledit]').count()>=2,rows)
    if rows:
        pg.locator('.pg-colpop [data-pgcoledit]').first.click(); pg.wait_for_timeout(600)
        r.add('«Editar» abre el diálogo del color',pg.evaluate("(()=>{const t=document.getElementById('cdTitle');return t&&t.textContent})()")=='Editar color','')
        pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
    # barra tras dibujar y grosor recordado
    sk=pg.evaluate("window.__PG.pages[1].v.id"); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    W="([id,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    def draw(x,y):
        a=pg.evaluate(W,[sk,x,y]); b=pg.evaluate(W,[sk,x+150,y+100]); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=5); pg.mouse.up(); pg.wait_for_timeout(500)
    pg.locator('[data-btool="ellipse"]').click(); draw(150,150)
    vis=pg.evaluate("(()=>{const b=document.querySelector('.board-ctxbar');return !!b&&!b.hidden&&getComputedStyle(b).display!=='none'})()"); tool=pg.evaluate("window.__BOARD.tool")
    r.add('Nada más dibujar un círculo aparece su barra (y la herramienta sigue activa)',vis and tool=='ellipse',(vis,tool))
    inp=pg.locator('.board-ctxbar [data-pgnumv]'); inp.fill('2'); inp.press('Enter'); pg.wait_for_timeout(300)
    draw(450,300)
    sws=pg.evaluate("window.__BOARD.objects.filter(o=>o.type==='ellipse').map(o=>o.sw)")
    r.add('El grosor elegido (2) se queda para los siguientes círculos',sws==[2,2],sws)
    pg.keyboard.press('Escape'); empty_click(pg)
    pg.locator('[data-btool="rect"]').click(); draw(150,500); s0=pg.evaluate("window.__BOARD.objects.filter(o=>o.type==='rect').map(o=>o.sw)")
    r.add('Cada herramienta recuerda su propio grosor (el cuadrado sigue en 4)',s0==[4],s0)
    pg.keyboard.press('Escape')
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
