# El cambio de proveedor no aparece en la hoja de cambios ni en el historial
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'supc',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','SC'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("window.__pgVerT.setField('Proveedor','Proveedor A');window.__pgVerT.setField('Patrón','P1')"); pg.wait_for_timeout(300)
    v=pg.evaluate("window.__pgVerT.save()"); pg.wait_for_timeout(600)
    pg.evaluate("window.__pgVerT.setField('Proveedor','Proveedor B');window.__pgVerT.setField('Patrón','P2')"); pg.wait_for_timeout(300)
    ch=pg.evaluate("window.__pgVerT.changes()")
    r.add('La hoja de cambios recoge otros cambios (Patrón) pero no el de proveedor',any('Patrón' in x for x in ch) and not any('Proveedor' in x for x in ch),ch)
    pg.evaluate("window.__pgVerT.save()"); pg.wait_for_timeout(600)
    pg.evaluate("window.__pgVerT.setField('Proveedor','Proveedor C');window.__pgVerT.setField('Patrón','P3')"); pg.wait_for_timeout(300)
    pg.evaluate("window.__pgVerT.load()"); pg.wait_for_timeout(1500)
    hp=pg.evaluate("window.__pgVerT.hist('Patrón')"); hv=pg.evaluate("window.__pgVerT.hist('Proveedor')")
    r.add('El historial de campos muestra el de Patrón pero nunca el de Proveedor',hp not in (None,'sin historial') and hv in (None,'sin historial'),(str(hp)[:80],hv))
    icons=pg.evaluate("[...document.querySelectorAll('.pg-layer .pg-spec:not(.is-preview) .pgs-f')].filter(f=>f.querySelector('.pgs-hist')).map(f=>{const l=f.querySelector('.pgs-lab');return (l&&l.tagName==='INPUT'?l.value:(l?l.textContent:'')).replace('*','').trim()})")
    r.add('En la hoja, el campo Proveedor no lleva icono de historial','Proveedor' not in icons,icons)
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
