# «+» para añadir página en cada hueco entre hojas, minimalista y de tamaño fijo
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'side',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Side'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    vis=pg.evaluate("[...document.querySelectorAll('.pg-layer .pg-lab')].map(l=>[...l.querySelectorAll('.pgl-nav,.pgl-add')].filter(e=>getComputedStyle(e).display!=='none').length)")
    r.add('Ninguna cabecera muestra el índice: solo su título',vis and all(n==1 for n in vis),vis[:5])
    n=pg.evaluate("window.__PG.pages.length"); g=pg.evaluate("document.querySelectorAll('.pg-gapadd').length")
    r.add('Hay un «+» en cada hueco entre hojas (todas, no solo la seleccionada)',g==n-1,(g,n))
    st=pg.evaluate("(()=>{const b=document.querySelector('.pg-gapadd'),s=getComputedStyle(b),r=b.getBoundingClientRect();return [s.borderTopStyle,s.backgroundColor,Math.round(r.width)]})()")
    pg.mouse.move(720,450)
    for _ in range(3): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(400); w2=pg.evaluate("Math.round(document.querySelector('.pg-gapadd').getBoundingClientRect().width)")
    r.add('Minimalista (discontinuo, sin fondo) y del mismo tamaño con cualquier zoom',st[0]=='dashed' and st[1] in ('rgba(0, 0, 0, 0)','transparent') and st[2]==w2==28,(st,w2))
    names=lambda:pg.evaluate("window.__PG.pages.map(p=>p.name)")
    def add_after(pid,name):
        pg.evaluate("id=>{const b=document.querySelector('.pg-gapadd[data-after=\"'+id+'\"]');b.click()}",pid); pg.wait_for_timeout(200)
        mid=pg.evaluate("window.__PG.shift&&window.__PG.shift.after>=0")
        pg.wait_for_timeout(1300); pg.fill('#tabPopName',name); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(2600)
        return mid
    sk=pg.evaluate("window.__PG.pages[1].v.id"); di=pg.evaluate("window.__PG.pages[0].v.id")
    mid=add_after(sk,'Derecha'); n1=names(); i=n1.index('Sketch')
    r.add('El «+» tras Sketch: las hojas se apartan con animación y la nueva queda justo a su derecha',mid and n1[i+1]=='Derecha',(mid,n1))
    add_after(di,'Izquierda'); n2=names(); i=n2.index('Sketch')
    r.add('El «+» entre Diseño y Sketch: la nueva queda justo a la izquierda de Sketch',n2[i-1]=='Izquierda',n2)
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
