# Hojas de continuación editables: seleccionar y mover en la hoja 2 edita el original y se ve en las dos
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'mir',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Mir'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    sk=pg.evaluate("window.__PG.pages.find(x=>x.i===1).v.id")
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1300)
    card='.pg-spec[data-pgv="%s"]:not(.is-preview)'%sk
    for _ in range(7): pg.locator(card+' .pgs-addb').last.click(); pg.wait_for_timeout(450)
    pg.wait_for_timeout(800)
    r.add('(preparación) Sketch tiene hoja 2',pg.evaluate("id=>window.__PG.pages.find(x=>x.v.id===id).chunks",sk)>=2,'')
    pg.mouse.move(720,450)
    for _ in range(3): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(800)
    W="([id,ci,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+ci*(P.SHW+P.VG)+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    a=pg.evaluate(W,[sk,0,200,200]); b=pg.evaluate(W,[sk,0,420,380])
    if not (0<a[0]<1400 and 0<b[0]<1400):
        pg.mouse.wheel(a[0]-300,0); pg.wait_for_timeout(700); a=pg.evaluate(W,[sk,0,200,200]); b=pg.evaluate(W,[sk,0,420,380])
    pg.locator('[data-btool="rect"]').click(); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(900)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    RECT="()=>{const o=window.__BOARD.objects.filter(o=>o.type==='rect'&&!o.pending).slice(-1)[0];return o?[o.id,Math.round(o.x),Math.round(o.y)]:null}"
    o0=pg.evaluate(RECT); empty_click(pg); pg.wait_for_timeout(400)
    r.add('(preparación) hay un cuadrado en la hoja 1',o0 is not None,o0)
    # pulsar el borde del cuadrado en la hoja 2
    m=pg.evaluate(W,[sk,1,200,290])
    if not (0<m[0]<1400):
        pg.mouse.move(720,450); pg.mouse.wheel(m[0]-900,0); pg.wait_for_timeout(700); m=pg.evaluate(W,[sk,1,200,290])
    pg.mouse.click(*m); pg.wait_for_timeout(600)
    sel=pg.evaluate("()=>{const s=window.__BOARD.sel;return s?(Array.isArray(s)?s.map(x=>x.id||x):[s.id||s]):[]}")
    r.add('Pulsar el cuadrado en la hoja 2 lo selecciona',o0 and o0[0] in [str(x) for x in sel],sel)
    tx=pg.evaluate("(()=>{const o=document.querySelector('.board-host .board-ov');return o?o.style.transform:''})()")
    r.add('…y la selección se muestra en la hoja 2',tx.startswith('translateX(') and not tx.startswith('translateX(0'),tx)
    d=pg.evaluate(W,[sk,1,262,200]); pg.mouse.move(*d); pg.mouse.down(); pg.mouse.move(d[0]+60,d[1]+40,steps=6); pg.mouse.up(); pg.wait_for_timeout(900)
    o1=pg.evaluate(RECT)
    r.add('Arrastrarlo en la hoja 2 mueve el original (se actualiza en las dos hojas)',o1 and o1[0]==o0[0] and o1[1]>o0[1]+20 and o1[2]>o0[2]+10,(o0,o1))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
