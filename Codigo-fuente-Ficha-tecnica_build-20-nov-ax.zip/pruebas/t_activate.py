# Activar otro color pulsando su campo
import sys
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def run():
    with sync_playwright() as p:
        ctx=launch(p,'act',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
        pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','E'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
        pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600); pg.locator('#cdPantone').fill('19-4052'); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1900)
        fa=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id"); did=pg.evaluate("window.__PG.pages.find(x=>x.i===0).v.id")
        pg.locator('.pg-lab[data-pglab="%s"] [data-pgnav="%s"]'%(did,fa)).evaluate('e=>e.click()'); pg.wait_for_timeout(1300)
        t=pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) textarea'%fa).first; t.click(); t.fill('DEN-A'); empty_click(pg); pg.wait_for_timeout(500)
        pg.evaluate("document.getElementById('addColorBtn').click()"); pg.wait_for_timeout(600); pg.locator('#cdPantone').fill('18-1664'); pg.locator('form.color-dialog .pb-copt[data-pbcopt="empty"]').click(); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1900)
        pg.mouse.move(720,450)
        for _ in range(4): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(70)
        pg.wait_for_timeout(500)
        first=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')][0].getAttribute('data-pgrow')")
        loc=pg.locator('.pg-spec.is-preview[data-pgrow="%s"][data-pgv="%s"] textarea'%(first,fa)).first; bx=loc.bounding_box(); pv=loc.input_value()
        pg.mouse.click(bx['x']+bx['width']/2,bx['y']+bx['height']/2); pg.wait_for_timeout(1700)
        on=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].findIndex(l=>l.classList.contains('is-on'))==0")
        info=pg.evaluate("(()=>{const a=document.activeElement;return [a&&a.value,a&&a.getAttribute('data-pgf'),!!(a&&a.closest('.pg-layer'))]})()")
        r.add('Antes de pulsar, la fila previa muestra el contenido de su color',pv=='DEN-A',pv)
        r.add('Un clic sobre un campo de otro color lo activa y te deja escribir en ese campo',on and info[0]=='DEN-A' and info[2],(on,info))
        ctx.close()
run()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
