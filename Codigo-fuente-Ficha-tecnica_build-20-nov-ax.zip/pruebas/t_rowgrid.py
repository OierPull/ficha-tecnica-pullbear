# Filas de otros colores con cuadrícula pulsable, barras compactas, tarjetas minimalistas, desplegable de un clic y colores sin estado
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'rgrid',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','RG'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('18-3838','18-1664'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
    sk=pg.evaluate("window.__PG.pages.find(x=>x.i===1).v.id")
    pg.mouse.move(720,450)
    for _ in range(2): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(900)
    bars=pg.evaluate("[...document.querySelectorAll('.pg-layer .pg-gbar-v,.pg-layer .pg-gbar-h')].map(b=>b.classList.contains('pg-gbar-v')?parseFloat(b.style.height):parseFloat(b.style.width))")
    r.add('Las barras «+» de la cuadrícula son compactas (no ocupan todo el ancho ni el alto)',bars and all(x<=120 for x in bars),bars[:4])
    pv=pg.locator('.pg-rowslayer .pg-grid.is-preview[data-pgv="%s"]'%sk)
    r.add('La fila del otro color también muestra su cuadrícula y su casilla «Añadir imagen»',pv.count()==1 and pv.locator('.pg-cell').count()>=1 and pv.locator('.pg-gbar-v').count()==1,pv.count())
    cid=pv.get_attribute('data-pgrow')
    b=pv.locator('.pg-gbar-v').bounding_box()
    if b and (b['y']<60 or b['y']>840):
        pg.mouse.wheel(0,b['y']-400); pg.wait_for_timeout(700); b=pv.locator('.pg-gbar-v').bounding_box()
    pg.mouse.click(b['x']+b['width']/2,b['y']+b['height']/2); pg.wait_for_timeout(2200)
    st=pg.evaluate("([id,c])=>[selectedColors[active]===c,(window.__PG.grid[id]||{}).c]",[sk,cid]) if False else pg.evaluate("id=>{const l=document.querySelector('.pg-layer .pg-grid[data-pggrid=\"'+id+'\"]');return [l?l.querySelectorAll('.pg-cell').length:-1]}",sk)
    act=pg.evaluate("c=>{const l=[...document.querySelectorAll('.pg-rowlab')].find(x=>x.dataset.pgrow===c);return !!(l&&l.classList.contains('is-on'))}",cid)
    r.add('Pulsar el «+» de otra fila activa ese color y añade la columna en su página',act and st[0]>=1,(act,st))
    v=pg.locator('.pg-addvar'); a=pg.locator('.pg-layer .pg-addlast').first
    sty=pg.evaluate("()=>{const a=document.querySelector('.pg-layer .pg-addlast'),v=document.querySelector('.pg-addvar');const f=e=>{const s=getComputedStyle(e);return [s.borderTopStyle,s.backgroundColor,s.borderRadius]};return [f(a),f(v)]}")
    r.add('«Añadir página» y «Crear nueva variante de color» tienen el mismo diseño minimalista',sty[0]==sty[1] and sty[0][0]=='dashed',sty)
    chip=pg.evaluate("[...document.querySelectorAll('header .color-chip')].map(c=>getComputedStyle(c).backgroundColor)")
    r.add('Ningún color de la cabecera tiene aspecto de seleccionado',all(x in ('rgba(0, 0, 0, 0)','transparent') for x in chip),chip)
    # desplegable de un solo clic en una página que no es la activa
    fid=pg.evaluate("window.__PG.pages[0].v.id")
    ta=pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) [data-pgpick="season"], .pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) [data-pgpick]'%(fid,fid)).first
    if ta.count():
        bb=ta.bounding_box(); pg.mouse.click(bb['x']+20,bb['y']+bb['height']/2); pg.wait_for_timeout(700)
        ok=pg.evaluate("(()=>{const m=document.getElementById('pgPick');if(!m)return false;const f=(window.__lastPick=document.activeElement).closest('.pgs-f').getBoundingClientRect(),r=m.getBoundingClientRect();return Math.abs(r.top-(f.bottom+6))<4})()")
        r.add('Departamento/Temporada se abren con un solo clic y la lista queda pegada al campo',ok,'')
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
