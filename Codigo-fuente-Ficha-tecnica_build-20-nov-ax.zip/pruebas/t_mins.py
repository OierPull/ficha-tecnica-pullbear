# «−» de la cuadrícula junto a su «+», y «Crear nueva variante de color» debajo de la fila aunque no haya colores
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'mins',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','M'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    v=pg.evaluate("(()=>{const v=document.querySelector('.pg-addvar').getBoundingClientRect();const sh=[...document.querySelectorAll('.pg-layer .pg-grid')].map(g=>g.getBoundingClientRect().bottom);return [Math.round(v.top),Math.round(Math.max(...sh))]})()")
    r.add('Sin colores, «Crear nueva variante de color» queda debajo de la fila (no encima de la hoja)',v[0]>v[1],v)
    pid=pg.evaluate("window.__PG.pages[0].v.id"); G='.pg-grid[data-pggrid="%s"]'%pid
    pg.locator(G+' .pg-gbar-v').click(); pg.wait_for_timeout(1200); pg.locator(G+' .pg-gbar-h').click(); pg.wait_for_timeout(1500)
    q=pg.evaluate("id=>{const g=document.querySelector('.pg-layer .pg-grid[data-pggrid=\"'+id+'\"]');const R=e=>e.getBoundingClientRect();const v=R(g.querySelector('.pg-gbar-v')),cm=R(g.querySelector('[data-pgg=\"c-\"]')),h=R(g.querySelector('.pg-gbar-h')),rm=R(g.querySelector('[data-pgg=\"r-\"]'));return [cm.top-v.bottom,Math.abs((cm.left+cm.right)/2-(v.left+v.right)/2),rm.left-h.right,Math.abs((rm.top+rm.bottom)/2-(h.top+h.bottom)/2)]}",pid)
    r.add('El «−» de columna está justo debajo del «+» de columna, y el «−» de fila justo a la derecha del «+» de fila',0<=q[0]<=8 and q[1]<=2 and 0<=q[2]<=8 and q[3]<=2,[round(x,1) for x in q])
    pg.locator(G+' [data-pgg="c-"]').click(); pg.wait_for_timeout(1300)
    r.add('…y siguen funcionando (quitar columna)',pg.evaluate("id=>window.__PG.grid[id].c",pid)==1,pg.evaluate("id=>JSON.stringify(window.__PG.grid[id])",pid))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
