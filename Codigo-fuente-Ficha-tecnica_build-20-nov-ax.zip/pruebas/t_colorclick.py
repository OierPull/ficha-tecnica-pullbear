# Pulsar el círculo de color abre la paleta, no el selector del sistema; el arcoíris sí lo abre
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'ccl',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','C'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("""()=>{window.__native=0;const i=document.querySelector('.board-island .board-color input[type=color]');i.addEventListener('click',e=>{if(!e.defaultPrevented)window.__native++},false)}""")
    c=pg.locator('.board-island .board-color').first.bounding_box(); pg.mouse.click(c['x']+c['width']/2,c['y']+c['height']/2); pg.wait_for_timeout(400)
    r.add('Pulsar el círculo de color no abre el selector del sistema',pg.evaluate("window.__native")==0,pg.evaluate("window.__native"))
    r.add('…sino la paleta',pg.evaluate("document.querySelector('.pg-palette').classList.contains('is-open')"),'')
    pp=pg.locator('.pg-palette .pg-sw-other').bounding_box(); pg.mouse.move(pp['x']+5,pp['y']+5,steps=3); pg.mouse.click(pp['x']+pp['width']/2,pp['y']+pp['height']/2); pg.wait_for_timeout(300)
    r.add('El círculo de arcoíris sí abre el selector del sistema',pg.evaluate("window.__native")==1,pg.evaluate("window.__native"))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
