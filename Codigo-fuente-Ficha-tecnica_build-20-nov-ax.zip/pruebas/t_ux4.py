# Primer bloque automático, selector de trims, fecha/opciones en Datos del producto, bola de color fija y colores iguales
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def step(name,fn):
    try:
        ok,det=fn(); r.add(name,bool(ok),det)
    except Exception as e: r.add(name,False,'EXC '+str(e)[:160])
def pid(pg,i): return pg.evaluate("i=>window.__PG.pages.find(x=>x.i===i).v.id",i)
def go(pg,id_): pg.evaluate("id=>document.querySelector('.pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",id_); pg.wait_for_timeout(1300)
with sync_playwright() as p:
    ctx=launch(p,'ux4',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','UX'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3500)
    pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill('19-4052'); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(2500)
    d0=pid(pg,0); sk=pid(pg,1); tr=pid(pg,4)
    go(pg,sk); pg.wait_for_timeout(800)
    step('Sketch de una ficha nueva ya trae su primer bloque desplegado',lambda:(pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) .pgs-blk'%sk).count()>=1,pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) .pgs-blk'%sk).count()))
    # página nueva
    lab='.pg-lab[data-pglab="%s"]:not(.is-cont)'%sk
    pg.locator(lab+' .pgl-add').evaluate('e=>e.click()'); pg.wait_for_timeout(1200); pg.fill('#tabPopName','Lavados'); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(3000)
    nid=pg.evaluate("window.__PG.pages.find(p=>p.name==='Lavados').v.id")
    step('Una página nueva aparece con su primer bloque desplegado',lambda:(pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) .pgs-blk'%nid).count()>=1,pg.locator('.pg-spec[data-pgv="%s"]:not(.is-preview) .pgs-blk'%nid).count()))
    # Trims vacío: selector de tipo
    go(pg,tr); card='.pg-spec[data-pgv="%s"]:not(.is-preview)'%tr
    for _ in range(6):
        d=pg.locator(card+' .pgs-del')
        if not d.count(): break
        d.first.click(); pg.wait_for_timeout(900)
    pg.wait_for_timeout(600)
    step('Trims sin bloques muestra el selector Botón / Cremallera / Hilo / Otro',lambda:(pg.locator(card+' .pgs-trimpick button:not(.pg-trimx)').count()==4,pg.locator(card+' .pgs-trimpick button:not(.pg-trimx)').count()))
    def pick():
        pg.locator(card+' .pgs-trimpick [data-pgtrim="Cremallera"]').click(); pg.wait_for_timeout(1300)
        n=pg.evaluate("s=>[...document.querySelectorAll(s+' .pgs-tin')].map(e=>e.value)",card); return (any('Cremallera' in x for x in n),n)
    step('…y al elegir uno se crea ese trim',pick)
    # Datos del producto
    go(pg,d0); dc='.pg-spec[data-pgv="%s"]:not(.is-preview)'%d0
    step('«Fecha» tiene calendario',lambda:(pg.locator(dc+' input[type="date"].pgs-date').count()==1,''))
    def fecha():
        pg.locator(dc+' input[type="date"].pgs-date').fill('2026-12-01'); pg.wait_for_timeout(700); empty_click(pg); pg.wait_for_timeout(500)
        go(pg,sk); go(pg,d0); return (pg.locator(dc+' input[type="date"].pgs-date').input_value()=='2026-12-01',pg.locator(dc+' input[type="date"].pgs-date').input_value())
    step('…y la fecha elegida se guarda',fecha)
    def dep():
        t=pg.locator(dc+' textarea[data-pgpick="dep"]'); t.click(); pg.wait_for_timeout(400)
        opts=pg.evaluate("[...document.querySelectorAll('#pgPick button')].map(b=>b.textContent)")
        pg.locator('#pgPick [data-pgpickv="Denim SRA"]').click(); pg.wait_for_timeout(700)
        return ('Denim SRA' in opts and t.input_value()=='Denim SRA',(len(opts),t.input_value()))
    step('«Departamento» se elige de una lista',dep)
    def sea():
        t=pg.locator(dc+' textarea[data-pgpick="sea"]'); t.click(); pg.wait_for_timeout(400)
        opts=pg.evaluate("[...document.querySelectorAll('#pgPick button')].map(b=>b.textContent)")
        first=opts[0] if opts else None
        if first: pg.locator('#pgPick button').first.click(); pg.wait_for_timeout(600)
        return (len(opts)>=4 and t.input_value()==first,(opts[:4],t.input_value()))
    step('«Temporada» se elige de una lista',sea)
    # bola de color con un solo color: visible, fija a la izquierda al desplazarse
    def dot1():
        b0=pg.locator('.pg-rowlab').first.bounding_box(); pg.mouse.move(720,450); pg.mouse.wheel(400,0); pg.wait_for_timeout(500); b1=pg.locator('.pg-rowlab').first.bounding_box()
        return (b0 and b1 and pg.locator('.pg-rowlab').first.is_visible() and abs(b0['x']-16)<=1 and abs(b1['x']-16)<=1 and abs(b0['y']-b1['y'])<=1,(b0,b1))
    step('Con un solo color la bola se ve y se queda fija a la izquierda al moverte',dot1)
    step('Los colores del proveedor arriba se ven todos iguales (ninguno parece seleccionado)',lambda:(len(set(pg.evaluate("[...document.querySelectorAll('#colorSwatches .color-chip')].map(c=>getComputedStyle(c).backgroundColor+'|'+getComputedStyle(c.querySelector('.color-square')).boxShadow)")))==1,pg.evaluate("[...document.querySelectorAll('#colorSwatches .color-chip')].map(c=>getComputedStyle(c.querySelector('.color-square')).boxShadow)")))
    step('Consola sin errores',lambda:(not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2])))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
