# Nueva página solo en algunos colores; aviso de campos obligatorios rellenable
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'colp',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','CP'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('19-0303','17-1230'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1400)
    print('CP',pg.evaluate("(()=>{try{return [window.__pgcp.cur(),window.__pgcp.cols()]}catch(e){return String(e)}})()"))
    cur=pg.evaluate("window.__pgcp.cur()")
    sk=pg.evaluate("window.__PG.pages[1].v.id")
    pg.evaluate("id=>document.querySelector('.pg-gapadd[data-after=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1500)
    chips=pg.evaluate("[...document.querySelectorAll('#tabPop .pg-npc')].map(b=>[b.getAttribute('data-npc'),b.classList.contains('is-on')])")
    r.add('«Nueva página» muestra los colores de la prenda, todos marcados',len(chips)>=2 and all(x[1] for x in chips),chips)
    other=[c for c,_ in chips if c!=cur][0]
    pg.locator('#tabPop .pg-npc[data-npc="%s"]'%other).click(); pg.wait_for_timeout(150)
    pg.fill('#tabPopName','Solo actual'); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(3000)
    dc=pg.evaluate("(()=>{const d=window.__pgcp.custom('Solo actual');return d?d.colors:null})()")
    r.add('La página se crea solo en los colores marcados',dc==[cur],(dc,cur))
    nid=pg.evaluate("window.__PG.pages.find(p=>p.name==='Solo actual').v.id")
    offs=pg.evaluate("[...document.querySelectorAll('.pg-layer .pg-offslot')].map(o=>o.classList.contains('is-active'))")
    r.add('En la fila del otro color esa página queda vacía; en el color actual se ve normal',offs==[False],offs)
    # cambiar al otro color
    pg.evaluate("c=>{const el=document.querySelector('.pg-rowslayer .pg-spec.is-preview[data-pgrow=\"'+c+'\"]');el&&el.dispatchEvent(new MouseEvent('pointerdown',{bubbles:true}));el&&el.click()}",other); pg.wait_for_timeout(2500)
    if pg.evaluate("window.__pgcp.cur()")!=other:
        pg.evaluate("c=>{try{window.__pgcp.activate(c)}catch(e){}}",other); pg.wait_for_timeout(2500)
    act=pg.evaluate("[...document.querySelectorAll('.pg-layer .pg-offslot.is-active [data-pgoffadd]')].length")
    r.add('Al abrir el otro color, la página aparece como «no incluida» con «Añadir a este color»',pg.evaluate("window.__pgcp.cur()")==other and act==1,(pg.evaluate("window.__pgcp.cur()"),act))
    plan=pg.evaluate("(()=>{try{return window.__pgcp.plan()}catch(e){return 'err '+e}})()")
    gi=pg.evaluate("(()=>{const P=window.__PG,p=P.pages.find(x=>x.name==='Solo actual');return (p.v.relatedSections||[])[0]})()")
    r.add('El PDF de ese color no incluye la página',isinstance(plan,list) and gi not in plan,(gi,plan if isinstance(plan,str) else len(plan)))
    if act: pg.locator('.pg-layer .pg-offslot.is-active [data-pgoffadd]').click(); pg.wait_for_timeout(1500)
    r.add('«Añadir a este color» la incorpora',pg.evaluate("document.querySelectorAll('.pg-layer .pg-offslot').length")==0 and pg.evaluate("window.__pgcp.custom('Solo actual').colors.length")==2,'')
    # aviso de campos obligatorios
    pg.locator('#pdfExportOpen').click(); pg.wait_for_timeout(800)
    rows=pg.evaluate("[...document.querySelectorAll('#pgPdfWarn .pg-mf-row')].map(r=>[r.querySelector('b').textContent,r.querySelector('.pg-mf-cols')?r.querySelector('.pg-mf-cols').textContent:'',r.querySelector('.pg-mf-in').tagName])")
    r.add('El aviso lista cada campo que falta con su página, apartado y colores, y un campo para rellenarlo',len(rows)>=3 and any(x[0]=='Departamento' and x[2]=='SELECT' for x in rows),rows)
    for i,(lab,_,tag) in enumerate(rows):
        el=pg.locator('#pgPdfWarn .pg-mf-in').nth(i)
        if tag=='SELECT': el.select_option(index=2)
        else: el.fill('Valor %d'%i)
        pg.wait_for_timeout(80)
    done=pg.evaluate("document.querySelectorAll('#pgPdfWarn .pg-mf-row.is-done').length")
    pg.locator('#pgPdfWarn [data-pgmfgo]').click(); pg.wait_for_timeout(1200)
    op=pg.evaluate("(()=>{const m=document.getElementById('pdfExportModal');return !!m&&!m.hidden&&getComputedStyle(m).display!=='none'})()")
    left=pg.evaluate("window.__pgcp.miss()")
    r.add('Rellenados en el propio aviso: quedan guardados (en todos los colores) y se abre la descarga',done==len(rows) and op and left==0,(done,len(rows),op,left))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
