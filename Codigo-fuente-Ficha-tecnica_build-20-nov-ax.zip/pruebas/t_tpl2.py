# Plantillas (nombre, fijos, trims, eliminar), Diseño sin estados ni proveedor, eliminar color, atajos D / Alt+arrastrar / P
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'tpl2',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    def confirm():
        cf=pg.locator('.ui-modal .ui-btn-primary, .ui-confirm .ui-btn-primary')
        for i in range(cf.count()):
            if cf.nth(i).is_visible(): cf.nth(i).click(); return True
        return False
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(500)
    pg.evaluate("(()=>{const b=document.querySelector('#tplManageBtn')||document.querySelector('#tplOpenBtn')||document.querySelector('[data-np-new]');b&&b.click()})()"); pg.wait_for_timeout(800)
    t=pg.evaluate("(()=>{const m=document.getElementById('tplModal');if(!m)return null;return [document.getElementById('tplTitle').textContent,[...m.querySelectorAll('.tpl-sec')].slice(0,4).map(li=>(li.classList.contains('is-locked')?'🔒':'')+((li.querySelector('.tpl-lname')||{}).textContent||(li.querySelector('.tpl-bname,.tpl-cname')||{}).value))]})()")
    r.add('El diálogo se llama «Plantillas de ficha técnica» y empieza por Diseño y Sketch bloqueados',t and t[0]=='Plantillas de ficha técnica' and t[1][:2]==['🔒Diseño','🔒Sketch'],t)
    names=pg.evaluate("[...document.querySelectorAll('#tplModal .tpl-bname')].map(i=>i.value)")
    r.add('Nombres actuales en la plantilla (Fabric, Linning, Print / Embroidery, Interior)',all(x in names for x in ('Fabric','Linning','Print / Embroidery','Interior')) and 'Tejido' not in names,names)
    pg.fill('#tplName','Plantilla prueba'); pg.locator('#tplModal [data-tpl-tkadd]').first.click(); pg.wait_for_timeout(300)
    nt=pg.locator('#tplModal .tpl-tname'); n=nt.count(); nt.nth(n-1).fill('Velcro'); nt.nth(0).fill('Botón metálico'); pg.wait_for_timeout(200)
    r.add('Trims: «+ Nuevo trim» crea uno más (sin límite de 4) y los títulos se pueden cambiar',n==5,n)
    pg.locator('#tplModal [data-tpl="save"]').click(); pg.wait_for_timeout(700)
    st=pg.evaluate("(()=>{const l=JSON.parse(localStorage.getItem('pb-ficha-templates-v1')||'[]');const t=(Array.isArray(l)?l:[]).find(x=>x.name==='Plantilla prueba');return t?[t.structure.trimLabels,(t.structure.trimCustom||[]).map(c=>c.label)]:null})()")
    if not pg.locator('#tplModal').count():
        pg.evaluate("(()=>{const b=document.querySelector('#tplManageBtn')||document.querySelector('#tplOpenBtn')||document.querySelector('[data-np-new]');b&&b.click()})()"); pg.wait_for_timeout(800)
    chips=pg.evaluate("[...document.querySelectorAll('#tplModal .tpl-chip2-n')].map(b=>b.textContent)")
    r.add('La plantilla se guarda con sus trims y aparece entre las guardadas',st and st[0].get('boton')=='Botón metálico' and 'Velcro' in st[1] and 'Plantilla prueba' in chips,(st,chips))
    pg.evaluate("document.querySelector('#tplModal .tpl-chip2-x').click()"); pg.wait_for_timeout(400); confirm(); pg.wait_for_timeout(600)
    chips2=pg.evaluate("[...document.querySelectorAll('#tplModal .tpl-chip2-n')].map(b=>b.textContent)")
    r.add('Una plantilla se elimina con su «×» (pide confirmación)','Plantilla prueba' not in chips2,chips2)
    pg.evaluate("(()=>{const b=document.querySelector('#tplModal [data-tpl=\"close\"]');b&&b.click()})()"); pg.wait_for_timeout(400)
    if not pg.locator('#newProjectModel').is_visible(): pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300)
    pg.fill('#newProjectModel','TP'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('19-0303','17-1230'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1400)
    di=pg.evaluate("window.__PG.pages[0].v.id"); sp='.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview)'%di
    d=pg.evaluate("s=>{const e=document.querySelector(s);const labs=[...e.querySelectorAll('.pgs-lab')].map(l=>(l.tagName==='INPUT'?l.value:l.textContent).replace('*','').trim());const vis=[...e.querySelectorAll('.pgs-fst,.pgs-bh .pg-st')].filter(x=>getComputedStyle(x).display!=='none').length;return [labs,vis,!!e.querySelector('.pg-colorsrow,.pgs-colors,[data-pgcolors]')||/Colores/.test(e.textContent)]}",sp)
    r.add('Diseño: sin «Proveedor» y sin botones de pendiente / aprobado, pero con sus colores','Proveedor' not in d[0] and d[1]==0 and d[2],d)
    # eliminar color
    ncol=pg.evaluate("document.querySelectorAll('.board-host .pg-rowlab').length")
    tab=pg.locator('header.sheet-toolbar .pbh-tab.is-on').first; bb=tab.bounding_box(); pg.mouse.click(bb['x']+30,bb['y']+bb['height']/2); pg.wait_for_timeout(500)
    x=pg.locator('.pg-colpop [data-pgcoldel2]').last; vis=x.count()>0
    if vis: x.click(); pg.wait_for_timeout(400); confirm(); pg.wait_for_timeout(1800)
    ncol2=pg.evaluate("document.querySelectorAll('.board-host .pg-rowlab').length")
    r.add('Un color se elimina desde la ventana de colores del proveedor tras confirmar',vis and ncol2==ncol-1,(vis,ncol,ncol2))
    # atajos
    sk=pg.evaluate("window.__PG.pages[1].v.id"); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1500)
    W="([wx,wy])=>{const v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+wx*v.k,hr.top+v.oy+wy*v.k]}"
    o=pg.evaluate("(()=>{const o=window.__BOARD.objects.filter(o=>o.type==='image'&&!o.pen).pop();return [o.id,o.x+o.w/2,o.y+o.h/2,o.x,o.y]})()")
    empty_click(pg); pg.mouse.click(*pg.evaluate(W,o[1:3])); pg.wait_for_timeout(400)
    n0=pg.evaluate("window.__BOARD.objects.length"); pg.keyboard.press('Control+d'); pg.wait_for_timeout(500); n1=pg.evaluate("window.__BOARD.objects.length")
    r.add('Cmd/Ctrl + D duplica la imagen',n1==n0+1,(n0,n1))
    pg.keyboard.press('Escape'); empty_click(pg); pg.wait_for_timeout(200)
    a=pg.evaluate(W,o[1:3]); pg.keyboard.down('Alt'); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(a[0]+150,a[1]+60,steps=8); pg.mouse.up(); pg.keyboard.up('Alt'); pg.wait_for_timeout(600)
    n2=pg.evaluate("window.__BOARD.objects.length"); orig=pg.evaluate("id=>{const o=window.__BOARD.objects.find(o=>o.id===id);return [Math.round(o.x),Math.round(o.y)]}",o[0])
    r.add('Alt + arrastrar crea una copia y deja el original en su sitio',n2==n1+1 and abs(orig[0]-o[3])<2 and abs(orig[1]-o[4])<2,(n1,n2,orig,[round(o[3]),round(o[4])]))
    pg.keyboard.press('l'); pg.wait_for_timeout(100); pg.keyboard.press('p'); pg.wait_for_timeout(150)
    t1=[pg.evaluate("window.__BOARD.tool"),pg.evaluate("window.__PG.penMode")]
    pg.keyboard.press('Shift+P'); pg.wait_for_timeout(150); t2=pg.evaluate("window.__PG.penMode"); pg.keyboard.press('Escape'); pg.keyboard.press('Escape')
    r.add('P vuelve a selección desde cualquier herramienta (la pluma pasa a Mayús + P)',t1==['select',None] and t2=='pen',(t1,t2))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
