# Con Fabric de un color seleccionada, pulsar Diseño de otro color selecciona Diseño de ese color, sin pasar por Fabric ni saltos
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'xrow',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','X'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('19-0303','17-1230','18-1664'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1700)
    ids=pg.evaluate("window.__PG.pages.map(p=>p.v.id)"); dis,fab=ids[0],ids[2]
    rows=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].map(l=>l.dataset.pgrow)")
    # activar el primer color y seleccionar su Fabric
    pg.mouse.move(720,450)
    for _ in range(4): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(800)
    def rowhit(cid,pid):
        loc=pg.locator('.pg-rowhit[data-pgrow="%s"][data-pgv="%s"][data-ci="0"]'%(cid,pid)).first; b=loc.bounding_box()
        if b and (b['y']<60 or b['y']+b['height']>870 or b['x']<0 or b['x']+b['width']>1440):
            pg.mouse.move(720,450); pg.mouse.wheel(b['x']-400,b['y']-300); pg.wait_for_timeout(800); b=loc.bounding_box()
        return b
    act=pg.evaluate("[...document.querySelectorAll('.pg-rowlab')].find(l=>l.classList.contains('is-on')).dataset.pgrow")
    other=[x for x in rows if x!=act][0]
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",fab); pg.wait_for_timeout(1300)
    r.add('(preparación) Fabric del color activo está seleccionada',pg.evaluate("window.__PG.focus")==fab,pg.evaluate("window.__PG.focus"))
    b=rowhit(other,dis); pg.wait_for_timeout(500)
    pg.evaluate("()=>{window.__fz=[];const t0=performance.now();(function f(){window.__fz.push([Math.round(performance.now()-t0),window.__PG.focus,Math.round((window.__PG.painted||[window.__BOARD.panX])[0]),Math.round((window.__PG.painted||[0,window.__BOARD.panY])[1]),+((window.__PG.painted||[0,0,window.__BOARD.zoom])[2]).toFixed(3)]);if(performance.now()-t0<1800)requestAnimationFrame(f)})()}")
    pg.mouse.click(b['x']+b['width']/2,b['y']+b['height']/2); pg.wait_for_timeout(2000)
    fz=pg.evaluate("window.__fz"); foc=[x[1] for x in fz]
    ison=pg.evaluate("c=>{const l=[...document.querySelectorAll('.pg-rowlab')].find(x=>x.dataset.pgrow===c);return !!(l&&l.classList.contains('is-on'))}",other)
    r.add('Pulsar Diseño de otro color activa ese color',ison,'')
    r.add('…y selecciona Diseño (no la Fabric que estaba seleccionada)',pg.evaluate("window.__PG.focus")==dis,pg.evaluate("window.__PG.focus"))
    k0=next((j for j,f in enumerate(foc) if f==dis),None); seq=[foc[0]]+[f for j,f in enumerate(foc[1:],1) if f!=foc[j-1]]
    r.add('…pasa directamente de Fabric a Diseño y ya no cambia (sin correcciones)',k0 is not None and all(f==dis for f in foc[k0:]) and seq==[fab,dis],seq)
    ch=[];prev=None
    for x in fz:
        k=(x[2],x[3],x[4])
        if k!=prev: ch.append(x); prev=k
    r.add('…y sin saltos: como mucho un ajuste vertical, sin cambio de zoom ni desplazamiento horizontal',len(ch)<=2 and len({x[4] for x in ch})==1 and len({x[2] for x in ch})==1,ch[:4])
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
