# Cada página se selecciona al pulsar en cualquier zona: lienzo, columna de campos (también bajo «Añadir campo»), casilla vacía
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'foc',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Foc'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.mouse.move(720,450)
    for _ in range(3): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(800)
    ids=pg.evaluate("window.__PG.pages.map(p=>p.v.id)"); names=pg.evaluate("window.__PG.pages.map(p=>p.name)")
    W="([id,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    zones=[('columna de campos, bajo «Añadir campo»',lambda P:(P['CX']+200,P['SHH']-60)),('lienzo',lambda P:(300,P['SHH']/2)),('borde inferior de la hoja',lambda P:(700,P['SHH']-20))]
    PP=pg.evaluate("({CX:window.__PG.CX,SHH:window.__PG.SHH,SHW:window.__PG.SHW})")
    fails=[]
    for zl,zf in zones:
        bad=[]
        for k,(i,nm) in enumerate(zip(ids,names)):
            other=ids[(k+1)%len(ids)]
            pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",other); pg.wait_for_timeout(700)
            wx,wy=zf(PP); pt=pg.evaluate(W,[i,wx,wy])
            if not (5<pt[0]<1435 and 70<pt[1]<880):
                pg.mouse.move(720,450); pg.mouse.wheel(pt[0]-720,pt[1]-450); pg.wait_for_timeout(700); pt=pg.evaluate(W,[i,wx,wy])
            pg.mouse.click(*pt); pg.wait_for_timeout(700)
            if pg.evaluate("window.__PG.focus")!=i: bad.append(nm)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
        r.add('Pulsar en la %s selecciona cada página (%d páginas)'%(zl,len(ids)),not bad,bad)
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
