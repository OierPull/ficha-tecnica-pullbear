# Guías inteligentes al mover y nuevo icono de biblioteca (uso real)
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
def scr(pg,wx,wy): return pg.evaluate("([x,y])=>{const r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV(),P=window.__PG;return [r.left+v.ox+(x+P.DX)*v.k,r.top+v.oy+y*v.k]}",[wx,wy])
def rects(pg): return pg.evaluate("window.__BOARD.objects.filter(o=>o.type==='rect').map(o=>[o.x,o.y,o.w,o.h])")
with sync_playwright() as p:
    ctx=launch(p,'guides',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','Guías'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",str('2')); pg.wait_for_timeout(900)
    ox=pg.evaluate("window.__PG.pages.find(x=>x.i===2).ox")
    for (a,b,c,d) in ((100,100,300,300),(520,480,680,600)):
        pg.locator('[data-btool="rect"]').click(); A=scr(pg,ox+a,b); B=scr(pg,ox+c,d); pg.mouse.move(*A); pg.mouse.down(); pg.mouse.move(*B,steps=6); pg.mouse.up(); pg.wait_for_timeout(700); pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
    pg.locator('[data-btool="select"]').dispatch_event('click'); pg.wait_for_timeout(200)
    ra,rb=rects(pg)[0],rects(pg)[1]
    k=pg.evaluate("window.__pgV().k")
    # arrastrar B para que su borde izquierdo quede a ~3 px de pantalla del borde izquierdo de A
    start=pg.evaluate("([x,y])=>{const r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV();return [r.left+v.ox+x*v.k,r.top+v.oy+y*v.k]}",[rb[0]+rb[2]*0.3,rb[1]]); tgt_dx=(ra[0]-rb[0])+3/k
    pg.mouse.move(*start); pg.mouse.down(); pg.mouse.move(start[0]+tgt_dx*k*0.5,start[1]-40,steps=4); pg.mouse.move(start[0]+tgt_dx*k,start[1]-60,steps=4); pg.wait_for_timeout(100)
    shown=pg.evaluate("!!window.__pbGuides()"); pg.mouse.up(); pg.wait_for_timeout(700)
    nb=rects(pg)[1]
    r.add('Al acercar un elemento al borde de otro, se alinea exactamente con él',abs(nb[0]-ra[0])<0.01,(round(nb[0],2),round(ra[0],2)))
    r.add('…y se ve la guía mientras se arrastra',shown,'')
    r.add('Al soltar, la guía desaparece',pg.evaluate("window.__pbGuides()") is None,'')
    # con Ctrl: sin ajuste
    rb=rects(pg)[1]; start=scr(pg,ox+rb[0]-ox+rb[2]/2-PGDX if False else 0,0) if False else None
    c0=pg.evaluate("(()=>{const o=window.__BOARD.objects.filter(o=>o.type==='rect')[1];return [o.x+o.w*0.3,o.y]})()")
    st=pg.evaluate("([x,y])=>{const r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV();return [r.left+v.ox+x*v.k,r.top+v.oy+y*v.k]}",c0)
    pg.mouse.move(*st); pg.mouse.down(); pg.keyboard.down('Control'); pg.mouse.move(st[0]+40,st[1]+2,steps=4); pg.mouse.move(st[0]+3/k+1,st[1]+60,steps=4); pg.wait_for_timeout(100); pg.mouse.up(); pg.keyboard.up('Control'); pg.wait_for_timeout(600)
    nb2=rects(pg)[1]
    r.add('Con Cmd/Ctrl pulsado se mueve libremente, sin ajustar',abs(nb2[0]-ra[0])>0.5,(round(nb2[0],2),round(ra[0],2)))
    # ajuste al centro de la zona de dibujo de la hoja
    o=pg.evaluate("(()=>{const o=window.__BOARD.objects.filter(o=>o.type==='rect')[1];return [o.x+o.w/2,o.y,o.w,o.x]})()")
    cx=pg.evaluate("ox=>ox+window.__PG.SHW/2",ox)
    st=pg.evaluate("([x,y])=>{const r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV();return [r.left+v.ox+x*v.k,r.top+v.oy+y*v.k]}",[o[3]+o[2]*0.3,o[1]-o[2]*0+0])
    pg.mouse.move(*st); pg.mouse.down(); pg.mouse.move(st[0]+((cx-o[0])+2/k)*k*0.5,st[1]+30,steps=4); pg.mouse.move(st[0]+((cx-o[0])+2/k)*k,st[1]+50,steps=4); pg.wait_for_timeout(100); pg.mouse.up(); pg.wait_for_timeout(600)
    oc=pg.evaluate("(()=>{const o=window.__BOARD.objects.filter(o=>o.type==='rect')[1];return o.x+o.w/2})()")
    r.add('También se alinea con el centro de la hoja',abs(oc-cx)<0.01,(round(oc,2),cx))
    s1=pg.evaluate("window.__pgStored()"); tid=pg.evaluate("window.__PG.pages.find(x=>x.i===2).v.id")
    r.add('Las posiciones ajustadas se guardan en su página',len(s1.get(tid,[]))==2,s1.get(tid))
    ic=pg.evaluate("(()=>{const b=document.querySelector('.board-island [data-blib] svg');return b?b.innerHTML:''})()")
    r.add('La biblioteca tiene un icono simple de guardado (marcador), no cuatro cuadrados','M7 3.5h10' in ic and 'rect' not in ic,ic[:60])
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
