import json,subprocess,glob
from h import *
from PIL import Image
r=R()
STORE='pb-tech-visual-uploads-v2::project::project-main'
MK="""const mk=async(n,col,w,h)=>{const cv=document.createElement('canvas');cv.width=w;cv.height=h;const c=cv.getContext('2d');c.fillStyle=col;c.fillRect(0,0,w,h);const b=await new Promise(r=>cv.toBlob(r,'image/png'));return new File([b],n+'.png',{type:'image/png'})};"""
JS_DROP="async([bx,by,name,col,w,h])=>{"+MK+"""
  const f=await mk(name,col,w,h),dt=new DataTransfer();dt.items.add(f);
  const sh=document.querySelector('.board-sheet').getBoundingClientRect(),x=sh.left+bx/1000*sh.width,y=sh.top+by/1000*sh.height;
  const host=document.getElementById('boardHost'),ev=t=>new DragEvent(t,{bubbles:true,cancelable:true,dataTransfer:dt,clientX:x,clientY:y});
  host.dispatchEvent(ev('dragenter'));host.dispatchEvent(ev('dragover'));host.dispatchEvent(ev('drop'));return true}"""
def sheet(pg): return pg.evaluate("(()=>{const s=document.querySelector('.board-sheet').getBoundingClientRect();return {x:s.left,y:s.top,w:s.width,h:s.height}})()")
def P(pg,bx,by): s=sheet(pg); return (s['x']+bx/1000*s['w'], s['y']+by/1000*s['h'])
def objs(pg,view='denim'):
    return pg.evaluate("([k,v])=>{const d=JSON.parse(localStorage.getItem(k)||'{}');const out={};for(const e of Object.keys(d)){const b=(d[e]||{}).boards;if(b&&b[v])out[e]=b[v].objects.map(o=>({t:o.type,x:o.x,y:o.y,w:o.w,h:o.h,x1:o.x1,y1:o.y1,x2:o.x2,y2:o.y2,text:o.text,ref:o.ref}))}return out}",[STORE,view])
def cur(pg,view='denim'):
    o=objs(pg,view); k=[x for x in o if 'red' in x] or list(o.keys()); return o[k[0]] if k else None
def pix(pg,bx,by):
    return pg.evaluate("([bx,by])=>{const c=document.querySelector('.board-host > canvas'),sh=document.querySelector('.board-sheet').getBoundingClientRect(),hr=document.getElementById('boardHost').getBoundingClientRect(),sx=(sh.left-hr.left+bx/1000*sh.width)*c.width/hr.width,sy=(sh.top-hr.top+by/1000*sh.height)*c.height/hr.height,x=c.getContext('2d').getImageData(Math.round(sx),Math.round(sy),1,1).data;return [x[0],x[1],x[2]]}",[bx,by])
def pixa(pg,bx,by):
    return pg.evaluate("([bx,by])=>{const c=document.querySelector('.board-host > canvas'),sh=document.querySelector('.board-sheet').getBoundingClientRect(),hr=document.getElementById('boardHost').getBoundingClientRect(),sx=(sh.left-hr.left+bx/1000*sh.width)*c.width/hr.width,sy=(sh.top-hr.top+by/1000*sh.height)*c.height/hr.height;return c.getContext('2d').getImageData(Math.round(sx),Math.round(sy),1,1).data[3]}",[bx,by])
def handles(pg): return pg.evaluate("document.querySelectorAll('.board-ov [data-h]').length")
def hint(pg): return pg.evaluate("(()=>{const e=document.getElementById('boardHint');return e&&!e.hidden?[e.textContent.trim(),e.dataset.kind]:null})()")
with sync_playwright() as p:
    ctx=launch(p,'board',1440,900); pg,logs=new_page(ctx); open_sheet(pg,'modified.html')
    ti=thumb_index(pg,'Tejido'); select_thumb(pg,ti); pg.wait_for_timeout(900)
    s=sheet(pg)
    r.add('Al elegir Tejido el centro es una mesa: hoja cuadrada sobre el gris, y la foto estática desaparece',pg.locator('#boardHost').is_visible() and abs(s['w']-s['h'])<2 and pg.evaluate("getComputedStyle(document.getElementById('photoStage')).display")=='none',s)
    nb=pg.locator('.board-island .board-btn:visible').count(); r.add('La isla es mínima, como en el diseño: texto, círculo, cuadrado, flecha, medida y color (selección, mano, imagen y deshacer van por teclado, arrastre y pegado)',nb==5 and pg.locator('.board-color input').count()==1,nb)
    c=pix(pg,500,500); ka=pixa(pg,20,980); r.add('La imagen de la tarjeta (tejido oscuro) está colocada y centrada; no hay ningún cuadrado ni hoja pintados (el resto del lienzo es transparente sobre el gris)',sum(c)<300 and ka==0 and pg.evaluate("getComputedStyle(document.querySelector('.board-sheet')).opacity")=='0',(c,ka))
    select_thumb(pg,thumb_index(pg,'Plano')); pg.wait_for_timeout(700)
    r.add('El plano técnico mantiene su editor de marcas (no hay mesa)',(not pg.locator('#boardHost').is_visible()) and pg.locator('#annotationModal').is_visible(),'')
    select_thumb(pg,thumb_index(pg,'Prenda')); pg.wait_for_timeout(700)
    r.add('La tarjeta Prenda también es una mesa (con la foto de la prenda)',pg.locator('#boardHost').is_visible() and sum(pix(pg,500,500))>0,'')
    select_thumb(pg,ti); pg.wait_for_timeout(700)
    # ---- seleccionar, mover, escalar
    x,y=P(pg,500,500); pg.mouse.click(x,y); pg.wait_for_timeout(200)
    r.add('Pulsar la imagen la selecciona: aparecen sus 8 tiradores',handles(pg)==8,handles(pg))
    s=sheet(pg); pg.mouse.move(x,y); pg.mouse.down(); pg.mouse.move(x-80,y-60,steps=6); pg.mouse.up(); pg.wait_for_timeout(400)
    o=cur(pg); dxu=-80/s['w']*1000
    r.add('Arrastrar la imagen la mueve (≈ −109 unidades en x) y se guarda',o and len(o)==1 and abs((o[0]['x']-(1000-o[0]['w'])/2)-dxu)<8,o[0] if o else None)
    sx,sy=P(pg,o[0]['x']+o[0]['w'],o[0]['y']+o[0]['h']); w0=o[0]['w']
    pg.mouse.move(sx,sy); pg.mouse.down(); pg.mouse.move(sx+40,sy+40,steps=5); pg.mouse.up(); pg.wait_for_timeout(400)
    o2=cur(pg); ratio0=o[0]['w']/o[0]['h']; ratio1=o2[0]['w']/o2[0]['h']
    r.add('El tirador de la esquina escala la imagen manteniendo su proporción',o2[0]['w']>w0+20 and abs(ratio1-ratio0)<0.02,(w0,o2[0]['w'],ratio0,ratio1))
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(300); o3=cur(pg)
    r.add('Deshacer (Ctrl+Z) devuelve el tamaño anterior',abs(o3[0]['w']-w0)<1,(w0,o3[0]['w']))
    pg.keyboard.press('Control+Shift+z'); pg.wait_for_timeout(300); o4=cur(pg); r.add('Rehacer lo vuelve a aplicar',o4[0]['w']>w0+20,o4[0]['w'])
    # ---- soltar imágenes
    pg.evaluate(JS_DROP,[250,250,'roja','#e02020',300,200]); pg.wait_for_timeout(1200)
    pg.evaluate(JS_DROP,[750,750,'azul','#2040e0',300,200]); pg.wait_for_timeout(1200)
    o=cur(pg); imgs=[q for q in o if q['t']=='image']
    r.add('Soltar un archivo sobre la hoja lo coloca donde lo sueltas (centrado en el punto)',len(imgs)==3 and abs(imgs[1]['x']+imgs[1]['w']/2-250)<12 and abs(imgs[2]['y']+imgs[2]['h']/2-750)<12,[(round(q['x']),round(q['y']),round(q['w']),round(q['h'])) for q in imgs])
    r.add('Y no aparece la antigua pantalla partida Sustituir/Añadir',pg.locator('#dropSplit:visible').count()==0,'')
    # ---- borrar y deshacer
    n0=len(cur(pg)); pg.keyboard.press('Delete'); pg.wait_for_timeout(300); n1=len(cur(pg))
    r.add('Supr borra el objeto seleccionado',n1==n0-1,(n0,n1)); pg.keyboard.press('Control+z'); pg.wait_for_timeout(300); r.add('…y Deshacer lo recupera',len(cur(pg))==n0,len(cur(pg)))
    # ---- formas
    pg.locator('[data-btool="rect"]').click(); pg.wait_for_timeout(150); a=P(pg,100,600); b=P(pg,300,780); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(300); pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
    rr=[q for q in cur(pg) if q['t']=='rect']; r.add('El cuadrado se dibuja arrastrando sobre la hoja y la herramienta vuelve a «seleccionar»',len(rr)==1 and abs(rr[0]['w']-200)<10 and pg.locator('[data-btool="select"][aria-pressed="true"]').count()==1,rr)
    pg.locator('[data-btool="ellipse"]').click(); a=P(pg,600,100); b=P(pg,800,260); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(300); pg.keyboard.press('Escape'); pg.wait_for_timeout(150)
    r.add('El círculo también',len([q for q in cur(pg) if q['t']=='ellipse'])==1,'')
    # flecha clic-clic
    pg.locator('[data-btool="arrow"]').click(); pg.wait_for_timeout(150); h0=hint(pg); a=P(pg,150,880); pg.mouse.click(*a); pg.wait_for_timeout(200); h1=hint(pg)
    r.add('Flecha: ayuda «clic donde empieza» y tras el primer clic «Ahora haz clic donde termina»',h0 and 'empieza' in h0[0] and h1 and 'termina' in h1[0] and h1[1]=='pending',(h0,h1))
    r.add('…y el primer clic no guarda nada',len([q for q in cur(pg) if q['t']=='arrow'])==0,'')
    b=P(pg,420,880); pg.mouse.move(*b,steps=4); pg.mouse.click(*b); pg.wait_for_timeout(300)
    ar=[q for q in cur(pg) if q['t']=='arrow']; r.add('El segundo clic crea la flecha, con aviso «✓ Flecha lista»',len(ar)==1 and (hint(pg) or ['',''])[0].startswith('✓'),(ar,hint(pg)))
    pg.locator('[data-btool="arrow"]').click(); pg.mouse.click(*P(pg,700,500)); pg.wait_for_timeout(150); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    r.add('Esc a mitad cancela la flecha sin guardar (la herramienta sigue lista para empezar otra)',len([q for q in cur(pg) if q['t']=='arrow'])==1 and (hint(pg) or ['',''])[1]=='start',hint(pg))
    # texto
    pg.locator('[data-btool="text"]').click(); pg.mouse.click(*P(pg,780,110)); pg.wait_for_timeout(250)
    ta=pg.locator('.board-text-edit'); r.add('Texto: un clic abre el cuadro para escribir sobre la hoja',ta.count()==1,ta.count())
    pg.keyboard.type('Posición del label'); pg.mouse.click(*P(pg,900,950)); pg.wait_for_timeout(350)
    tx=[q for q in cur(pg) if q['t']=='text']; r.add('Al salir del cuadro se guarda el texto',len(tx)==1 and tx[0]['text']=='Posición del label',tx)
    # ---- un tirador fuera de la hoja también se alcanza
    imgs=[q for q in cur(pg) if q['t']=='image']; big=imgs[0]; pg.mouse.click(*P(pg,big['x']+big['w']/2,big['y']+big['h']/2)); pg.wait_for_timeout(150)
    delta=1050-(big['x']+big['w']); s=sheet(pg); c0=P(pg,big['x']+big['w']/2,big['y']+big['h']/2); c1=P(pg,big['x']+big['w']/2+delta,big['y']+big['h']/2)
    pg.mouse.move(*c0); pg.mouse.down(); pg.mouse.move(*c1,steps=6); pg.mouse.up(); pg.wait_for_timeout(300)
    mv=[q for q in cur(pg) if q['t']=='image'][0]; ex,ey=P(pg,mv['x']+mv['w'],mv['y']+mv['h']/2); outside=ex>s['x']+s['w']+10
    wa=mv['w']; pg.mouse.move(ex,ey); pg.mouse.down(); pg.mouse.move(ex-40,ey,steps=4); pg.mouse.up(); pg.wait_for_timeout(300); wb=[q for q in cur(pg) if q['t']=='image'][0]['w']
    r.add('Un objeto puede salirse de la hoja y su tirador (fuera de ella) sigue funcionando',outside and wb<wa-10,(outside,round(wa),round(wb)))
    # ---- texto de la flecha en la punta: se escribe nada más terminarla
    pg.locator('[data-btool="arrow"]').click(); pg.mouse.click(*P(pg,300,900)); pg.wait_for_timeout(120); pg.mouse.click(*P(pg,600,760)); pg.wait_for_timeout(300)
    r.add('Al terminar la flecha se abre directamente el texto de su punta (sin crear un campo aparte) y ya está enfocado',pg.locator('.board-text-edit').count()==1 and pg.evaluate("document.activeElement&&document.activeElement.classList.contains('board-text-edit')"),pg.locator('.board-text-edit').count())
    pg.keyboard.type('Carro YKK'); pg.keyboard.press('Enter'); pg.keyboard.type('segunda línea'); pg.mouse.click(*P(pg,950,60)); pg.wait_for_timeout(350)
    txs=[q for q in cur(pg) if q['t']=='text' and q.get('text')=='Carro YKK\nsegunda línea']; arrs=[q for q in cur(pg) if q['t']=='arrow']
    r.add('El texto de la flecha es un objeto aparte (varias líneas con Enter) y la flecha no lleva texto',len(txs)==1 and len(arrs)>=1 and not any(a.get('text') for a in arrs),(txs,arrs))
    a_before=json.dumps([q for q in cur(pg) if q['t']=='arrow']); t0=txs[0]; pg.mouse.click(*P(pg,t0['x']+30,t0['y']+20)); pg.wait_for_timeout(600); sx0,sy0=P(pg,t0['x']+30,t0['y']+20); pg.mouse.move(sx0,sy0); pg.mouse.down(); pg.mouse.move(sx0+60,sy0+40,steps=5); pg.mouse.up(); pg.wait_for_timeout(300)
    t1=[q for q in cur(pg) if q['t']=='text' and q.get('text','').startswith('Carro')][0]
    r.add('El texto se mueve solo; la flecha se queda donde está',abs(t1['x']-t0['x'])>20 and json.dumps([q for q in cur(pg) if q['t']=='arrow'])==a_before,(t0['x'],t1['x']))
    n_ar=len([q for q in cur(pg) if q['t']=='arrow']); n_tx=len([q for q in cur(pg) if q['t']=='text'])
    pg.locator('[data-btool="arrow"]').click(); pg.mouse.click(*P(pg,100,700)); pg.wait_for_timeout(120); pg.mouse.click(*P(pg,300,600)); pg.wait_for_timeout(250); pg.keyboard.press('Escape'); pg.wait_for_timeout(250)
    ar2=[q for q in cur(pg) if q['t']=='arrow']; r.add('Esc omite el texto: queda la flecha, no se crea ningún texto vacío y no hay campos abiertos',len(ar2)==n_ar+1 and len([q for q in cur(pg) if q['t']=='text'])==n_tx and pg.locator('.board-text-edit').count()==0,(n_ar,len(ar2)))
    # ---- caja de texto como Figma: tiradores laterales, ancho ajustable, medida
    tx=[q for q in cur(pg) if q['t']=='text'][0]; pg.keyboard.press('Escape'); pg.mouse.click(*P(pg,tx['x']+30,tx['y']+20)); pg.wait_for_timeout(200)
    r.add('Un texto seleccionado muestra tiradores laterales (ancho) y la medida «ancho × alto»',pg.locator('.board-ov [data-h="e"]').count()==1 and pg.locator('.board-ov [data-h="w"]').count()==1 and '×' in pg.evaluate("document.querySelector('.board-ov').textContent"),pg.evaluate("document.querySelector('.board-ov').textContent")[:40])
    ex,ey=pg.evaluate("(()=>{const e=document.querySelector('.board-ov [data-h=\"e\"]').getBoundingClientRect();return [e.left+e.width/2,e.top+e.height/2]})()"); pg.mouse.move(ex,ey); pg.mouse.down(); pg.mouse.move(ex-70,ey,steps=5); pg.mouse.up(); pg.wait_for_timeout(300)
    tx2=[q for q in cur(pg) if q['t']=='text'][0]; r.add('Arrastrar el lado derecho fija el ancho de la caja: el texto se ajusta a varias líneas',tx2['w'] and tx2['w']>0,tx2)
    pg.keyboard.press('Enter'); pg.wait_for_timeout(250); r.add('Enter sobre un texto seleccionado lo edita en la propia mesa',pg.locator('.board-text-edit').count()==1,pg.locator('.board-text-edit').count()); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    pg.keyboard.press('Escape'); pg.mouse.click(*P(pg,950,40)); pg.wait_for_timeout(150); pg.mouse.dblclick(*P(pg,tx2['x']+30,tx2['y']+20)); pg.wait_for_timeout(350); r.add('Doble clic sobre un texto lo edita en la propia mesa',pg.locator('.board-text-edit').count()==1,pg.locator('.board-text-edit').count()); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    # ---- persistencia
    n_before=len(cur(pg)); pg.wait_for_timeout(400); pg.reload(); pg.wait_for_timeout(1500)
    if not pg.locator('#technicalSheetApp').is_visible(): pg.locator('#projectGrid > *').first.click(); pg.wait_for_timeout(1500)
    select_thumb(pg,thumb_index(pg,'Tejido')); pg.wait_for_timeout(900)
    r.add('Tras recargar, la mesa conserva todo lo colocado',len(cur(pg))==n_before and sum(pix(pg,250,250))<700,(n_before,len(cur(pg)),pix(pg,250,250)))
    # ---- por color
    ob=objs(pg); r.add('La mesa es por color: solo el color activo (Rojo) la tiene guardada',any('red' in k for k in ob) and not any('black' in k for k in ob),list(ob.keys()))
    # ---- ZOOM Y DESPLAZAMIENTO (como Figma)
    def zl(): return pg.evaluate("document.querySelector('[data-zlabel]').textContent")
    def zoomv(): return pg.evaluate("window.__BOARD.zoom")
    s0=sheet(pg); ZL0=zl(); Zf=pg.evaluate('window.__BOARD.zoom'); r.add('Hay una barra de zoom con − / porcentaje / + y la mesa entra ajustada al contenido (todo a la vista)',pg.locator('#boardHost .board-zoom').is_visible() and 80<=int(ZL0[:-1])<=110,ZL0)
    cx,cy=s0['x']+s0['w']*0.3,s0['y']+s0['h']*0.35; bu=((cx-s0['x'])/s0['w']*1000,(cy-s0['y'])/s0['h']*1000)
    pg.mouse.move(cx,cy); pg.keyboard.down('Control'); pg.mouse.wheel(0,-100); pg.keyboard.up('Control'); pg.wait_for_timeout(250)
    s1=sheet(pg); bu1=((cx-s1['x'])/s1['w']*1000,(cy-s1['y'])/s1['h']*1000)
    r.add('Ctrl/Cmd + rueda hace zoom in y el punto bajo el cursor se queda quieto',s1['w']>s0['w']*1.2 and abs(bu1[0]-bu[0])<3 and abs(bu1[1]-bu[1])<3 and zl()!='100%',(round(s0['w']),round(s1['w']),bu,bu1,zl()))
    pg.mouse.move(cx,cy); pg.keyboard.down('Control'); pg.mouse.wheel(0,100); pg.mouse.wheel(0,100); pg.keyboard.up('Control'); pg.wait_for_timeout(250); s2=sheet(pg)
    r.add('Ctrl/Cmd + rueda al revés hace zoom out',s2['w']<s1['w']*0.7,(round(s1['w']),round(s2['w'])))
    pg.locator('[data-bz="fit"]').click(); pg.wait_for_timeout(200); s3=sheet(pg)
    r.add('Pulsar el porcentaje vuelve a ajustar el contenido a la vista',abs(s3['w']-s0['w'])<2 and abs(s3['x']-s0['x'])<2 and zl()==ZL0,(s0,s3))
    pg.mouse.move(s0['x']+300,s0['y']+300); pg.mouse.wheel(0,80); pg.wait_for_timeout(250); s4=sheet(pg)
    r.add('La rueda sola desplaza la mesa (como Figma), sin cambiar el zoom',abs((s4['y']-s3['y'])+80)<3 and abs(s4['w']-s3['w'])<1,(s3['y'],s4['y']))
    pg.locator('[data-bz="fit"]').click(); pg.locator('[data-bz="in"]').click(); pg.locator('[data-bz="in"]').click(); pg.wait_for_timeout(200)
    r.add('Los botones + y − cambian el zoom (×1,25 cada paso)',abs(int(zl()[:-1])-round(Zf*1.5625*100))<=1,zl())
    pg.locator('[data-bz="out"]').click(); pg.locator('[data-bz="out"]').click(); pg.locator('[data-bz="out"]').click(); pg.wait_for_timeout(200); r.add('…y − lo reduce',abs(int(zl()[:-1])-round(Zf*1.5625/1.953125*100))<=1,zl())
    pg.keyboard.press('Control+0'); pg.wait_for_timeout(200); r.add('Cmd/Ctrl + 0 ajusta a la vista',zl()==ZL0,zl())
    pg.keyboard.press('Control+='); pg.wait_for_timeout(200); z1=zoomv(); pg.keyboard.press('Control+-'); pg.wait_for_timeout(200); z2=zoomv()
    r.add('Cmd/Ctrl + «+» y «−» del teclado hacen zoom',z1>Zf*1.2 and abs(z2-Zf)<0.01,(z1,z2,Zf))
    for _ in range(25): pg.keyboard.press('Control+=')
    pg.wait_for_timeout(200); r.add('El zoom tiene tope (800%)',zoomv()<=8.001 and zl()=='800%',zl())
    for _ in range(40): pg.keyboard.press('Control+-')
    pg.wait_for_timeout(200); r.add('…y mínimo (10%)',zoomv()>=0.0999 and zl()=='10%',zl())
    pg.keyboard.press('Control+0'); pg.wait_for_timeout(200)
    # desplazar con Espacio + arrastrar y con la herramienta Mano
    s5=sheet(pg); n_before=json.dumps(cur(pg)); pg.mouse.move(s5['x']+s5['w']*0.9,s5['y']+s5['h']*0.9); pg.keyboard.down(' '); pg.mouse.down(); pg.mouse.move(s5['x']+s5['w']*0.9-90,s5['y']+s5['h']*0.9-60,steps=6); pg.mouse.up(); pg.keyboard.up(' '); pg.wait_for_timeout(250); s6=sheet(pg)
    r.add('Mantener Espacio y arrastrar desplaza la vista (sin mover objetos)',abs((s6['x']-s5['x'])+90)<4 and abs((s6['y']-s5['y'])+60)<4 and json.dumps(cur(pg))==n_before,(s5['x'],s6['x'],s5['y'],s6['y']))
    pg.keyboard.press('Control+0'); pg.wait_for_timeout(150)
    # interacción con zoom: mover un objeto 100 px de pantalla equivale a 100/k unidades
    pg.locator('[data-bz="in"]').click(); pg.locator('[data-bz="in"]').click(); pg.wait_for_timeout(250); sz=sheet(pg); k=sz['w']/1000
    imgs=[q for q in cur(pg) if q['t']=='image']; o0=imgs[-1]; px_,py_=P(pg,o0['x']+o0['w']*0.12,o0['y']+o0['h']*0.12)
    isl=pg.locator('.board-island').bounding_box()
    if isl and isl['x']<=px_<=isl['x']+isl['width'] and isl['y']<=py_<=isl['y']+isl['height']: py_=isl['y']+isl['height']+30
    ok_vis=0<px_<1400 and 0<py_<900
    if ok_vis:
        pg.mouse.click(px_,py_); pg.wait_for_timeout(150); pg.mouse.move(px_,py_); pg.mouse.down(); pg.mouse.move(px_+50,py_+30,steps=5); pg.mouse.up(); pg.wait_for_timeout(300)
        o1=[q for q in cur(pg) if q['t']=='image'][-1]
    r.add('Con zoom, mover un objeto 50 px en pantalla lo mueve 50/zoom unidades en la hoja',ok_vis and abs((o1['x']-o0['x'])-50/k)<4 and abs((o1['y']-o0['y'])-30/k)<4,(round(k,3),(o1['x']-o0['x']) if ok_vis else None,50/k))
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(250)
    pg.evaluate(JS_DROP,[600,600,'zoomdrop','#20a040',200,200]); pg.wait_for_timeout(1000)
    zd=[q for q in cur(pg) if q['t']=='image'][-1]; r.add('Con zoom, soltar un archivo lo coloca exactamente donde se suelta',abs(zd['x']+zd['w']/2-600)<10 and abs(zd['y']+zd['h']/2-600)<10,(zd['x']+zd['w']/2,zd['y']+zd['h']/2))
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(250); pg.keyboard.press('Control+0'); pg.wait_for_timeout(200)
    # pellizco de dos dedos
    pg.evaluate("""()=>{const B=window.__BOARD,r=B.host.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,mk=(t,id,x,y)=>B.svg.dispatchEvent(new PointerEvent(t,{pointerId:id,clientX:x,clientY:y,bubbles:true,button:0,isPrimary:id===1,pointerType:'touch'}));mk('pointerdown',1,cx-50,cy);mk('pointerdown',2,cx+50,cy);mk('pointermove',1,cx-100,cy);mk('pointermove',2,cx+100,cy);mk('pointerup',1,cx-100,cy);mk('pointerup',2,cx+100,cy)}""")
    pg.wait_for_timeout(250); r.add('Pellizco de dos dedos (táctil): separar los dedos hace zoom in (≈ ×2)',1.8<zoomv()<2.2,zoomv())
    pg.keyboard.press('Control+0'); pg.wait_for_timeout(200)
    # ---- PDF: lo que ves es lo que se exporta
    pg.mouse.click(*P(pg,500,500)); pg.wait_for_timeout(150); pg.locator('[data-bact="reset"]').click(); pg.wait_for_timeout(300)
    pg.keyboard.press('Control+a') if False else None
    x,y=P(pg,500,500); pg.mouse.click(x,y); pg.wait_for_timeout(150); pg.keyboard.press('Delete'); pg.wait_for_timeout(250)
    pg.evaluate(JS_DROP,[250,250,'roja2','#e02020',300,200]); pg.wait_for_timeout(1200)
    pg.evaluate(JS_DROP,[750,750,'azul2','#2040e0',300,200]); pg.wait_for_timeout(1200)
    pg.keyboard.press('Escape'); pg.locator('[data-bz="in"]').click(); pg.mouse.move(*P(pg,500,500)); pg.mouse.wheel(60,90); pg.wait_for_timeout(250)
    g=export_pdf(pg,'board',colors=('Rojo',),changes=False); fn=g[0][1]; n,_,t=pdf_info(fn)
    page=[i for i,x in enumerate(t[:n]) if 'Tejido' in x and 'Identificación' not in x[:600]]
    r.add('La hoja de Tejido sale en el PDF aunque solo tenga mesa (sin apartados)',len(page)>=1,[i for i in range(n)])
    pi=page[0]+1 if page else 2
    for f in glob.glob('pdfs/boardpg*'): __import__('os').remove(f)
    subprocess.run(['pdftoppm','-r','100','-f',str(pi),'-l',str(pi),'-png',fn,'pdfs/boardpg'],check=True)
    im=Image.open(sorted(glob.glob('pdfs/boardpg*.png'))[0]).convert('RGB'); W,H=im.size
    red=[];blue=[]
    for yy in range(0,H,2):
        for xx in range(0,int(W*0.75),2):
            c=im.getpixel((xx,yy))
            if c[0]>190 and c[1]<70 and c[2]<70: red.append((xx,yy))
            if c[2]>190 and c[0]<70 and c[1]<110: blue.append((xx,yy))
    cen=lambda L:(sum(a for a,b in L)/len(L),sum(b for a,b in L)/len(L)) if L else (0,0)
    rc,bc=cen(red),cen(blue); dx,dy=bc[0]-rc[0],bc[1]-rc[1]; side=dx/0.5
    r.add('En el PDF las dos imágenes están en la misma posición relativa que en la mesa (rojo arriba-izquierda, azul abajo-derecha, mismo desplazamiento en x e y)',len(red)>200 and len(blue)>200 and dx>60 and abs(dx-dy)<dx*0.08,(len(red),len(blue),rc,bc,dx,dy))
    import subprocess as _sp
    lst=_sp.run(['pdfimages','-list',fn],capture_output=True,text=True).stdout.split('\n')[2:]
    dims=[(int(l.split()[3]),int(l.split()[4])) for l in lst if l.strip()]
    r.add('…y el PDF recorta la imagen de la mesa a TODO su contenido (proporción del contenido, no un cuadrado fijo)',any(abs(a/b-1)>0.05 for a,b in dims),dims)
    errs=[l for l in logs if l[0] in('pageerror','console.error','reqfailed')]; r.add('Consola sin errores',not errs,errs[:3]); ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
