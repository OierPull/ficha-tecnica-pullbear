# Pluma como Illustrator, estilo de línea en trazos, barra ordenada, «×» de Trims, curva sin recorte, doble clic directo
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'pen3',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','P3'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    sk=pg.evaluate("window.__PG.pages[1].v.id"); pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    W="([id,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    PEN="()=>window.__BOARD.objects.filter(o=>o.pen).map(o=>[o.pen.mode,o.pen.closed,o.pen.pts.length])"
    # pluma: Esc termina y la herramienta sigue; segundo trazo; Ctrl+clic termina
    pg.keyboard.press('Shift+P'); pg.wait_for_timeout(150)
    for xy in [(100,100),(250,180),(400,100)]: pg.mouse.click(*pg.evaluate(W,[sk,*xy])); pg.wait_for_timeout(450)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    a=pg.evaluate(PEN); m=pg.evaluate("window.__PG.penMode")
    r.add('Pluma: Esc termina el trazo y la herramienta sigue activa (como Illustrator)',a==[['pen',False,3]] and m=='pen',(a,m))
    for xy in [(100,300),(250,380)]: pg.mouse.click(*pg.evaluate(W,[sk,*xy])); pg.wait_for_timeout(450)
    pg.keyboard.down('Control'); pg.mouse.click(*pg.evaluate(W,[sk,600,600])); pg.keyboard.up('Control'); pg.wait_for_timeout(300)
    a=pg.evaluate(PEN)
    r.add('Pluma: Cmd/Ctrl + clic en vacío termina el trazo abierto',a==[['pen',False,3],['pen',False,2]],a)
    # cerrar haciendo clic en el primer punto
    for xy in [(500,100),(650,100),(575,220)]: pg.mouse.click(*pg.evaluate(W,[sk,*xy])); pg.wait_for_timeout(450)
    pg.mouse.click(*pg.evaluate(W,[sk,500,100])); pg.wait_for_timeout(300)
    a=pg.evaluate(PEN)
    r.add('Pluma: clic en el primer punto cierra la forma',a[-1:]==[['pen',True,3]],a)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    r.add('Un segundo Esc (sin trazo en curso) vuelve a selección',pg.evaluate("window.__PG.penMode") is None,'')
    # curvatura con punto de esquina por doble clic
    pg.keyboard.press('Shift+`') if False else pg.locator('.board-island [data-pgpen="curve"]').click(); pg.wait_for_timeout(150)
    pg.mouse.click(*pg.evaluate(W,[sk,150,500])); pg.wait_for_timeout(450); pg.mouse.dblclick(*pg.evaluate(W,[sk,300,450])); pg.wait_for_timeout(100); pg.mouse.click(*pg.evaluate(W,[sk,450,560])); pg.wait_for_timeout(450)
    pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
    c=pg.evaluate("(()=>{const o=window.__BOARD.objects.filter(o=>o.pen).pop();return [o.pen.mode,o.pen.pts.length,o.pen.pts.map(p=>!!p.corner)]})()")
    r.add('Curvatura: doble clic crea un punto de esquina (sin puntos repetidos)',c[0]=='curve' and c[1]==3 and c[2]==[False,True,False],c)
    # curva que se sale de la caja: la caja incluye la curva entera
    pg.mouse.click(*pg.evaluate(W,[sk,150,700])); pg.mouse.click(*pg.evaluate(W,[sk,400,620])); pg.mouse.click(*pg.evaluate(W,[sk,420,780])); pg.mouse.click(*pg.evaluate(W,[sk,160,760])); pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
    ok=pg.evaluate("""(()=>{const o=window.__BOARD.objects.filter(o=>o.pen).pop(),t=decodeURIComponent(o.src.split(',')[1]);const d=document.createElement('div');d.style.cssText='position:fixed;left:-9999px';d.innerHTML=t;document.body.appendChild(d);const sv=d.querySelector('svg'),bb=sv.getBBox(),vb=sv.viewBox.baseVal;d.remove();return [bb.x>=vb.x-0.5,bb.y>=vb.y-0.5,bb.x+bb.width<=vb.x+vb.width+0.5,bb.y+bb.height<=vb.y+vb.height+0.5]})()""")
    r.add('La curva queda entera dentro de su caja (no se corta)',all(ok),ok)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    # estilo de línea en un trazo de pluma
    oid=pg.evaluate("window.__BOARD.objects.filter(o=>o.pen)[0].id")
    pg.mouse.click(*pg.evaluate(W,[sk,175,140])); pg.wait_for_timeout(400)
    sel=pg.evaluate("window.__BOARD.sel")
    lv=pg.locator('.board-ctxbar .board-ctx-line').is_visible()
    if lv: pg.locator('.board-ctxbar [data-bdash="dash"]').click(); pg.wait_for_timeout(300)
    dsh=pg.evaluate("id=>{const o=window.__BOARD.objects.find(o=>o.id===id);return [o.pen.dash,decodeURIComponent(o.src.split(',')[1]).indexOf('stroke-dasharray')>=0]}",sel)
    if lv: pg.locator('.board-ctxbar [data-bdash="dot"]').click(); pg.wait_for_timeout(300)
    dot=pg.evaluate("id=>window.__BOARD.objects.find(o=>o.id===id).pen.dash",sel)
    r.add('Los trazos de pluma pueden ser discontinuos o de puntos',lv and dsh==['dash',True] and dot=='dot',(lv,dsh,dot))
    # barra ordenada
    ordv=pg.evaluate("[...document.querySelector('.board-ctxbar').children].filter(c=>!c.hidden&&getComputedStyle(c).display!=='none').sort((a,b)=>(+a.dataset.pgord)-(+b.dataset.pgord)).map(c=>c.dataset.pgord)")
    nums=[int(x) for x in ordv if x]
    nums=[int(x) for x in ordv if x]
    r.add('La barra se ordena: estilo y color primero, capas al final y sin papelera',nums==sorted(nums) and nums[0]<=4 and 10 not in nums,ordv)
    pg.keyboard.press('Escape'); empty_click(pg); pg.wait_for_timeout(200)
    # doble clic directo a puntos aunque no se acierte en la línea
    o=pg.evaluate("id=>{const P=window.__PG,o=window.__BOARD.objects.find(o=>o.id===id),p=P.pages[1];return [o.x-p.ox+o.w*0.5,o.y+o.h*0.85]}",oid)
    pg.mouse.dblclick(*pg.evaluate(W,[sk,o[0],o[1]])); pg.wait_for_timeout(800)
    sv=pg.evaluate("window.__svgp&&window.__svgp()")
    r.add('Doble clic en un trazo de pluma (aunque no se acierte en la línea): directo a editar los puntos, sin el paso «Listo»',bool(sv),sv)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(200); pg.keyboard.press('Escape'); pg.wait_for_timeout(300)
    # Trims: «×» deja la página vacía
    tr=pg.evaluate("window.__PG.pages.find(p=>p.name==='Trims').v.id")
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",tr); pg.wait_for_timeout(1200)
    x=pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) .pg-trimx'%tr)
    hx=x.count()==1 and x.is_visible()
    if hx: x.click(); pg.wait_for_timeout(1300)
    st=pg.evaluate("id=>{const s=document.querySelector('.pg-layer .pg-spec[data-pgv=\"'+id+'\"]:not(.is-preview)');const tp=s.querySelector('.pgs-trimpick');return [s.classList.contains('pg-spec-empty'),!!tp&&getComputedStyle(tp).visibility!=='hidden'&&tp.getBoundingClientRect().width>0,!!s.querySelector('.pg-specshow')]}",tr)
    r.add('Trims: la «×» del selector deja la página vacía (con «Campos» para recuperarlo)',hx and st==[True,False,True],(hx,st))
    pg.locator('.pg-layer .pg-spec[data-pgv="%s"]:not(.is-preview) .pg-specshow'%tr).click(); pg.wait_for_timeout(1300)
    back=pg.evaluate("id=>!!document.querySelector('.pg-layer .pg-spec[data-pgv=\"'+id+'\"]:not(.is-preview) .pgs-trimpick button')",tr)
    r.add('…y «Campos» vuelve a mostrar el selector de trims',back,'')
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
