# Cambiar de color o de página sin saltos: la hoja pulsada se queda donde está y no hay estados intermedios
import os
from h import *
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
TRACK="""()=>{window.__tr=[];const B=window.__BOARD,t0=performance.now();(function f(){window.__tr.push([Math.round(performance.now()-t0),Math.round((window.__PG.painted||[B.panX])[0]),Math.round((window.__PG.painted||[0,B.panY])[1]),+((window.__PG.painted||[0,0,B.zoom])[2]).toFixed(3)]);if(performance.now()-t0<1500)requestAnimationFrame(f)})()}"""
def changes(pg):
    tr=pg.evaluate("window.__tr"); out=[]; prev=None
    for t,x,y,z in tr:
        if prev is None or (x,y,z)!=prev: out.append((t,x,y,z))
        prev=(x,y,z)
    return out
def monotonic(seq):
    d=[b-a for a,b in zip(seq,seq[1:]) if b!=a]
    return all(x>0 for x in d) or all(x<0 for x in d)
with sync_playwright() as p:
    ctx=launch(p,'rsw',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','RS'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    for c in ('19-4052','18-1664'):
        pg.evaluate("document.querySelector('.pg-addcol-fixed').click()"); pg.wait_for_timeout(700); pg.locator('#cdPantone').fill(c); pg.locator('form.color-dialog .cd-submit').click(); pg.wait_for_timeout(1800)
    li=pg.evaluate("window.__PG.pages.find(x=>x.i===3).v.id"); sk=pg.evaluate("window.__PG.pages.find(x=>x.i===1).v.id")
    pg.evaluate("id=>document.querySelector('.pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",li); pg.wait_for_timeout(1500)
    pg.mouse.move(720,450)
    for _ in range(2): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(800)
    loc=pg.locator('.pg-rowhit[data-pgv="%s"][data-ci="0"]'%li).first; b=loc.bounding_box()
    if b['y']<60 or b['y']+b['height']>860:
        pg.mouse.wheel(0,(b['y']-300)); pg.wait_for_timeout(700); b=loc.bounding_box()
    row=loc.get_attribute('data-pgrow'); top0=round(b['y']); left0=round(b['x'])
    pg.evaluate(TRACK); pg.mouse.click(b['x']+b['width']/2,b['y']+b['height']/2); pg.wait_for_timeout(1700)
    ch=changes(pg)
    act=pg.evaluate("c=>{const l=[...document.querySelectorAll('.pg-rowlab')].find(x=>x.dataset.pgrow===c);return !!(l&&l.classList.contains('is-on'))}",row)
    r.add('(preparación) Pulsar Linning de otro color activa ese color',act,'')
    zs={z for t,x,y,z in ch}; xs={x for t,x,y,z in ch}
    r.add('Misma página en otro color: sin estados intermedios (ni zoom ni posición horizontal cambian; como mucho un ajuste vertical)',len(zs)==1 and len(xs)==1 and len(ch)<=2,ch)
    sh=pg.evaluate("id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [Math.round(hr.left+v.ox+p.ox*v.k),Math.round(hr.top+v.oy)]}",li)
    r.add('…y la hoja pulsada se queda en el mismo sitio de la pantalla',abs(sh[0]-left0)<=3 and abs(sh[1]-top0)<=3,(sh,(left0,top0)))
    pg.wait_for_timeout(500); pg.evaluate(TRACK)
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview):not(.is-cont) [data-pgnav=\"'+id+'\"], .pg-layer .pg-lab:not(.is-preview) .pgl-cur')&&0",li)
    pos=pg.evaluate("id=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+300)*v.k,hr.top+v.oy+300*v.k]}",li)
    pg.mouse.click(*pos); pg.wait_for_timeout(1600)
    r.add('Pulsar de nuevo la página en la que ya estás: no se mueve nada',len(changes(pg))<=1,changes(pg))
    pg.evaluate(TRACK)
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1700)
    ch=changes(pg); xs=[x for t,x,y,z in ch]
    r.add('Otra página del mismo color: se desliza en un solo sentido, sin idas y vueltas ni cambios de zoom',len(ch)>2 and monotonic(xs) and len({z for t,x,y,z in ch})==1,(len(ch),xs[:3],xs[-3:]))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
