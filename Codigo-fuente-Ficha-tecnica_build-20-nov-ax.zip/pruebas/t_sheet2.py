# La hoja 2 se selecciona por separado: el marco rodea solo la hoja pulsada
import os
from h import *
from PIL import Image
r=R(); URLX=os.environ.get('SHARE_URL',BASE+'modified.html')
with sync_playwright() as p:
    ctx=launch(p,'sh2',1440,900); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept()); pg.goto(URLX); pg.wait_for_timeout(2000)
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(300); pg.fill('#newProjectModel','H2'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3000)
    sk=pg.evaluate("window.__PG.pages.find(x=>x.i===1).v.id")
    pg.evaluate("id=>document.querySelector('.pg-layer .pg-lab:not(.is-preview) [data-pgnav=\"'+id+'\"]').click()",sk); pg.wait_for_timeout(1200)
    card='.pg-spec[data-pgv="%s"]:not(.is-preview)'%sk
    for _ in range(7): pg.locator(card+' .pgs-addb').last.click(); pg.wait_for_timeout(450)
    pg.mouse.move(720,450)
    for _ in range(3): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(80)
    pg.wait_for_timeout(800)
    W="([id,ci,wx,wy])=>{const P=window.__PG,p=P.pages.find(x=>x.v.id===id),v=window.__pgV(),hr=document.querySelector('.board-host').getBoundingClientRect();return [hr.left+v.ox+(p.ox+ci*(P.SHW+P.VG)+wx)*v.k,hr.top+v.oy+wy*v.k]}"
    def dark_edge(ci):
        a=pg.evaluate(W,[sk,ci,0,0]); b=pg.evaluate(W,[sk,ci,800,0])
        pg.screenshot(path='audit/sh2.png'); im=Image.open('audit/sh2.png').convert('L'); y=int(round(a[1]))
        n=0
        for x in range(int(a[0])+10,int(b[0]),4):
            if 0<=x<im.size[0] and 0<=y<im.size[1] and min(im.getpixel((x,yy)) for yy in range(max(0,y-2),min(im.size[1],y+3)))<60: n+=1
        return n
    m=pg.evaluate(W,[sk,1,300,400])
    if not (0<m[0]<1400): pg.mouse.wheel(m[0]-900,0); pg.wait_for_timeout(700); m=pg.evaluate(W,[sk,1,300,400])
    pg.mouse.click(*m); pg.wait_for_timeout(700)
    e1=dark_edge(1); e0=dark_edge(0)
    r.add('Pulsar la hoja 2 la selecciona a ella sola (marco en la hoja 2, no en la 1)',e1>20 and e0<5,(e1,e0))
    m=pg.evaluate(W,[sk,0,300,400]); pg.mouse.click(*m); pg.wait_for_timeout(700)
    e1=dark_edge(1); e0=dark_edge(0)
    r.add('Pulsar la hoja 1 vuelve a marcar solo la hoja 1',e0>20 and e1<5,(e0,e1))
    r.add('Consola sin errores',not [x for x in lg if 'error' in str(x).lower()][:1],str(lg[:2]))
    ctx.close()
print('RESUMEN: %d pruebas, %d fallos'%(len(r.rows),len([x for x in r.rows if not x[1]])))
