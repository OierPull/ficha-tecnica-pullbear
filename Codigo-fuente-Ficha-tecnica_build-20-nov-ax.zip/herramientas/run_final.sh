#!/bin/bash
cd /home/claude/work; unset SHARE_URL; : > final.txt
for t in t_ui5 t_sideadd t_supswitch t_sheet2 t_crossrow t_focusall t_mirror t_same t_mins t_rowgrid t_last t_free t_rowswitch t_switch t_double t_pdf2 t_ux4 t_gridlink t_indepf t_rows2 t_activate t_hist2 t_rows t_index t_gridpdf t_grid t_rules t_status t_ctxbar t_guides t_pages2 t_sheet t_pages t_specs t_pdfpages t_hdr t_tabs t_ui4 t_ver t_colfield t_fhist t_dlg t_nocolor t_colsec t_card t_norej t_sup; do
  (curl -s -o /dev/null -m 3 http://127.0.0.1:8765/modified.html) || ((setsid nohup python3 -m http.server 8765 --bind 127.0.0.1 > /tmp/srv.log 2>&1 < /dev/null &) ; sleep 2)
  rm -rf profile/*; echo "$t: $(timeout 280 python3 $t.py 2>&1 | grep -E '^(FAIL|RESUMEN)|Traceback' | tr '\n' ' ' | cut -c1-400)" >> final.txt
done
echo FIN1 >> final.txt
timeout 150 python3 make_pkg2.py modified.html dist LEEME_new.txt >> final.txt 2>&1 && rm -rf unz && mkdir unz && (cd unz && unzip -q ../dist/Ficha-tecnica-PullBear_build-18-nov-q.zip && sha256sum -c SHA256.txt) >> final.txt 2>&1
export SHARE_URL="file:///home/claude/work/unz/Ficha-tecnica-PullBear.html"
for t in t_ui5 t_sideadd t_crossrow t_focusall t_mirror t_same t_rowgrid t_free t_rowswitch t_double t_pdf2 t_gridlink t_rows2 t_index t_grid t_rules t_pages2 t_pdfpages; do
  rm -rf profile/*; echo "$t (paquete desde disco): $(timeout 280 python3 $t.py 2>&1 | grep -E '^(FAIL|RESUMEN)|Traceback' | tr '\n' ' ' | cut -c1-400)" >> final.txt
done
echo FIN2 >> final.txt
