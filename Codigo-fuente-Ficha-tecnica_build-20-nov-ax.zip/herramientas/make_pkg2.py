# Empaquetador (reconstruido): sella el HTML (CSP), recomprime imágenes, revisa seguridad y crea el zip con guía y huella.
import re,sys,hashlib,zipfile,os,shutil,base64,io
from PIL import Image
src,outdir=sys.argv[1],sys.argv[2]
html=open(src,encoding='utf-8').read(); BUILD=re.search(r'build ([\w-]+)',html).group(1)
csp=open('/home/claude/work/csp_meta.txt').read()
assert html.count('<head>\n')==1; html=html.replace('<head>\n','<head>'+csp+'\n',1)
def shrink(m):
    try:
        im=Image.open(io.BytesIO(base64.b64decode(m.group(2)))); im.load(); b=io.BytesIO(); im.save(b,'WEBP',quality=50,method=6); nb=base64.b64encode(b.getvalue()).decode()
        return 'data:image/webp;base64,'+nb if len(nb)<len(m.group(2))*0.9 else m.group(0)
    except Exception: return m.group(0)
html=re.sub(r'data:image/(webp|png|jpeg);base64,([A-Za-z0-9+/=]{60000,})',shrink,html)
pats={'fetch':r'\bfetch\s*\(','XMLHttpRequest':r'XMLHttpRequest','WebSocket':r'new\s+WebSocket','sendBeacon':r'sendBeacon','eval':r'\beval\s*\(','scripts externos':r'<script[^>]+src=','estilos externos':r'<link(?![^>]*href="data:)[^>]+href=|@import|url\(\s*["\']?https?:','iframes':r'<iframe'}
res={k:len(re.findall(v,html)) for k,v in pats.items()}; assert all(v==0 for v in res.values()),res
name='Ficha-tecnica-PullBear.html'; pk=os.path.join(outdir,'paquete'); shutil.rmtree(pk,ignore_errors=True); os.makedirs(pk)
open(f'{pk}/{name}','w',encoding='utf-8').write(html); sha=hashlib.sha256(html.encode('utf-8')).hexdigest()
open(f'{pk}/SHA256.txt','w',encoding='utf-8').write(f'{sha}  {name}\n')
leeme=open(sys.argv[3] if len(sys.argv)>3 else '/home/claude/work/z/LEEME.txt',encoding='utf-8').read(); leeme=re.sub(r'build [0-9]{2}-nov-[a-z]','build '+BUILD,leeme)
open(f'{pk}/LEEME.txt','w',encoding='utf-8').write(leeme); shutil.copy('/home/claude/work/z/SEGURIDAD.txt',f'{pk}/SEGURIDAD.txt')
zp=os.path.join(outdir,f'Ficha-tecnica-PullBear_build-{BUILD}.zip')
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
    for f in (name,'LEEME.txt','SEGURIDAD.txt','SHA256.txt'): z.write(f'{pk}/{f}',f)
print(zp,os.path.getsize(zp)//1024,'KB sha',sha[:16])
