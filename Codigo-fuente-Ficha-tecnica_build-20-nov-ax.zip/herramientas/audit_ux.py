# Auditoría UX/funcional del modo Illustrator: recorrido completo de un usuario nuevo
import os,json,glob
from h import *
W,H=int(os.environ.get('AW','1440')),int(os.environ.get('AH','900'))
URLX=os.environ.get('SHARE_URL',BASE+'modified.html'); OUT='audit/%dx%d_'%(W,H)
issues=[]; steps=[]
CHECK="""(()=>{const out=[];const host=document.querySelector('.board-host');if(!host)return['sin mesa'];const hr=host.getBoundingClientRect();
const vis=e=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none'&&r.right>hr.left&&r.left<hr.right&&r.bottom>hr.top&&r.top<hr.bottom};
const ov=(a,b)=>{const r=a.getBoundingClientRect(),s=b.getBoundingClientRect();return !(r.right<=s.left||s.right<=r.left||r.bottom<=s.top||s.bottom<=r.top)};
const isl=document.querySelector('.board-island');
document.querySelectorAll('.pg-lab').forEach(l=>{if(vis(l)&&isl&&ov(isl,l))out.push('barra de herramientas tapa el nombre de '+(l.querySelector('input')||l).value)});
document.querySelectorAll('.pg-add').forEach(a=>{if(!a.hidden&&vis(a))document.querySelectorAll('.pg-spec').forEach(c=>{if(vis(c)&&ov(a,c))out.push('un «+» tapa una columna de campos')})});
const vs=document.querySelector('.pg-viewsw');if(vs&&vs.offsetParent&&!vs.hidden)out.push('el selector de vista sigue visible');
if(document.querySelector('main.content section.spec')&&document.querySelector('main.content section.spec').offsetParent)out.push('el panel flotante está visible');
document.querySelectorAll('.pg-spec .pgs-in').forEach(w=>{const m=(w.style.transform||'').match(/scale\\(([0-9.]+)\\)/);if(m&&+m[1]<0.8)out.push('columna reducida al '+Math.round(+m[1]*100)+'%')});
document.querySelectorAll('.pg-spec').forEach(c=>{if(vis(c)&&c.scrollHeight>c.clientHeight+3&&!c.querySelector('.pgs-in[style*=scale]'))out.push('columna con contenido cortado')});
const cb=document.querySelector('.board-ctxbar');if(cb&&!cb.hidden&&isl&&ov(cb,isl))out.push('la barra de opciones se monta sobre la barra de herramientas');
return out})()"""
def step(pg,name,shot=True):
    pg.wait_for_timeout(500); found=pg.evaluate(CHECK)
    for f in found: issues.append(name+': '+f)
    steps.append(name)
    if shot: pg.screenshot(path=OUT+'%02d_%s.png'%(len(steps),name))
def scr(pg,wx,wy): return pg.evaluate("([x,y])=>{const r=document.querySelector('.board-host').getBoundingClientRect(),v=window.__pgV(),P=window.__PG;return [r.left+v.ox+(x+P.DX)*v.k,r.top+v.oy+y*v.k]}",[wx,wy])
with sync_playwright() as p:
    ctx=launch(p,'audit%d'%W,W,H); pg,lg=new_page(ctx); pg.set_default_timeout(15000); pg.on('dialog',lambda d:d.accept())
    pg.goto(URLX); pg.wait_for_timeout(2200); pg.screenshot(path=OUT+'00_portal.png')
    pg.locator('#newProjectBtn').click(); pg.wait_for_timeout(500); pg.screenshot(path=OUT+'01_nueva_ficha.png')
    pg.fill('#newProjectModel','EJ-24001 · Baggy barrel jeans'); pg.locator('#newProjectForm button.primary').click(); pg.wait_for_timeout(3200)
    step(pg,'ficha_recien_creada')
    if pg.locator('.pg-grid .pg-cell-add').count()<1: issues.append('hoja vacía sin su casilla gris con «+»')
    if pg.locator('.pg-empty:not([hidden])').count(): issues.append('sigue apareciendo el aviso «Arrastra una imagen aquí»')
    ca=pg.evaluate("(()=>{const b=document.querySelector('.pg-spec .pb-coladd');if(!b)return null;return [b.scrollWidth<=b.clientWidth+1,b.getBoundingClientRect().height<40,b.textContent.trim()]})()")
    if ca and not (ca[0] and ca[1]): issues.append('«+ Añadir color» cortado o partido: %s'%ca)
    if pg.evaluate("window.__BOARD.viewId")!='__pages__': issues.append('la ficha nueva no abre en Illustrator')
    if pg.evaluate("window.__PG.single"): issues.append('abre en Presentación')
    # Identificación
    idc='.pg-spec[data-pgv="%s"][data-ci="0"]'%pg.evaluate("window.__PG.pages[0].v.id")
    for lab,val in (('Temporada','AW27'),('Patrón','PB-0012')):
        f=pg.locator(idc+' .pgs-f').filter(has=pg.locator('.pgs-lab',has_text=lab)).locator('textarea')
        if not f.count(): f=pg.locator(idc+' .pgs-f:has(input.pgs-lab[value="%s"]) textarea'%lab)
        if f.count(): f.first.click(); f.first.type(val); pg.wait_for_timeout(200)
        else: issues.append('Identificación: no encuentro el campo '+lab)
    empty_click(pg); pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1600); empty_click(pg)
    step(pg,'identificacion_rellena')
    # Dibujo plano: imagen + anotación + campo
    pg.evaluate("i=>document.querySelector('#visualGallery [data-select-index=\"'+i+'\"]').click()",str('1')); pg.wait_for_timeout(1000)
    pg.set_input_files('.board-island [data-bupload-file]','pantalon.svg'); pg.wait_for_timeout(1600)
    d=pg.evaluate("window.__PG.pages.find(x=>x.i===1)"); ox=d['ox']
    pg.locator('[data-btool="ellipse"]').click(); a=scr(pg,ox+180,180); b=scr(pg,ox+330,330); pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move(*b,steps=6); pg.mouse.up(); pg.wait_for_timeout(1200)
    dc='.pg-spec[data-pgv="%s"]'%d['v']['id']
    if pg.locator(dc+' .pgs-n').count()<1: issues.append('Dibujo plano: la anotación no crea su bloque numerado')
    f=pg.locator(dc+' textarea').first
    if f.count(): f.click(); f.type('Bolsillo delantero'); pg.wait_for_timeout(300)
    empty_click(pg); step(pg,'dibujo_plano_anotado')
    act=pg.evaluate("document.querySelector('#visualGallery > .gallery-card:has(.gallery-thumb.active) .tab-name').textContent.trim()")
    if act!='Sketch': issues.append('pulsar el fondo gris cambió de página a '+act)
    if pg.evaluate("window.__PG.focus")!=d['v']['id']: issues.append('el borde de página activa no está en Dibujo plano')
    if pg.locator('.pg-grid[data-pggrid="%s"] .pg-cell-add'%d['v']['id']).count(): issues.append('la casilla vacía sigue tras subir la imagen')
    # añadir página
    n0=pg.evaluate("window.__PG.pages.length"); pg.evaluate("id=>{const p=window.__PG.pages.find(x=>x.v.id===id);if(window.__PG.focus!==id){const t=document.querySelector('#visualGallery [data-select-index=\"'+p.i+'\"]');t&&t.click()}}",d['v']['id']); pg.wait_for_timeout(900)
    if not pg.locator('.pg-sideadd.r').is_visible(): issues.append('no se ve el «+» lateral de la hoja seleccionada')
    pg.locator('.pg-sideadd.r').click(); pg.wait_for_timeout(1300)
    step(pg,'anadir_pagina_ventana')
    if pg.locator('#tabPop .tab-pop-head strong').count() and pg.locator('#tabPop .tab-pop-head strong').inner_text().strip()!='Nueva página': issues.append('la ventana no se titula «Nueva página»')
    if pg.locator('#tabPop .tab-pop-link').is_visible(): issues.append('la ventana de nueva página muestra «Guardar como ficha tipo»')
    if not pg.locator('#tabPop').is_visible(): issues.append('añadir página: no se abre la ventana')
    else:
        pg.fill('#tabPopName','Medidas'); pg.locator('#tabPop .ui-btn-primary').click(); pg.wait_for_timeout(2600)
        if pg.evaluate("window.__PG.pages.length")!=n0+1: issues.append('añadir página: no se crea')
    step(pg,'pagina_anadida')
    # vista general
    hb=pg.locator('.board-host').bounding_box(); pg.mouse.move(hb['x']+hb['width']/2,hb['y']+hb['height']/2)
    for _ in range(5): pg.keyboard.down('Control'); pg.mouse.wheel(0,120); pg.keyboard.up('Control'); pg.wait_for_timeout(100)
    step(pg,'vista_general')
    # PDF
    os.makedirs('pdfs',exist_ok=True); [os.remove(x) for x in glob.glob('pdfs/audit__*.pdf')]
    pg.evaluate("window.__PG&&(window.__PG.pdfOk=true)")  # «Descargar igualmente» si faltan obligatorios

    got=export_pdf(pg,'audit',wait=60)
    if not got: issues.append('PDF: no se descarga')
    else:
        n,_,tx=pdf_info(got[0][1]); allt=' '.join(tx)
        for need in ('AW27','PB-0012','Bolsillo delantero','Página 1 de','Sketch'):
            if need not in allt: issues.append('PDF: falta «%s»'%need)
        steps.append('pdf %d páginas'%n)
    # recargar
    pg.reload(); pg.wait_for_timeout(2600); pg.locator('#projectGrid .project-card').first.click(); pg.wait_for_timeout(3200)
    v=pg.locator(idc.replace('[data-ci="0"]','')+' .pgs-f').filter(has=pg.locator('.pgs-lab',has_text='Temporada')).locator('textarea').first
    if not v.count() or v.input_value()!='AW27': issues.append('al recargar no se conserva lo escrito')
    step(pg,'recargada')
    errs=[str(x)[:160] for x in lg if 'error' in str(x).lower()]
    issues+=['consola: '+e for e in errs[:5]]
    ctx.close()
print('PASOS:',steps); print('INCIDENCIAS (%d):'%len(issues)); [print(' -',i) for i in issues]
