exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
call("Input.dispatchKeyEvent",{"type":"keyDown","key":"D","code":"KeyD","windowsVirtualKeyCode":68,"modifiers":1|4|8});call("Input.dispatchKeyEvent",{"type":"keyUp","key":"D","code":"KeyD","windowsVirtualKeyCode":68});time.sleep(.8)
print("modal:",ev("!!document.getElementById('pbDiag')"),"| bytes:",ev("(document.querySelector('#pbDiag textarea')||{value:''}).value.length"))
print(ev("(document.querySelector('#pbDiag textarea')||{value:''}).value.slice(0,500)"))
