exec(open("auditoria/deshacer_base.py").read().split('print("inicio:"')[0])
def pt(x,y,t,**k):
    d={"type":t,"x":x,"y":y,"button":"left","clickCount":1};d.update(k);call("Input.dispatchMouseEvent",d)
ev("""__tdbg(`boardAddImage(ASSETS.pantalon.src)`)""");time.sleep(2)
# dibujar un cuadrado marcador sobre la página
ev("""__tdbg(`boardSetTool("rect")`)""")
b=json.loads(ev("JSON.stringify((function(){var p=document.querySelector('.pg-layer [data-pggrid=\"'+window.__pid+'\"]').getBoundingClientRect();return [p.left+80,p.top+80]})())"))
pt(b[0],b[1],"mouseMoved");pt(b[0],b[1],"mousePressed");pt(b[0]+60,b[1]+40,"mouseMoved",buttons=1);pt(b[0]+120,b[1]+80,"mouseMoved",buttons=1);pt(b[0]+120,b[1]+80,"mouseReleased");time.sleep(1.5)
print("modo libre:",ev("document.querySelector('.pg-grid[data-pggrid=\"'+window.__pid+'\"]').classList.contains('is-free')"))
print("botón + visible:",ev("""(function(){var b=document.querySelector('.pg-grid[data-pggrid="'+window.__pid+'"] .pg-gbar');return b?getComputedStyle(b).display:'sin botón'})()"""))
print("antes:",st())
ev("document.querySelector('[data-pgg=\"c+\"][data-pggrid=\"'+window.__pid+'\"]').click()");time.sleep(3)
print("tras +:",st())
print("cuadrícula de la página original sigue:",ev("""JSON.stringify(__tdbg('(function(){var g=pgGridOf(PG.pages.find(function(x){return x.v.id===window.__pid}));return g.c+"x"+g.r})()'))"""))
