exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
def key(k,code,vk,mod=0):
    call("Input.dispatchKeyEvent",{"type":"keyDown","key":k,"code":code,"windowsVirtualKeyCode":vk,"modifiers":mod});call("Input.dispatchKeyEvent",{"type":"keyUp","key":k,"code":code,"windowsVirtualKeyCode":vk,"modifiers":mod});time.sleep(.9)
def st(): return ev("""JSON.stringify(__tdbg('(function(){var p=PG.pages.find(function(x){return x.name==="Fabric"})||PG.pages[2];var g=pgGridOf(p);return {pags:PG.pages.map(function(q){return q.name}),grid:g.c+"x"+g.r,bloques:(pgPageGroup(p).g.items||[]).length,custom:(structure().custom||[]).length,undo:BOARD.undo.length}})()'))""")
ev("""__tdbg(`(function(){var p=PG.pages.find(function(x){return x.name==="Fabric"})||PG.pages[2];pgCenter(p.v.id,true);window.__pid=p.v.id})()`)""");time.sleep(1.5)
print("inicio:",st())
for i in range(3):
    ev("""__tdbg('pgGridSet(window.__pid,1,0)')""");time.sleep(1.2);print("tras +col #%d:"%(i+1),st())
for i in range(5):
    ev("""__tdbg('pgGridSet(window.__pid,0,1)')""");time.sleep(1.4);print("tras +fila #%d:"%(i+1),st())
