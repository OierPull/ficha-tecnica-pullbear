exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
code="""(async function(){var svg='<svg xmlns="http://www.w3.org/2000/svg" width="200" height="140" viewBox="0 0 200 140"><path d="M10 120 L100 10 L190 120 Z" fill="none" stroke="#111" stroke-width="1"/><circle cx="100" cy="80" r="30" fill="none" stroke="#111"/></svg>';var f=new File([svg],'plano.svg',{type:'image/svg+xml'});
 var u=await new Promise(function(r){__tdbg('optimizeImage')(f,r)});return JSON.stringify([u.slice(0,26),u.length])})()"""
print("SVG al subir:",ev(code))
