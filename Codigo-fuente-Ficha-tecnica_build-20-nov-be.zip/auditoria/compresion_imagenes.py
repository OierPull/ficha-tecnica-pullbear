exec(open("auditoria/flujo_imagenes_ui_sin_anotaciones.py").read().split('pan(3312)')[0])
code="""(async function(){
function toFile(u,name){var a=u.split(","),m=/data:([^;]+)/.exec(a[0])[1],b=atob(a[1]),n=b.length,arr=new Uint8Array(n);for(var i=0;i<n;i++)arr[i]=b.charCodeAt(i);return new File([arr],name,{type:m})}
async function mk(w,h,kind,mime,q){var c=document.createElement('canvas');c.width=w;c.height=h;var x=c.getContext('2d');
 if(kind==='photo'){var g=x.createLinearGradient(0,0,w,h);g.addColorStop(0,'#355');g.addColorStop(1,'#cba');x.fillStyle=g;x.fillRect(0,0,w,h);for(var i=0;i<6000;i++){x.fillStyle='rgba('+(Math.random()*255|0)+','+(Math.random()*255|0)+','+(Math.random()*255|0)+',.25)';x.beginPath();x.arc(Math.random()*w,Math.random()*h,2+Math.random()*30,0,7);x.fill()}}
 else{x.fillStyle='#fff';x.fillRect(0,0,w,h);x.strokeStyle='#111';x.lineWidth=2;for(var i=0;i<80;i++){x.beginPath();x.moveTo(Math.random()*w,Math.random()*h);x.bezierCurveTo(Math.random()*w,Math.random()*h,Math.random()*w,Math.random()*h,Math.random()*w,Math.random()*h);x.stroke()}}
 return toFile(c.toDataURL(mime,q),'t.'+mime.split('/')[1])}
var cases=[['foto 6000 JPEG',6000,4000,'photo','image/jpeg',.97],['foto 3000 PNG',3000,2000,'photo','image/png'],['foto 2400 JPEG',2400,1600,'photo','image/jpeg',.92],['dibujo 3000 PNG',3000,2000,'line','image/png']],out=[];
for(var i=0;i<cases.length;i++){var c=cases[i],f=await mk(c[1],c[2],c[3],c[4],c[5]);
 var old=await new Promise(function(r){var rd=new FileReader();rd.onload=function(){var im=new Image();im.onload=function(){var sc=Math.min(1,1800/Math.max(im.naturalWidth,im.naturalHeight)),cv=document.createElement('canvas');cv.width=Math.round(im.naturalWidth*sc);cv.height=Math.round(im.naturalHeight*sc);cv.getContext('2d').drawImage(im,0,0,cv.width,cv.height);r(cv.toDataURL('image/webp',.9))};im.src=rd.result};rd.readAsDataURL(f)});
 var nu=await new Promise(function(r){__tdbg('optimizeImage')(f,r)});
 var dim=await new Promise(function(r){var im=new Image();im.onload=function(){r(im.naturalWidth+'x'+im.naturalHeight)};im.src=nu});
 out.push([c[0],'origen '+Math.round(f.size/1024)+'KB','antes '+Math.round(old.length*.75/1024)+'KB 1800px','ahora '+Math.round(nu.length*.75/1024)+'KB '+dim+' '+nu.slice(5,15)])}
return JSON.stringify(out)})()"""
print(ev(code))
