exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(90)
def ready():
    for _ in range(40):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
ev("document.getElementById('newProjectBtn').click()");time.sleep(.8)
ev("document.querySelector('#newProjectForm button.primary').click()");time.sleep(.6)
print("sin referencia -> modal abierto:",not ev("document.getElementById('newProjectModal').hidden"),"| aviso:",ev("(document.querySelector('#newProjectForm .np-err')||{}).textContent"),"| foco:",ev("document.activeElement.id"),"| ficha abierta:",not ev("document.getElementById('technicalSheetApp').hidden"))
rc=call("Page.captureScreenshot",{"format":"png"});open("/tmp/opencode/np1.png","wb").write(base64.b64decode(rc["result"]["data"]))
ev("(function(){var e=document.getElementById('newProjectModel');e.value='ABC-1';e.dispatchEvent(new Event('input',{bubbles:true}))})()");time.sleep(.3)
print("aviso tras escribir:",ev("!!document.querySelector('#newProjectForm .np-err')"))
ev("document.querySelector('#newProjectForm button.primary').click()");time.sleep(4)
print("ficha abierta:",not ev("document.getElementById('technicalSheetApp').hidden"))
# tarjeta antigua sin nombre
ev("""__tdbg(`(function(){portalProjects.unshift({id:"project-viejo",type:"pantalon",title:"Pantalón / denim",model:"",style:"",createdAt:1,updatedAt:1,blank:true});savePortalProjects()})()`)""")
ev("document.getElementById('returnToProjects').click()");time.sleep(1.5)
print("títulos:",ev("JSON.stringify([].map.call(document.querySelectorAll('.project-card-title'),function(e){return e.textContent}))"))
