exec(open("auditoria/referencia_obligatoria.py").read().split('ev("document.getElementById(\'newProjectBtn\').click()")')[0])
def mk(model,typ):
    ev("document.getElementById('newProjectBtn').click()");time.sleep(.6)
    ev("(function(){var e=document.getElementById('newProjectModel');e.value='%s';e.dispatchEvent(new Event('input',{bubbles:true}));var t=document.getElementById('newProjectType');t.value='%s'})()"%(model,typ));time.sleep(.2)
    ev("document.querySelector('#newProjectForm button.primary').click()");time.sleep(4)
    ev("document.getElementById('returnToProjects').click()");time.sleep(1.5)
print("selector por defecto:",ev("document.getElementById('newProjectType').value=='' && document.getElementById('newProjectType').selectedOptions[0].textContent"))
mk("SIN-TIPO","");mk("CON-TIPO","falda")
print("tarjetas:",ev("JSON.stringify([].map.call(document.querySelectorAll('.project-card'),function(c){return [c.querySelector('.project-card-title').textContent,c.querySelector('.project-card-sub').textContent]}))"))
