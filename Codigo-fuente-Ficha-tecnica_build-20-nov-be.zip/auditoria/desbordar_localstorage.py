exec(open("auditoria/cdp.py").read())
import time,json
s.settimeout(240)
def ready():
    for _ in range(60):
        time.sleep(.5)
        try:
            if ev("document.readyState==='complete'&&typeof window.__tdbg==='function'&&!!document.getElementById('newProjectBtn')"):return
        except Exception: pass
ev("localStorage.clear()");call("Page.reload",{"ignoreCache":True});ready();time.sleep(1.5)
# crear una ficha
ev("document.getElementById('newProjectBtn').click()");time.sleep(.6)
ev("(function(){var e=document.getElementById('newProjectModel');e.value='SPILL-1';e.dispatchEvent(new Event('input',{bubbles:true}))})()")
ev("document.querySelector('#newProjectForm button.primary').click()");time.sleep(4)
# llenar localStorage con relleno ajeno hasta casi el límite
fill="""(function(){var chunk=new Array(1024*100).join('x'),n=0;try{while(true){localStorage.setItem('zz-fill'+n,chunk);n++}}catch(e){}
 var small=new Array(1024).join('y'),m=0;try{while(true){localStorage.setItem('zz-fine'+m,small);m++}}catch(e){}
 return n+' bloques + '+m+' finos'})()"""
print("relleno:",ev(fill))
# ahora guardar una ficha grande (muchos objetos) con la app
big="""__tdbg(`(function(){var u=variantVisual(active,true);u.junk=new Array(400000).join("abcdefghij ");try{saveVisuals()}catch(e){return "ERR "+e}return "guardado"})()`)"""
print("guardar dato grande:",ev(big))
print("banner:",ev("(document.getElementById('pbBanner')||{}).textContent"))
print("estado:",ev("JSON.stringify(window.pbStorage.status())"))
call("Page.reload",{"ignoreCache":True});ready();time.sleep(2)
ev("document.querySelector('[data-project-open]').click()");time.sleep(4)
print("tras recargar, dato grande recuperado:",ev("""__tdbg('(variantVisual(active).junk||"").length')"""),"| banner:",ev("(document.getElementById('pbBanner')||{}).textContent"))
