exec(open("auditoria/orden_exportacion_base.py").read().split("st=ev(")[0])
# dar contenido para que salgan en el plan
ev("""__tdbg(`(function(){var rank=0;(data[active]||[]).forEach(function(g){(g.items||[]).forEach(function(it){(it.fields||[]).forEach(function(f,i){if(i===0&&!f.value)f.value="x"})})});persist();render()})()`)""");time.sleep(1)
print(ev("""JSON.stringify(__tdbg('buildExportPagePlan().map(function(p){return p.section})'))"""))
print("board:",ev("""JSON.stringify(__tdbg('pgItemsAll().map(function(x){return x.name})'))"""))
ev("document.getElementById('pdfExportOpen').click()");time.sleep(1);ev("(function(){var g=document.querySelector('[data-pgwarn=go]');if(g&&g.offsetParent)g.click()})()");time.sleep(1.5)
print("lista del diálogo:",ev("JSON.stringify([].map.call(document.querySelectorAll('#pdfPageList label, #pdfPageList [data-pdf-page]'),function(e){return (e.closest('label')||e).textContent.trim()}))"))
