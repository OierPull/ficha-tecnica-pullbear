# Auditoría de la ficha técnica · build 20-nov-c

## Qué es la aplicación hoy
- Un solo HTML de 8,7 MB. Unos 6,5 MB son imágenes de ejemplo incrustadas y unos 0,5 MB, la librería de PDF.
- El código propio son unos 800 KB de JavaScript y 794 KB de CSS.
- No hace peticiones de red. Guarda todo en `localStorage`.

## Cómo está construida (hallazgos)
- **Capas sobre capas:** hay 920 funciones y 149 puntos donde una función ya existente se sustituye por otra que la envuelve (`var _x=f; f=function(){…}`). El comportamiento final depende del orden en que se cargan los bloques.
- **CSS por especificidad:** hay 7.405 `!important` y selectores con `:not(#a):not(#b)…` para ganar a reglas antiguas. Por eso un arreglo visual (como el círculo del diálogo de color) obliga a añadir otra regla más fuerte.
- **Duplicados:** 14 nombres de función declarados más de una vez (la mayoría dentro de ámbitos distintos).
- **Código muerto:** solo se detectó una función sin uso (`pgRowBoard`), ya eliminada. No hay mucho código muerto que quitar; el problema es la estructura, no la cantidad.

## Causas de las incoherencias que has visto
1. **Imágenes «fantasma».** Un objeto de imagen sin tamaño, sin origen o roto seguía contando como «hoja con imagen». La hoja no mostraba «Añadir imagen» y tampoco había nada que ver. **Corregido.**
2. **Capa de la mesa desfasada.** La capa de títulos, fichas y casillas se reconstruye solo cuando cambia una firma de estado. Si un cambio no entra en esa firma, queda a medias. **Mitigado:** un vigilante comprueba cada 1,5 s que cada hoja tiene título, ficha y casilla de imagen, y la reconstruye si falta algo. También libera un estado de animación atascado.
3. **Barra de opciones en la hoja equivocada.** Las hojas generadas son copias dibujadas de la primera hoja. **Corregido** en la entrega anterior.

## Comprobación automática
`auditoria/smoke_cdp.py` recorre 10 flujos clave y cuenta los errores de consola. Resultado en esta versión: **10 de 10 correctos y 0 errores de consola**.

Necesita Chrome con depuración remota y una versión de prueba del HTML con un gancho temporal. Está pensado para la VM.

## Lo que NO se puede prometer
No se puede garantizar «100 % sin bugs» en este tipo de archivo. Para acercarse de verdad hace falta un trabajo por fases:
1. **Partir el archivo** en módulos (mesa, páginas, PDF, colores, almacenamiento) con una compilación que los una en un único HTML.
2. **Sustituir los envoltorios** por un único lugar donde se define cada función, empezando por la mesa y los marcadores.
3. **Reescribir el CSS** por componentes, sin `!important`, con la rejilla de diseño de Pull&Bear.
4. **Una batería de pruebas** que se ejecute en cada cambio (las 70 pruebas de Playwright del ZIP original más las nuevas).
5. **Revisión de rendimiento:** evitar reconstruir toda la capa de la mesa en cada cambio.

Cada fase se puede probar y entregar por separado sin romper lo existente.

## Auditoría de elementos que no se ven (build 20-nov-h)

Método: se abre un proyecto con la app real y se comprueba, hoja por hoja y en cada zoom, que existen y se ven el título, la ficha y la casilla de imagen (`auditoria/invariantes_mesa.py`). Se hizo la prueba antes y después de los arreglos.

| Elemento | Cuándo desaparecía | Causa | Arreglo |
|---|---|---|---|
| **Títulos de las hojas** (Diseño, Sketch, Fabric…) | Al abrir un proyecto ya guardado, y tras cualquier reconstrucción de la capa | La anchura de las etiquetas se guardaba en una caché por zoom. Al reconstruir las etiquetas con el mismo zoom, las nuevas no recibían anchura y se encogían a 0 px | La anchura se comprueba etiqueta a etiqueta. El vigilante también repara las etiquetas sin anchura |
| **Casilla «Añadir imagen»** y botones de columna y fila | Con zoom alejado | Se ocultaban cuando la hoja medía menos de 380 px en pantalla | El umbral baja a 90 px (botones: 60 px) |
| **Casilla «Añadir imagen»** | Hojas con una imagen «fantasma» | Un objeto de imagen vacío contaba como imagen real | Corregido en la entrega anterior |
| **Orden automático de imágenes** | Al subir la imagen desde «Añadir imagen» de la barra | Esa ruta usa la biblioteca (`boardLibInsert`), que no marcaba la imagen como nueva y se saltaba la lógica | Las tres rutas de entrada (subida directa, biblioteca y SVG) marcan las imágenes nuevas |
| **Versión antigua en el navegador** | Al abrir el enlace tras una actualización | GitHub Pages indica al navegador que guarde la página 10 minutos | La página consulta `version.json` y, si hay una versión más nueva, se recarga sola |

Resultado de la comprobación después de los arreglos: 0 fallos en 14 momentos (crear, 6 niveles de zoom, 2 hojas nuevas, reabrir y 3 imágenes) y 0 errores de consola.

## build 20-nov-m
- «Incluir hoja de cambios» sale marcada al abrir Exportar a PDF.
- Portada del PDF: se re-centra el contenido de la mesa (horizontal y vertical) sin mover las posiciones relativas (`pdfCenterImage`).
- Idioma ES/EN: capa de traducción en pantalla y en el PDF (`I18N_EXACT`, `I18N_RX`, `i18nTr`). Los datos guardados no se tocan. El selector está en la cabecera. Para localizar textos sin traducir: `auditoria/traducciones_sin_traducir.py`.

## build 20-nov-o
- Zoom de la mesa: 100 % = hoja A4 real (297 mm a 96 ppp = 1122,52 px de ancho de hoja). Campo editable para zoom exacto, escalones 5–800 %, botones «A4 · 100%» y «Ajustar», Mayús+0 = 100 %, pinza de Safari (gesture*), el zoom no cambia al redimensionar la ventana.
- Eliminado el botón «Vista A4» de la cabecera.
