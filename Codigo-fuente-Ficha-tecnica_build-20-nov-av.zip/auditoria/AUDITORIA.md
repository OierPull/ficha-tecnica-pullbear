# Auditoría de la ficha técnica · build 20-nov-c

## Qué es la aplicación hoy
- Un solo HTML de 8,7 MB. Unos 6,5 MB son imágenes de ejemplo incrustadas y unos 0,5 MB, la librería de PDF.
- El código propio son unos 800 KB de JavaScript y 794 KB de CSS.
- No hace peticiones de red. Guarda todo en `localStorage`.

## Cómo está construida (hallazgos)
- **Capas sobre capas:** hay 920 funciones y 149 puntos donde una función ya existente se sustituye por otra que la envuelve (`var _x=f; f=function(){…}`). El comportamiento final depende del orden en que se cargan los bloques.
- **CSS por especificidad:** hay 7.405 `!important` y selectores con `:not(#a):not(#b)…` para ganar a reglas antiguas. Por eso un arreglo visual (como el círculo del diálogo de color) obliga a añadir otra regla más fuerte.
- **Duplicados:** 14 nombres de función declarados más de una vez (la mayoría dentro de ámbitos distintos).
- **Código muerto:** solo se detectó una función sin uso (`pgRowBoard`), ya eliminada. No hay mucho código muerto que quitar; el problema es la estructura, no la cantidad.

## Causas de las incoherencias que has visto
1. **Imágenes «fantasma».** Un objeto de imagen sin tamaño, sin origen o roto seguía contando como «hoja con imagen». La hoja no mostraba «Añadir imagen» y tampoco había nada que ver. **Corregido.**
2. **Capa de la mesa desfasada.** La capa de títulos, fichas y casillas se reconstruye solo cuando cambia una firma de estado. Si un cambio no entra en esa firma, queda a medias. **Mitigado:** un vigilante comprueba cada 1,5 s que cada hoja tiene título, ficha y casilla de imagen, y la reconstruye si falta algo. También libera un estado de animación atascado.
3. **Barra de opciones en la hoja equivocada.** Las hojas generadas son copias dibujadas de la primera hoja. **Corregido** en la entrega anterior.

## Comprobación automática
`auditoria/smoke_cdp.py` recorre 10 flujos clave y cuenta los errores de consola. Resultado en esta versión: **10 de 10 correctos y 0 errores de consola**.

Necesita Chrome con depuración remota y una versión de prueba del HTML con un gancho temporal. Está pensado para la VM.

## Lo que NO se puede prometer
No se puede garantizar «100 % sin bugs» en este tipo de archivo. Para acercarse de verdad hace falta un trabajo por fases:
1. **Partir el archivo** en módulos (mesa, páginas, PDF, colores, almacenamiento) con una compilación que los una en un único HTML.
2. **Sustituir los envoltorios** por un único lugar donde se define cada función, empezando por la mesa y los marcadores.
3. **Reescribir el CSS** por componentes, sin `!important`, con la rejilla de diseño de Pull&Bear.
4. **Una batería de pruebas** que se ejecute en cada cambio (las 70 pruebas de Playwright del ZIP original más las nuevas).
5. **Revisión de rendimiento:** evitar reconstruir toda la capa de la mesa en cada cambio.

Cada fase se puede probar y entregar por separado sin romper lo existente.

## Auditoría de elementos que no se ven (build 20-nov-h)

Método: se abre un proyecto con la app real y se comprueba, hoja por hoja y en cada zoom, que existen y se ven el título, la ficha y la casilla de imagen (`auditoria/invariantes_mesa.py`). Se hizo la prueba antes y después de los arreglos.

| Elemento | Cuándo desaparecía | Causa | Arreglo |
|---|---|---|---|
| **Títulos de las hojas** (Diseño, Sketch, Fabric…) | Al abrir un proyecto ya guardado, y tras cualquier reconstrucción de la capa | La anchura de las etiquetas se guardaba en una caché por zoom. Al reconstruir las etiquetas con el mismo zoom, las nuevas no recibían anchura y se encogían a 0 px | La anchura se comprueba etiqueta a etiqueta. El vigilante también repara las etiquetas sin anchura |
| **Casilla «Añadir imagen»** y botones de columna y fila | Con zoom alejado | Se ocultaban cuando la hoja medía menos de 380 px en pantalla | El umbral baja a 90 px (botones: 60 px) |
| **Casilla «Añadir imagen»** | Hojas con una imagen «fantasma» | Un objeto de imagen vacío contaba como imagen real | Corregido en la entrega anterior |
| **Orden automático de imágenes** | Al subir la imagen desde «Añadir imagen» de la barra | Esa ruta usa la biblioteca (`boardLibInsert`), que no marcaba la imagen como nueva y se saltaba la lógica | Las tres rutas de entrada (subida directa, biblioteca y SVG) marcan las imágenes nuevas |
| **Versión antigua en el navegador** | Al abrir el enlace tras una actualización | GitHub Pages indica al navegador que guarde la página 10 minutos | La página consulta `version.json` y, si hay una versión más nueva, se recarga sola |

Resultado de la comprobación después de los arreglos: 0 fallos en 14 momentos (crear, 6 niveles de zoom, 2 hojas nuevas, reabrir y 3 imágenes) y 0 errores de consola.

## build 20-nov-m
- «Incluir hoja de cambios» sale marcada al abrir Exportar a PDF.
- Portada del PDF: se re-centra el contenido de la mesa (horizontal y vertical) sin mover las posiciones relativas (`pdfCenterImage`).
- Idioma ES/EN: capa de traducción en pantalla y en el PDF (`I18N_EXACT`, `I18N_RX`, `i18nTr`). Los datos guardados no se tocan. El selector está en la cabecera. Para localizar textos sin traducir: `auditoria/traducciones_sin_traducir.py`.

## build 20-nov-o
- Zoom de la mesa: 100 % = hoja A4 real (297 mm a 96 ppp = 1122,52 px de ancho de hoja). Campo editable para zoom exacto, escalones 5–800 %, botones «A4 · 100%» y «Ajustar», Mayús+0 = 100 %, pinza de Safari (gesture*), el zoom no cambia al redimensionar la ventana.
- Eliminado el botón «Vista A4» de la cabecera.

## build 20-nov-p
- Idioma: la traducción se aplica de forma síncrona (MutationObserver antes de pintar), sin parpadeo en castellano al actuar en la mesa; el cambio ES⇄EN es instantáneo y sin recargar la página (se guardan los originales para restaurar).

## build 20-nov-q
- Diálogo de color: el código Inditex se calcula solo al mover el selector, escribir el HEX o arrastrar (CIEDE2000 contra la tabla `PG_INDITEX` con HEX). Casilla «Usar el color exacto de Inditex» (activa por defecto) guarda el HEX oficial del código. Si se guarda sin código, se calcula en ese momento.

## build 20-nov-r
- Marcadores numerados de los cuadrados: solo el número en el color del cuadrado (rojo, verde si está aprobado), sin círculo de fondo; en la mesa, en el PDF y en la ficha lateral.

## build 20-nov-s
- Nitidez del PDF: la página de la mesa se rasteriza a 4096 px (antes 1900) y ya no se vuelve a reducir a 1800 px ni a JPEG 0,90 (ahora tope 4200 px, JPEG 0,95).
- Resumen de cambios rediseñado (`layoutPdfChangePages`, `drawVersionChangesPdfPages`): título, tarjetas con totales, secciones agrupadas, etiquetas Nuevo/Modificado/Eliminado, columnas Antes/Ahora y enlaces a página.
- Cambios en las hojas más discretos: sin barra amarilla lateral, píldoras tintadas, resalte de campo suave.
- `auditoria/pdf_render_paginas.py` genera el PDF en la propia página y lo renderiza con pdf.js (copiar pdf.min.js y pdf.worker.min.js 3.11.174 junto al HTML).

## build 20-nov-t
- Colores del bloque «Datos del producto»: las filas de otros colores (`.pg-rowslayer`) heredan ahora el mismo estilo de chips que la fila activa (`.pg-layer`).
- Descarga del PDF: aviso con botón «Descargar de nuevo» tras generar el PDF (por si el navegador bloquea la descarga automática). Flujo real: botón de cabecera → aviso de campos obligatorios → «Descargar sin completar» → botón del color.

## build 20-nov-u
- PDF: en apartados con varias páginas, los cuadrados (y su número) vinculados a bloques de otras páginas se dibujan al 20 % de opacidad, igual que en la mesa (`pdfDimIdsFor`, `pgDimmed`).
- Resumen de cambios: las tarjetas muestran solo el desglose (modificados / nuevos / eliminados) y el total va aparte en texto («7 cambios · 5 apartados»), para que no parezca que se suman dos veces.

## build 20-nov-w
- Estado en web y PDF con el mismo lenguaje: anillo gris = pendiente, círculo verde con check = aprobado, círculo rojo con cruz = rechazado. En el PDF desaparecen las píldoras con borde (bloques: solo icono; página: icono + palabra) y todos los campos llevan su icono.
- «Antes»: en campos modificados, si no había valor se escribe «antes vacío» (sin tachar); en el resumen, filas nuevas/eliminadas usan frases explícitas (No existía / Añadido a la ficha · Estaba en la ficha / Ya no está en la ficha) y «Vacío» cuando procede. Los cambios vacío↔«-» ya no cuentan como cambio.

## build 20-nov-x
- Campos del PDF: check redondeado (extremos redondos), círculo de estado más grande y centrado verticalmente en el campo (mismas proporciones que en la web), sin línea naranja lateral; aprobados con fondo verde suave y modificados pendientes con fondo amarillo suave. Se reserva un hueco a la derecha para el círculo (medición y dibujo coinciden).

## build 20-nov-y
- PDF: eliminada la píldora «N cambios» de la cabecera de cada página (los cambios ya se ven en los campos y en el resumen).

## build 20-nov-z
- «Duplicar otro color»: no se podía cambiar el color de origen porque el radio invisible de la tarjeta (a pantalla completa) interceptaba los clics. Ahora los radios no capturan clics y el selector es propio, con un círculo del color de cada colorway (`pbCsrcUi`); el icono de la tarjeta también muestra el color elegido.

## build 20-nov-aa
- A4 · 100% con tamaño físico real: el navegador no puede conocer los milímetros de la pantalla, así que hay calibración de una vez (tarjeta bancaria 85,6 mm o ancho de un A4 210 mm; se guarda por pantalla y nivel de zoom del navegador) y una estimación inicial para los MacBook habituales (`ZOOM_GUESS`). Botón de regla junto a «A4 · 100%» para recalibrar.

## build 20-nov-ab
- «A4 · 100%» en un MacBook reconocido aplica la estimación al instante (aviso con «Calibrar»); solo abre el calibrador si el dispositivo no se reconoce o se pide calibrar.

## build 20-nov-ac
- Eliminados «A4 · 100%» y el calibrador de pantalla. La barra de zoom queda: − [porcentaje editable] ▾ + | Ajustar. El menú ▾ ofrece «Ajustar a la vista», 50, 75, 100, 150, 200 y 400 %. Atajos: Cmd 0 (ajustar), Mayús+0 (100 %), Cmd +/−.

## build 20-nov-ad
- Atajos como Illustrator: Z = herramienta zoom (persistente); clic y arrastrar a la derecha acerca y a la izquierda aleja (zoom «scrubby» anclado al punto de clic); clic simple acerca, Alt+clic aleja. P = pluma, V = selección (Esc/V/otra herramienta salen del zoom).

## build 20-nov-ae
- Pluma: al cambiar de herramienta (V, H, T, M, L, Z o un botón) el trazo empezado con 2 o más puntos se conserva como trazo abierto; antes se descartaba. Con un solo punto no se crea nada.

## build 20-nov-af
- Borde negro de la hoja: un objeto que sobresale de la hoja atenúa su parte exterior con un velo del color del fondo; ese velo cubría también el borde negro y lo dejaba como una línea gris translúcida. El velo ya respeta una franja de 5 px alrededor de la hoja.

## build 20-nov-ag
- PDF: «Nuevo» en naranja (etiqueta junto al bloque, etiqueta y texto «Añadido a la ficha» del resumen, tarjeta de nuevos y «nuevo» en los campos) para que no se confunda con el verde de aprobado. Modificado sigue en dorado y eliminado en gris.

## build 20-nov-ah
- «Nuevo proveedor»: tarjetas con icono (copia, ficha vacía, plantilla, ficha existente), indicador de selección tipo check y desplegable integrado en la tarjeta elegida; textos traducidos en inglés; el diálogo no se sale por arriba de la ventana.

## build 20-nov-ai
- «Nuevo proveedor»: eliminada la opción «Ficha que ya existe» (quedan Copia de un proveedor, Ficha vacía y Plantilla).

## build 20-nov-aj
- Ficha de la mesa más limpia: campos planos con línea fina en lugar de tarjetas grises, círculos de estado más pequeños y finos, y lo secundario (× de eliminar, reloj de historial, × de campo) solo aparece al pasar el ratón; «+ Añadir campo» queda atenuado hasta pasar el ratón.

## build 20-nov-ak
- Plantilla predeterminada «Denim CRO» (`TPL_BUILTIN`): añade Wash, Fastening, Thread y Others tras Fabric, tomados del PDF de Menswear Denim. Aparece siempre en «Nuevo desarrollo», «Nuevo proveedor» y en Plantillas; se puede editar (se guarda una copia propia) pero reaparece si se borra.

## build 20-nov-al
- «Denim CRO» reorganizada: solo Wash como hoja propia; Fastening (bloque Botón) y Thread (bloque Hilo, con sus campos) se crean dentro de Trims al empezar una ficha con la plantilla (`structure.seed` + `pbTplSeed`). Se elimina Others.

## build 20-nov-am
- PDF con el mismo diseño minimalista que la mesa: los campos sin estado ni cambios son filas planas con línea fina (sin tarjeta gris) y los círculos de estado tienen las mismas proporciones; aprobados (verde) y modificados (amarillo) conservan su fondo suave.

## build 20-nov-an
- PDF: los campos vacíos muestran «Sin especificar» en gris claro en lugar de un guion oscuro.

## build 20-nov-ao
- Aviso «Faltan campos obligatorios»: contador «N de M campos rellenados» y un solo botón visible: «Descargar sin completar» mientras falten campos y «Descargar» cuando estén todos.

## build 20-nov-ap
- Selector de idioma dentro de la mesa: «ES / EN» en texto discreto abajo a la izquierda. Se quita de la cabecera de la ficha; se mantiene en la pantalla principal.

## build 20-nov-aq
- Menús de la cabecera (colores del proveedor y versiones) se abren al pasar el ratón (120 ms) y se cierran al salir (260 ms); clic y teclado siguen funcionando.

## build 20-nov-ar
- Mesa: se quita la línea divisoria bajo el título de cada apartado del panel de especificaciones.

## build 20-nov-as
- Listas de Departamento y Temporada en la mesa: ahora se pueden desplazar con la rueda (antes el scroll cerraba la lista y movía la mesa).

## build 20-nov-at
- Mesa: al pasar de un campo editado a otro, la reconstrucción de la mesa tras guardar el primero quitaba el foco al segundo (había que volver a clicar). Ahora el foco se devuelve al campo pulsado.

## build 20-nov-au
- Descargar PDF: selector «Idioma del PDF» (English por defecto, Español) en el diálogo de exportar; el idioma de la pantalla no cambia. Se recuerda la última elección.
- Mesa: con la herramienta cuadrado/círculo, pulsar sobre el panel de textos pasa a la herramienta ratón y no crea figura. Las figuras ya creadas bajo el panel se seleccionan pulsando en un hueco (o Cmd/Ctrl+clic sobre un campo) y se borran con Supr.

## build 20-nov-av
- Número de los cuadrados editable (`o.no`): en la barra de opciones sustituye a «Grosor» para cuadrados/círculos numerados, y se puede cambiar pulsando el número en la cabecera del bloque del panel. Si el número ya está en uso en la página se avisa y se ofrece intercambiar; los demás se renumeran solos sin repetir.
