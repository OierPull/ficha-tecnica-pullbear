# Ficha técnica Pull&Bear: traspaso para Claude Code

Versión: **build 19-nov-l** (19 de noviembre de 2026).

## Qué es
Una aplicación web en **un único archivo HTML** (`ficha-tecnica.html`, unos 8 MB, con imágenes de ejemplo incrustadas). No usa servidor: guarda todo en `localStorage`. Sin dependencias externas: no carga scripts de fuera ni hace peticiones de red.

## Estructura del código (importante)
- El archivo base es una app antigua («mesa clásica» con panel `#sections`). Encima se han ido añadiendo capas de mejoras.
- Casi todos los cambios recientes están **al final del último `<script>`**, justo antes del comentario `/* ===== PDF: cambiar de proveedor sin cerrar el diálogo ===== */`. Cada bloque empieza con `/* ===== descripción ===== */`.
- El estilo nuevo está **al final del último `<style>`**. Muchas reglas llevan un prefijo con `:not(#q1)…:not(#q6)` para ganar especificidad frente al CSS antiguo.
- Patrón habitual: envolver funciones existentes (`var _orig=fn; fn=function(){…}`). Algunas funciones viven en ámbitos cerrados (por ejemplo `SVGE` y `SVGP`, de la edición de SVG). Para tocarlas hay que insertar el código **dentro** de ese ámbito.
- La versión visible está en el texto `build 19-nov-l`. Al cambiar algo, súbela (19-nov-m, etc.).

## Conceptos clave
- **Mesa de páginas** (`PG`, `BOARD`): una fila por color y una hoja por página. `PG.pages` contiene las páginas; `pgLayerBuild()` reconstruye la capa de títulos, campos y cuadrícula; `boardRedraw()` repinta el lienzo.
- **Datos**: `data[active]` es la ficha del color abierto. Los demás colores están en `colorSheets[colorVariantKey(active,colorId)]`. La lista de colores está en `colorOptions`, y `saveColorState()` guarda los tres.
- **Estructura** (páginas propias, ocultas, títulos): `structure()` y `structSave()`. Las páginas propias pueden tener `d.colors=[ids]`, para existir solo en esos colores.
- **Plantillas** (antes «fichas tipo»): `TPLUI`, `tplRender`, `tplSave`, `TPL_STORE="pb-ficha-templates-v1"`.
- **Colores Inditex**: `PG_INDITEX` (629 códigos, generado desde `herramientas/inditex_colors.json`, a partir de `colores_pull.xlsx`). `pantoneParse` está envuelta: si escribes números, los busca en la lista de Inditex.
- **Proveedores**: cada proveedor es un «proyecto» en una carpeta. El nombre se guarda en `project.supplier`; el campo «Proveedor» de Diseño ya no existe.

## Pruebas automáticas (Playwright, Python)
- `pruebas/h.py` contiene las funciones comunes: `launch`, `new_page`, `R`, `export_pdf`, `empty_click`. La variable `BASE` apunta a `http://127.0.0.1:8765/`.
- **Servidor:** desde la carpeta donde esté el HTML (con el nombre `modified.html`, o ajusta `BASE` y las rutas), ejecuta `python3 -m http.server 8765 --bind 127.0.0.1`.
- **Una prueba:** `python3 pruebas/t_clicks.py`. Al final imprime `RESUMEN: N pruebas, M fallos`.
- **Probar el HTML empaquetado:** `SHARE_URL=file:///ruta/Ficha-tecnica-PullBear.html python3 pruebas/t_x.py`.
- Pruebas recientes y útiles: `t_misc5`, `t_ind`, `t_tpl2`, `t_clicks`, `t_refit`, `t_pen3`, `t_colpage`, `t_fix3`, `t_feedback`, `t_grid`, `t_pages2`, `t_rows2`.
- Las pruebas necesitan `pantalon.svg` en la carpeta de trabajo; cualquier SVG sencillo sirve.
- **Empaquetar para los diseñadores:** `python3 herramientas/make_pkg2.py modified.html dist herramientas/LEEME_new.txt`. Comprueba la seguridad (sin `eval` ni red) y genera el zip con `LEEME.txt`, `SEGURIDAD.txt` y `SHA256.txt`.

## Pendiente (último mensaje de la usuaria, sin resolver)
1. **Página nueva solo en algunos colores.** Al desmarcar un color en «Nueva página», la página se sigue creando en ese color. El código está en el bloque `/* ===== páginas solo en algunos colores ===== */`.
   - **Cómo funciona:** al pulsar «Añadir» se guardan los colores marcados y un temporizador busca la página nueva en `structure().custom` para asignarle `nd.colors`.
   - **Causa probable:** la página nueva no se detecta, por ejemplo si `structure(true)` devuelve otra copia o si la página se crea por otra vía.
   - **Por dónde empezar:** depurar con un caso de 4 colores, creando la página desde el «+» entre hojas.
2. **Títulos de página no siempre legibles.** El nombre de cada hoja (arriba a la izquierda) a veces no se lee con zoom alejado. Revisar el tamaño y la escala de `.pg-lab .pgl-cur` según el zoom; podría usarse un tamaño mínimo en pantalla.
3. **Hoja de una sola casilla.** Con la primera imagen añadida desde «Añadir imagen» de la hoja, la segunda imagen subida desde la barra se encaja en la cuadrícula la primera vez que se mueve; después ya va libre.
   - **Dónde mirar:** la envoltura de `pgGridOnCommit` (busca `o.pgFree1`) y la lógica de imagen nueva, que asigna la casilla 0.
   - **Qué tiene que pasar:** en una hoja de 1×1, solo la primera imagen debe colocarse grande y centrada; las demás, libres desde el primer momento.

## Notas
- La usuaria pide cambios pequeños con pruebas dirigidas, y una auditoría completa solo cuando pide el resultado definitivo.
- Los colores siempre se piden por **código Inditex**.
- La pluma va con Mayús + P. P vuelve a selección, V selecciona y Z hace zoom mientras se mantiene pulsada.


## Cambios build 20-nov-bi
- «+» del grid crea página a la derecha con animación; botones del grid siempre visibles.
- Resto: ver auditoria/AUDITORIA.md.
